﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_Interfaces;
using CPE_Lib;
using log4net;

namespace DPE_Methodic_Engine
{
    public class DPE_Methodic_Block: Block
    {
        ILog logger = log4net.LogManager.GetLogger(typeof(DPE_Methodic_Block));
        private CPE_Methodic methodic = new CPE_Methodic();
        public CPE_Methodic Methodic
        {
            get { return methodic; }
            set { methodic = value; }
        }

        private List<int> inputs = new List<int>();
        public List<int> Inputs
        {
            get { return inputs; }
            set { inputs = value; }
        }

        private List<int> outputs;

        public List<int> Outputs
        {
            get { return outputs; }
            set { outputs = value; }
        }


        public override bool Init()
        {
            this.Methodic.Init();

            return base.Init();
        }
        public override bool Activate()
        {
            this.Methodic.Activate();
            for (int i = 0; i < this.Outputs.Count; i++)
            {
                this.Dpe.GetRegister(this.Outputs[i]).Data = new DataNodeDouble();
            }
            return base.Activate();
        }
        public override void Execute()
        {
            this.logger.DebugFormat("Execute() Begin");
            base.Execute();


            Slice slice = new Slice();
            slice.InputData = new double[this.Inputs.Count];
            slice.InputStatus = new CPE_ValidityDataTypes[this.Inputs.Count];
            slice.OutputData = new double[this.Outputs.Count];
            slice.OutputStatus = new CPE_ValidityDataTypes[this.Outputs.Count];
            for (int i = 0; i < slice.OutputStatus.Length; i++)
            {
                slice.OutputStatus[i] = CPE_ValidityDataTypes.ValidityDataTypeUndefined;
            }

            for (int i = 0; i < this.Inputs.Count; i++)
            {
                if (this.Dpe.GetRegister(this.Inputs[i]).Data != null)
                {
                    DataNodeDouble data_node = (DataNodeDouble)this.Dpe.GetRegister(this.Inputs[i]).Data;
                    slice.InputData[i] = data_node.DataDouble;
                    slice.InputStatus[i] = (CPE_ValidityDataTypes)data_node.State;
                }
                else
                {
                    slice.InputData[i] = 0;
                    slice.InputStatus[i] = CPE_ValidityDataTypes.ValidityDataTypeUndefined;
                }
            }
            try
            {
                this.Methodic.Execute(slice);
            }
            catch (Exception ex)
            {
                this.logger.ErrorFormat("Error in Methodic Execute: {0}", ex.Message);
            }
            for (int i = 0; i < this.Outputs.Count; i++)
            {
                DataNodeDouble data_node = (DataNodeDouble)this.Dpe.GetRegister(this.Outputs[i]).Data;
                data_node.DataDouble = slice.OutputData[i];
                data_node.State = (DPE_Status)slice.OutputStatus[i];
            }
            this.logger.DebugFormat("Execute() End");
        }
        public override void DeActivate()
        {
            this.Methodic.DeActivate();
            base.DeActivate();
        }
        public override void DeInit()
        {
            this.Methodic.DeInit();
            base.DeInit();
        }
    }
}
