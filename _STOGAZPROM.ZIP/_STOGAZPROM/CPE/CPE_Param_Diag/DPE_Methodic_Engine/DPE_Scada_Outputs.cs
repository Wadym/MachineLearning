﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_IO_Block;
using log4net;

namespace DPE_Methodic_Engine
{
    public class DPE_Scada_Outputs : DPEOutputSDABlock
    {
        private string[] scada_tags = new string[0];

        public string[] Scada_Tags
        {
            get { return scada_tags; }
            set { scada_tags = value; }
        }

        private List<int> ids = new List<int>();
        public List<int> IDs
        {
            get { return ids; }
            set { ids = value; }
        }

        public void Config(string[] scada_tags)
        {
            this.Scada_Tags = scada_tags;
        }

        ILog logger;
        public override bool Init()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
            logger.InfoFormat("Init() start");

            for (int i = 0; i < this.Scada_Tags.Length; i++)
            {
                if (this.Scada_Tags[i] != "")
                {
                    this.IDs.Add(100 + i);
                    logger.InfoFormat("Init() Add nodes[{0}] Scada_Tag ={1}, ID={2}", i, this.Scada_Tags[i], this.IDs[this.IDs.Count-1]);
                    this.SDATags.Add(new SDANode(this.Scada_Tags[i], this.IDs[this.IDs.Count - 1]));
                }
            }
            logger.InfoFormat("Init() done");
            bool result = base.Init();
            logger.InfoFormat("Init() done base");
            return result;
        }
        public override bool Activate()
        {
            return base.Activate();
        }
        public override void Execute()
        {
            this.logger.DebugFormat("Execute()");
            base.Execute();
            this.logger.DebugFormat("Execute() done");
        }

    }
}
