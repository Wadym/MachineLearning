﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_IO_Block;
using log4net;
using DPE_Interfaces;

namespace DPE_Methodic_Engine
{
    public class DPE_Scada_Inputs: DPEInputSDABlock 
    {
        static ILog Logger = log4net.LogManager.GetLogger(typeof(DPE_Scada_Inputs));
        private string[] scada_tags = new string[0];

        public string[] Scada_Tags
        {
            get { return scada_tags; }
            set { scada_tags = value; }
        }

        private List<string> tags = new List<string>();

        public List<string> Tags
        {
            get { return tags; }
            set { tags = value; }
        }

        private List<int> ids = new List<int>();
        public List<int> IDs
        {
            get { return ids; }
            set { ids = value; }
        }


        List<float> a = new List<float>();
        List<float> b_add = new List<float>();

        public void Config(string[] scada_tags)
        {
            this.Scada_Tags = scada_tags;
        }

        public override bool Init()
        {
            for (int i = 0; i < this.scada_tags.Length; i++)
            {
                if (this.scada_tags[i] != "")
                {
                    string[] add = this.scada_tags[i].Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries);
                    float a = 1;
                    float b = 0;
                    string tag = string.Empty;
                    try
                    {
                        if (add.Length > 1)
                        {
                            b = Convert.ToSingle(add[1].Replace(" ",""));
                        }
                        string[] mult = add[0].Split(new string[] { "*" }, StringSplitOptions.RemoveEmptyEntries);
                        if (mult.Length > 1)
                        {
                            a = Convert.ToSingle(mult[1].Replace(" ", ""));
                        }
                        tag = mult[0].Replace(" ", "");
                    }
                    catch (Exception ex)
                    {
                        Logger.ErrorFormat("Error in Tag definition: {0}, messge = {1}", this.scada_tags[i], ex.Message);
                    }

                    this.b_add.Add(b);
                    this.a.Add(a);
                    this.IDs.Add(i);
                    this.Tags.Add(tag);
                    //this.SDATags.Add(new SDANode(this.inputs[i].Scada_Tag, this.inputs[i].ID));
                }
            }
            for (int i = 0; i < this.IDs.Count; i++)
            {
                this.SDATags.Add(new SDANode(this.Tags[i], this.IDs[i]));
            }
            return base.Init();
        }
        public override bool Activate()
        {
            return base.Activate();
        }
        public override void Execute()
        {
            base.Execute();
            // Make input correction for every input node...
            for (int i = 0; i < this.IDs.Count; i++)
            {
                if (this.Dpe.GetRegister(this.IDs[i]).Data != null)
                {
                    DataNodeDouble data_node = (DataNodeDouble)this.Dpe.GetRegister(this.IDs[i]).Data;
                    data_node.DataDouble = data_node.DataDouble * this.a[i] + this.b_add[i];
                }
            }
            //for (int i = 0; i < this.inputs.Count; i++)
            //{
            //    DataNodeDouble data_node = (DataNodeDouble)this.Dpe.GetRegister(this.inputs[i].ID).Data.Data;
            //    data_node.DataDouble = data_node.DataDouble * this.inputs[i].A + this.inputs[i].B;
            //}
        }

    }
}
