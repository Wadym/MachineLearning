﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE;
using log4net;
using CPE_Lib;

namespace DPE_Methodic_Engine
{
    public class DPE_Methodic_Exec
    {

        private DPE_Scada_Inputs inputs = new DPE_Scada_Inputs();
        public DPE_Scada_Inputs Inputs
        {
            get { return inputs; }
            set { inputs = value; }
        }

        private DPE_Methodic_Block methodic = new DPE_Methodic_Block();
        public DPE_Methodic_Block Methodic
        {
            get { return methodic; }
            set { methodic = value; }
        }

        private DPE_Scada_Outputs outputs = new DPE_Scada_Outputs();
        public DPE_Scada_Outputs Outputs
        {
            get { return outputs; }
            set { outputs = value; }
        }


        private DP_Engine dpe = new DP_Engine();
        public DP_Engine DPE
        {
            get { return dpe; }
            set { dpe = value; }
        }

        ILog logger;
        public void Config()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
            logger.InfoFormat("Config() = Config");

            this.DPE.Inputs.Add(this.Inputs);
            this.DPE.ProcessingBlocks.Add(this.methodic);
            this.DPE.Outputs.Add(this.Outputs);
            this.Outputs.ConnectionUpdate = 60;
//            this.Output.ConnectionUpdate = 60;
//            this.DPE.Outputs.Add(this.Output);
        }

        public Boolean Init()
        {
            logger.InfoFormat("Init() = Config");
            Boolean isInitialized = this.DPE.Init();
            this.Methodic.Inputs = this.Inputs.IDs;
            this.Methodic.Outputs = this.Outputs.IDs;

            return isInitialized;
        }
        public Boolean Activate()
        {
            return this.DPE.Activate();
        }

        public Boolean Deactivate()
        {
            return this.DPE.DeActivate();
        }
        public Boolean DeInit()
        {
            return this.DPE.DeInit();
        }
        
        private CPE_DataBlobAccess file_access  = new CPE_DataBlobAccess();

        public CPE_DataBlobAccess File_Access
        {
            get { return file_access; }
            set { file_access = value; }
        }

    }
}
