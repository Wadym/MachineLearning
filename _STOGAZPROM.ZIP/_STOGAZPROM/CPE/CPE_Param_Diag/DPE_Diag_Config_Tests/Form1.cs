﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DPE_Diag_Config;
using System.Xml.Serialization;
using System.IO;
using System.Xml;

namespace DPE_Diag_Config_Tests
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string filename = @"test_xml_002.xml";
        private void button1_Click(object sender, EventArgs e)
        {
            DPE_Methodic_Cfg cfg = new DPE_Methodic_Cfg();
            List<Type> types = new List<Type>();

            types.Add(typeof(DPE_Defaults_Cfg));
            types.Add(typeof(DPE_Methodic_Common_Cfg));
            types.Add(typeof(DPE_Methodic_InOut));
            types.Add(typeof(DPE_View_Config));

            cfg.Common.Views.Add(new DPE_View_Config());

            types.Add(typeof(DPE_Methodic_Shop));
            types.Add(typeof(DPE_Methodic_Agregate));

            cfg.Common.Defaults = "_MethodicConfig_";
            cfg.Tuning.Add(new  DPE_Methodic_Shop());
            cfg.Tuning[0].Agregates.Add(new DPE_Methodic_Agregate());
            XmlSerializer xmlS = new XmlSerializer(typeof(List<DPE_Methodic_Cfg>), types.ToArray());
            List<DPE_Methodic_Cfg> sss = new List<DPE_Methodic_Cfg>();
            sss.Add(cfg);
            Stream fs = new FileStream(filename, FileMode.Create);
            StreamWriter writer = new StreamWriter(fs);
            xmlS.Serialize(writer, sss);
            writer.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Type> types = new List<Type>();
            types.Add(typeof(DPE_Methodic_Cfg));
            types.Add(typeof(DPE_Defaults_Cfg));
            types.Add(typeof(DPE_Methodic_Common_Cfg));
            types.Add(typeof(DPE_Methodic_InOut));
            types.Add(typeof(DPE_View_Config));
            types.Add(typeof(XmlNode));
            
            XmlSerializer xmlS = new XmlSerializer(typeof(DPE_Methodic_Cfg), types.ToArray());

            Stream fr = new FileStream(filename, FileMode.Open);
            StreamReader reader = new StreamReader(fr);
            DPE_Methodic_Cfg cfg = (DPE_Methodic_Cfg)xmlS.Deserialize(reader);
            reader.Close();

            //XmlSerializer xml_w = new XmlSerializer(cfg.Common.Defaults.MethodicConfig.GetType(), types.ToArray());

            //XmlSerializer xml_w = new XmlSerializer(cfg.Common.Defaults.MethodicConfig.GetType());
            //MemoryStream fs = new MemoryStream();
            //StreamWriter writer = new StreamWriter(fs);
            //xml_w.Serialize(writer, cfg.Common.Defaults.MethodicConfig);
            //writer.Close();
            //string temp = Encoding.Default.GetString(fs.ToArray());
            //Console.WriteLine("Cfg = {0}", temp);

            XmlNode[] nodes = cfg.Common.Defaults as XmlNode[];
            
            if (nodes != null)
            {
                for (int i = 0; i < nodes.Length; i++)
                {
                    if (nodes[i].Name == "MethodicConfig")
                    {
                        Console.WriteLine("{0}", nodes[i].Name);
                        string res = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                        res += nodes[i].OuterXml;
                        Console.WriteLine("Xml[{0}] = {1}", i, res);
                        File.WriteAllText("temp_xml.xml", res);
                        //Console.WriteLine("Xml[{0}] = {1}", i, MyNodeToString(nodes[i], 1));
                    }
                }
            }
            //for (int i = 0; i < cfg.Tuning[0].Agregates[0].MethodicConfig; i++)
            {
                
            }
            //reader.Close();
        }

        string MyNodeToString(System.Xml.XmlNode node, int indentation)
        {

            using (var sw = new System.IO.StringWriter())
            {
                using (var xw = new System.Xml.XmlTextWriter(sw))
                {
                    xw.Formatting = System.Xml.Formatting.Indented;
                    xw.Indentation = indentation;
                    node.WriteContentTo(xw);
                }
                return sw.ToString();
            }
            return "";
        }
    }
}
