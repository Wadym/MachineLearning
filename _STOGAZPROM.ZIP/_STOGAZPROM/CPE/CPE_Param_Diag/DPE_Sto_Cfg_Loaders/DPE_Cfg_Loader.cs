﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using System.Xml.Serialization;
using System.IO;

namespace DPE_Sto_Cfg_Loaders
{
    public class DPE_Cfg_Loader
    {
        public static List<Metodic> GetMethodics(string filename)
        {
            List<Metodic> block_xml = new List<Metodic>();
            ConfigPage block = new ConfigPD();

            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).STO.Shops.Add(new Shop_STO_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).STO.Shops[i].Agregates.Add(new Agregate_STO_Config());
                }
            }
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).DG90.Shops.Add(new Shop_DG90_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).DG90.Shops[i].Agregates.Add(new Agregate_DG90_Config());
                }
            }

            List<Type> block_types = block.GetTypes(new List<Type>());
            block_types.Add(typeof(bool));
            XmlSerializer xmlS = new XmlSerializer(block_xml.GetType(), block_types.ToArray());

            Stream fr = new FileStream(filename, FileMode.Open);
            StreamReader reader = new StreamReader(fr);
            List<Metodic> result = (List<Metodic>)xmlS.Deserialize(reader);
            reader.Close();

            return result;
        }

        public virtual bool Init()
        {
            bool result = true;
            return result;
        }

        public virtual void Start()
        {
        }

        public virtual void Stop()
        {
        }

    }
}
