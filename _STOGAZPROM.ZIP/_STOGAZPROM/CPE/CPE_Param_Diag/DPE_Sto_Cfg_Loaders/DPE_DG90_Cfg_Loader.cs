﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using CPE_Metodic_DG90;
using CPE_Metodic_STO;
using System.IO;

namespace DPE_Sto_Cfg_Loaders
{
    public class DPE_DG90_Cfg_Loader : DPE_Cfg_Loader
    {
        Model_DG90_Config common = null;
        Agregate_DG90_Config agregate = null;

        private DPE_DG90_Engine engine = new DPE_DG90_Engine();
        public DPE_DG90_Engine Engine
        {
            get { return engine; }
            set { engine = value; }
        }


        public bool Config(Model_DG90_Config common, uint shop_id, Agregate_DG90_Config agregate, string main_path)
        {
            bool result = true;
            this.common = common;
            this.agregate = agregate;

            this.Engine.Config();

            // Set up inputs
            this.Engine.Input.ShopID = shop_id;
            this.Engine.Input.MachineID = (uint)agregate.Mashine_ID;
            this.Engine.Output.ShopID = shop_id;
            this.Engine.Output.MachineID = (uint)agregate.Mashine_ID;

            this.Engine.Input.Tag = string.Format("DPE CPE Input {0}, {1}", shop_id, agregate.Mashine_ID);
            this.Engine.Input.ConnectionUpdate = 60;
            this.Engine.FileRead.Tag = string.Format("FileRead {0}, {1}", shop_id, agregate.Mashine_ID);
            this.Engine.CPE.Tag = string.Format("CPE {0}, {1}", shop_id, agregate.Mashine_ID);

            #region T_Atm_C

            this.Engine.Input.T_Atm_C.Scada_Tag = common.Inputs.T_Atm_C.Scada_Tag;
            this.Engine.Input.T_Atm_C.ID = 1;

            CPE_Data T_Atm_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_Atm_C.A = agregate.InputsCorrection.T_Atm_C.A;
            else T_Atm_C.A = common.Inputs.T_Atm_C.A;
            if (agregate.InputsCorrection.Initialized) T_Atm_C.B = agregate.InputsCorrection.T_Atm_C.B;
            else T_Atm_C.B = common.Inputs.T_Atm_C.B;
            T_Atm_C.Attr = common.Inputs.T_Atm_C.Attribute;
            T_Atm_C.RegID = this.Engine.Input.T_Atm_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_Atm_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Atm_C)] = common.Inputs.T_Atm_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Atm_C)] = common.Inputs.T_Atm_C.MaxDiff;
            #endregion
            #region P_Atm_kPa
            //P_Atm_kPa
            this.Engine.Input.P_Atm_kPa.Scada_Tag = common.Inputs.P_Atm_kPa.Scada_Tag;
            this.Engine.Input.P_Atm_kPa.ID = 2;

            CPE_Data P_Atm_kPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) P_Atm_kPa.A = agregate.InputsCorrection.P_Atm_kPa.A;
            else P_Atm_kPa.A = common.Inputs.P_Atm_kPa.A;
            if (agregate.InputsCorrection.Initialized) P_Atm_kPa.B = agregate.InputsCorrection.P_Atm_kPa.B;
            else P_Atm_kPa.B = common.Inputs.P_Atm_kPa.B;
            P_Atm_kPa.Attr = common.Inputs.P_Atm_kPa.Attribute;
            P_Atm_kPa.RegID = this.Engine.Input.P_Atm_kPa.ID;
            this.Engine.CPE.Input.Nodes.Add(P_Atm_kPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Atm_kPa)] = common.Inputs.P_Atm_kPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Atm_kPa)] = common.Inputs.P_Atm_kPa.MaxDiff;
            #endregion
            #region N_rot_nd_RPM
            //N_rot_nd_RPM
            this.Engine.Input.N_rot_nd_RPM.Scada_Tag = common.Inputs.N_rot_nd_RPM.Scada_Tag;
            this.Engine.Input.N_rot_nd_RPM.ID = 3;

            CPE_Data N_rot_nd_RPM = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) N_rot_nd_RPM.A = agregate.InputsCorrection.N_rot_nd_RPM.A;
            else N_rot_nd_RPM.A = common.Inputs.N_rot_nd_RPM.A;
            if (agregate.InputsCorrection.Initialized) N_rot_nd_RPM.B = agregate.InputsCorrection.N_rot_nd_RPM.B;
            else N_rot_nd_RPM.B = common.Inputs.N_rot_nd_RPM.B;
            N_rot_nd_RPM.Attr = common.Inputs.N_rot_nd_RPM.Attribute;
            N_rot_nd_RPM.RegID = this.Engine.Input.N_rot_nd_RPM.ID;
            this.Engine.CPE.Input.Nodes.Add(N_rot_nd_RPM);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_nd_RPM)] = common.Inputs.N_rot_nd_RPM.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_nd_RPM)] = common.Inputs.N_rot_nd_RPM.MaxDiff;
            #endregion
            #region N_rot_vd_RPM
            //N_rot_vd_RPM
            this.Engine.Input.N_rot_vd_RPM.Scada_Tag = common.Inputs.N_rot_vd_RPM.Scada_Tag;
            this.Engine.Input.N_rot_vd_RPM.ID = 4;

            CPE_Data N_rot_vd_RPM = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) N_rot_vd_RPM.A = agregate.InputsCorrection.N_rot_vd_RPM.A;
            else N_rot_vd_RPM.A = common.Inputs.N_rot_vd_RPM.A;
            if (agregate.InputsCorrection.Initialized) N_rot_vd_RPM.B = agregate.InputsCorrection.N_rot_vd_RPM.B;
            else N_rot_vd_RPM.B = common.Inputs.N_rot_vd_RPM.B;
            N_rot_vd_RPM.Attr = common.Inputs.N_rot_vd_RPM.Attribute;
            N_rot_vd_RPM.RegID = this.Engine.Input.N_rot_vd_RPM.ID;
            this.Engine.CPE.Input.Nodes.Add(N_rot_vd_RPM);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_vd_RPM)] = common.Inputs.N_rot_vd_RPM.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_vd_RPM)] = common.Inputs.N_rot_vd_RPM.MaxDiff;
            #endregion
            #region N_rot_nag_RPM
            //N_rot_nag_RPM
            this.Engine.Input.N_rot_nag_RPM.Scada_Tag = common.Inputs.N_rot_nag_RPM.Scada_Tag;
            this.Engine.Input.N_rot_nag_RPM.ID = 5;

            CPE_Data N_rot_nag_RPM = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) N_rot_nag_RPM.A = agregate.InputsCorrection.N_rot_nag_RPM.A;
            else N_rot_nag_RPM.A = common.Inputs.N_rot_nag_RPM.A;
            if (agregate.InputsCorrection.Initialized) N_rot_nag_RPM.B = agregate.InputsCorrection.N_rot_nag_RPM.B;
            else N_rot_nag_RPM.B = common.Inputs.N_rot_nag_RPM.B;
            N_rot_nag_RPM.Attr = common.Inputs.N_rot_nag_RPM.Attribute;
            N_rot_nag_RPM.RegID = this.Engine.Input.N_rot_nag_RPM.ID;
            this.Engine.CPE.Input.Nodes.Add(N_rot_nag_RPM);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_nag_RPM)] = common.Inputs.N_rot_nag_RPM.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.N_rot_nag_RPM)] = common.Inputs.N_rot_nag_RPM.MaxDiff;
            #endregion
            #region T_In_Nag_C
            //T_In_Nag_C
            this.Engine.Input.T_In_Nag_C.Scada_Tag = common.Inputs.T_In_Nag_C.Scada_Tag;
            this.Engine.Input.T_In_Nag_C.ID = 6;

            CPE_Data T_In_Nag_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_In_Nag_C.A = agregate.InputsCorrection.T_In_Nag_C.A;
            else T_In_Nag_C.A = common.Inputs.T_In_Nag_C.A;
            if (agregate.InputsCorrection.Initialized) T_In_Nag_C.B = agregate.InputsCorrection.T_In_Nag_C.B;
            else T_In_Nag_C.B = common.Inputs.T_In_Nag_C.B;
            T_In_Nag_C.Attr = common.Inputs.T_In_Nag_C.Attribute;
            T_In_Nag_C.RegID = this.Engine.Input.T_In_Nag_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_In_Nag_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_In_Nag_C)] = common.Inputs.T_In_Nag_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_In_Nag_C)] = common.Inputs.T_In_Nag_C.MaxDiff;
            #endregion
            #region T_Out_Nag_C
            //T_Out_Nag_C
            this.Engine.Input.T_Out_Nag_C.Scada_Tag = common.Inputs.T_Out_Nag_C.Scada_Tag;
            this.Engine.Input.T_Out_Nag_C.ID = 7;

            CPE_Data T_Out_Nag_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_Out_Nag_C.A = agregate.InputsCorrection.T_Out_Nag_C.A;
            else T_Out_Nag_C.A = common.Inputs.T_Out_Nag_C.A;
            if (agregate.InputsCorrection.Initialized) T_Out_Nag_C.B = agregate.InputsCorrection.T_Out_Nag_C.B;
            else T_Out_Nag_C.B = common.Inputs.T_Out_Nag_C.B;
            T_Out_Nag_C.Attr = common.Inputs.T_Out_Nag_C.Attribute;
            T_Out_Nag_C.RegID = this.Engine.Input.T_Out_Nag_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_Out_Nag_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Out_Nag_C)] = common.Inputs.T_Out_Nag_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Out_Nag_C)] = common.Inputs.T_Out_Nag_C.MaxDiff;
            #endregion
            #region P_Over_In_Nag_MPa
            //P_Over_In_Nag_MPa
            this.Engine.Input.P_Over_In_Nag_MPa.Scada_Tag = common.Inputs.P_Over_In_Nag_MPa.Scada_Tag;
            this.Engine.Input.P_Over_In_Nag_MPa.ID = 8;

            CPE_Data P_Over_In_Nag_MPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) P_Over_In_Nag_MPa.A = agregate.InputsCorrection.P_Over_In_Nag_MPa.A;
            else P_Over_In_Nag_MPa.A = common.Inputs.P_Over_In_Nag_MPa.A;
            if (agregate.InputsCorrection.Initialized) P_Over_In_Nag_MPa.B = agregate.InputsCorrection.P_Over_In_Nag_MPa.B;
            else P_Over_In_Nag_MPa.B = common.Inputs.P_Over_In_Nag_MPa.B;
            P_Over_In_Nag_MPa.Attr = common.Inputs.P_Over_In_Nag_MPa.Attribute;
            P_Over_In_Nag_MPa.RegID = this.Engine.Input.P_Over_In_Nag_MPa.ID;
            this.Engine.CPE.Input.Nodes.Add(P_Over_In_Nag_MPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Over_In_Nag_MPa)] = common.Inputs.P_Over_In_Nag_MPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Over_In_Nag_MPa)] = common.Inputs.P_Over_In_Nag_MPa.MaxDiff;
            #endregion
            #region P_Over_Out_Nag_MPa
            //P_Over_Out_Nag_MPa
            this.Engine.Input.P_Over_Out_Nag_MPa.Scada_Tag = common.Inputs.P_Over_Out_Nag_MPa.Scada_Tag;
            this.Engine.Input.P_Over_Out_Nag_MPa.ID = 9;

            CPE_Data P_Over_Out_Nag_MPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) P_Over_Out_Nag_MPa.A = agregate.InputsCorrection.P_Over_Out_Nag_MPa.A;
            else P_Over_Out_Nag_MPa.A = common.Inputs.P_Over_Out_Nag_MPa.A;
            if (agregate.InputsCorrection.Initialized) P_Over_Out_Nag_MPa.B = agregate.InputsCorrection.P_Over_Out_Nag_MPa.B;
            else P_Over_Out_Nag_MPa.B = common.Inputs.P_Over_Out_Nag_MPa.B;
            P_Over_Out_Nag_MPa.Attr = common.Inputs.P_Over_Out_Nag_MPa.Attribute;
            P_Over_Out_Nag_MPa.RegID = this.Engine.Input.P_Over_Out_Nag_MPa.ID;
            this.Engine.CPE.Input.Nodes.Add(P_Over_Out_Nag_MPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Over_Out_Nag_MPa)] = common.Inputs.P_Over_Out_Nag_MPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Over_Out_Nag_MPa)] = common.Inputs.P_Over_Out_Nag_MPa.MaxDiff;
            #endregion
            #region dP_In_Conf_kPa
            //dP_In_Conf_kPa
            this.Engine.Input.dP_In_Conf_kPa.Scada_Tag = common.Inputs.dP_In_Conf_kPa.Scada_Tag;
            this.Engine.Input.dP_In_Conf_kPa.ID = 10;

            CPE_Data dP_In_Conf_kPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) dP_In_Conf_kPa.A = agregate.InputsCorrection.dP_In_Conf_kPa.A;
            else dP_In_Conf_kPa.A = common.Inputs.dP_In_Conf_kPa.A;
            if (agregate.InputsCorrection.Initialized) dP_In_Conf_kPa.B = agregate.InputsCorrection.dP_In_Conf_kPa.B;
            else dP_In_Conf_kPa.B = common.Inputs.dP_In_Conf_kPa.B;
            dP_In_Conf_kPa.Attr = common.Inputs.dP_In_Conf_kPa.Attribute;
            dP_In_Conf_kPa.RegID = this.Engine.Input.dP_In_Conf_kPa.ID;
            this.Engine.CPE.Input.Nodes.Add(dP_In_Conf_kPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dP_In_Conf_kPa)] = common.Inputs.dP_In_Conf_kPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dP_In_Conf_kPa)] = common.Inputs.dP_In_Conf_kPa.MaxDiff;
            #endregion
            #region T_In_Os_Compr_C
            //T_In_Os_Compr_C
            this.Engine.Input.T_In_Os_Compr_C.Scada_Tag = common.Inputs.T_In_Os_Compr_C.Scada_Tag;
            this.Engine.Input.T_In_Os_Compr_C.ID = 11;

            CPE_Data T_In_Os_Compr_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_In_Os_Compr_C.A = agregate.InputsCorrection.T_In_Os_Compr_C.A;
            else T_In_Os_Compr_C.A = common.Inputs.T_In_Os_Compr_C.A;
            if (agregate.InputsCorrection.Initialized) T_In_Os_Compr_C.B = agregate.InputsCorrection.T_In_Os_Compr_C.B;
            else T_In_Os_Compr_C.B = common.Inputs.T_In_Os_Compr_C.B;
            T_In_Os_Compr_C.Attr = common.Inputs.T_In_Os_Compr_C.Attribute;
            T_In_Os_Compr_C.RegID = this.Engine.Input.T_In_Os_Compr_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_In_Os_Compr_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_In_Os_Compr_C)] = common.Inputs.T_In_Os_Compr_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_In_Os_Compr_C)] = common.Inputs.T_In_Os_Compr_C.MaxDiff;
            #endregion
            #region T_Calc_Gg_C
            //T_Calc_Gg_C
            this.Engine.Input.T_Calc_Gg_C.Scada_Tag = common.Inputs.T_Calc_Gg_C.Scada_Tag;
            this.Engine.Input.T_Calc_Gg_C.ID = 12;

            CPE_Data T_Calc_Gg_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_Calc_Gg_C.A = agregate.InputsCorrection.T_Calc_Gg_C.A;
            else T_Calc_Gg_C.A = common.Inputs.T_Calc_Gg_C.A;
            if (agregate.InputsCorrection.Initialized) T_Calc_Gg_C.B = agregate.InputsCorrection.T_Calc_Gg_C.B;
            else T_Calc_Gg_C.B = common.Inputs.T_Calc_Gg_C.B;
            T_Calc_Gg_C.Attr = common.Inputs.T_Calc_Gg_C.Attribute;
            T_Calc_Gg_C.RegID = this.Engine.Input.T_Calc_Gg_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_Calc_Gg_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Calc_Gg_C)] = common.Inputs.T_Calc_Gg_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_Calc_Gg_C)] = common.Inputs.T_Calc_Gg_C.MaxDiff;
            #endregion
            #region dTg_Over_CBN_sau
            //dTg_Over_CBN_sau
            this.Engine.Input.dTg_Over_CBN_sau.Scada_Tag = common.Inputs.dTg_Over_CBN_sau.Scada_Tag;
            this.Engine.Input.dTg_Over_CBN_sau.ID = 13;

            CPE_Data dTg_Over_CBN_sau = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) dTg_Over_CBN_sau.A = agregate.InputsCorrection.dTg_Over_CBN_sau.A;
            else dTg_Over_CBN_sau.A = common.Inputs.dTg_Over_CBN_sau.A;
            if (agregate.InputsCorrection.Initialized) dTg_Over_CBN_sau.B = agregate.InputsCorrection.dTg_Over_CBN_sau.B;
            else dTg_Over_CBN_sau.B = common.Inputs.dTg_Over_CBN_sau.B;
            dTg_Over_CBN_sau.Attr = common.Inputs.dTg_Over_CBN_sau.Attribute;
            dTg_Over_CBN_sau.RegID = this.Engine.Input.dTg_Over_CBN_sau.ID;
            this.Engine.CPE.Input.Nodes.Add(dTg_Over_CBN_sau);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dTg_Over_CBN_sau)] = common.Inputs.dTg_Over_CBN_sau.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dTg_Over_CBN_sau)] = common.Inputs.dTg_Over_CBN_sau.MaxDiff;
            #endregion
            #region T_TG_C
            //T_TG_C
            this.Engine.Input.T_TG_C.Scada_Tag = common.Inputs.T_TG_C.Scada_Tag;
            this.Engine.Input.T_TG_C.ID = 14;

            CPE_Data T_TG_C = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) T_TG_C.A = agregate.InputsCorrection.T_TG_C.A;
            else T_TG_C.A = common.Inputs.T_TG_C.A;
            if (agregate.InputsCorrection.Initialized) T_TG_C.B = agregate.InputsCorrection.T_TG_C.B;
            else T_TG_C.B = common.Inputs.T_TG_C.B;
            T_TG_C.Attr = common.Inputs.T_TG_C.Attribute;
            T_TG_C.RegID = this.Engine.Input.T_TG_C.ID;
            this.Engine.CPE.Input.Nodes.Add(T_TG_C);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_TG_C)] = common.Inputs.T_TG_C.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.T_TG_C)] = common.Inputs.T_TG_C.MaxDiff;
            #endregion
            #region P_Tg_Flow_MPa
            //P_Tg_Flow_MPa
            this.Engine.Input.P_Tg_Flow_MPa.Scada_Tag = common.Inputs.P_Tg_Flow_MPa.Scada_Tag;
            this.Engine.Input.P_Tg_Flow_MPa.ID = 15;

            CPE_Data P_Tg_Flow_MPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) P_Tg_Flow_MPa.A = agregate.InputsCorrection.P_Tg_Flow_MPa.A;
            else P_Tg_Flow_MPa.A = common.Inputs.P_Tg_Flow_MPa.A;
            if (agregate.InputsCorrection.Initialized) P_Tg_Flow_MPa.B = agregate.InputsCorrection.P_Tg_Flow_MPa.B;
            else P_Tg_Flow_MPa.B = common.Inputs.P_Tg_Flow_MPa.B;
            P_Tg_Flow_MPa.Attr = common.Inputs.P_Tg_Flow_MPa.Attribute;
            P_Tg_Flow_MPa.RegID = this.Engine.Input.P_Tg_Flow_MPa.ID;
            this.Engine.CPE.Input.Nodes.Add(P_Tg_Flow_MPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Tg_Flow_MPa)] = common.Inputs.P_Tg_Flow_MPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Tg_Flow_MPa)] = common.Inputs.P_Tg_Flow_MPa.MaxDiff;
            #endregion
            #region dP_Diafr_Tg_kPa
            //dP_Diafr_Tg_kPa
            this.Engine.Input.dP_Diafr_Tg_kPa.Scada_Tag = common.Inputs.dP_Diafr_Tg_kPa.Scada_Tag;
            this.Engine.Input.dP_Diafr_Tg_kPa.ID = 16;

            CPE_Data dP_Diafr_Tg_kPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) dP_Diafr_Tg_kPa.A = agregate.InputsCorrection.dP_Diafr_Tg_kPa.A;
            else dP_Diafr_Tg_kPa.A = common.Inputs.dP_Diafr_Tg_kPa.A;
            if (agregate.InputsCorrection.Initialized) dP_Diafr_Tg_kPa.B = agregate.InputsCorrection.dP_Diafr_Tg_kPa.B;
            else dP_Diafr_Tg_kPa.B = common.Inputs.dP_Diafr_Tg_kPa.B;
            dP_Diafr_Tg_kPa.Attr = common.Inputs.dP_Diafr_Tg_kPa.Attribute;
            dP_Diafr_Tg_kPa.RegID = this.Engine.Input.dP_Diafr_Tg_kPa.ID;
            this.Engine.CPE.Input.Nodes.Add(dP_Diafr_Tg_kPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dP_Diafr_Tg_kPa)] = common.Inputs.dP_Diafr_Tg_kPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dP_Diafr_Tg_kPa)] = common.Inputs.dP_Diafr_Tg_kPa.MaxDiff;
            #endregion
            #region dTg_sau
            //dTg_sau
            this.Engine.Input.dTg_sau.Scada_Tag = common.Inputs.dTg_sau.Scada_Tag;
            this.Engine.Input.dTg_sau.ID = 17;

            CPE_Data dTg_sau = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) dTg_sau.A = agregate.InputsCorrection.dTg_sau.A;
            else dTg_sau.A = common.Inputs.dTg_sau.A;
            if (agregate.InputsCorrection.Initialized) dTg_sau.B = agregate.InputsCorrection.dTg_sau.B;
            else dTg_sau.B = common.Inputs.dTg_sau.B;
            dTg_sau.Attr = common.Inputs.dTg_sau.Attribute;
            dTg_sau.RegID = this.Engine.Input.dTg_sau.ID;
            this.Engine.CPE.Input.Nodes.Add(dTg_sau);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dTg_sau)] = common.Inputs.dTg_sau.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.dTg_sau)] = common.Inputs.dTg_sau.MaxDiff;
            #endregion
            #region P_OK_MPa
            //P_OK_MPa
            this.Engine.Input.P_OK_MPa.Scada_Tag = common.Inputs.P_OK_MPa.Scada_Tag;
            this.Engine.Input.P_OK_MPa.ID = 18;

            CPE_Data P_OK_MPa = new CPE_Data();
            if (agregate.InputsCorrection.Initialized) P_OK_MPa.A = agregate.InputsCorrection.P_OK_MPa.A;
            else P_OK_MPa.A = common.Inputs.P_OK_MPa.A;
            if (agregate.InputsCorrection.Initialized) P_OK_MPa.B = agregate.InputsCorrection.P_OK_MPa.B;
            else P_OK_MPa.B = common.Inputs.P_OK_MPa.B;
            P_OK_MPa.Attr = common.Inputs.P_OK_MPa.Attribute;
            P_OK_MPa.RegID = this.Engine.Input.P_OK_MPa.ID;
            this.Engine.CPE.Input.Nodes.Add(P_OK_MPa);

            this.Engine.CPE.ModeDetector.MinValues[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_OK_MPa)] = common.Inputs.P_OK_MPa.Min;
            this.Engine.CPE.ModeDetector.Delta[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_OK_MPa)] = common.Inputs.P_OK_MPa.MaxDiff;
            #endregion
            #region P_Gas

//            this.Engine.FileRead.Filename = string.Format(@"c:\ASTD-2\Data\ParamGas\ParamGas_{0}_{1}.xml", shop_id, agregate.Mashine_ID);
            this.Engine.FileRead.Filename = Path.Combine(main_path, string.Format(@"ParamGas_{0}_{1}.xml", shop_id, agregate.Mashine_ID));
            this.Engine.FileRead.Nodes.Add(19); // P_Gas
            this.Engine.FileRead.Nodes.Add(20); // NV_Gas
            //P_Gas

            CPE_Data P_Gas = new CPE_Data();
            P_Gas.A = 1;
            P_Gas.B = 0;
            P_Gas.Attr = 1;
            P_Gas.RegID = 19;
            this.Engine.CPE.Input.Nodes.Add(P_Gas);

            this.Engine.CPE.ModeDetector.MinValues[18] = -100000000;
            this.Engine.CPE.ModeDetector.Delta[18] = 100000000;
            //            this.Engine.CPE.Input.Attributes[this.Engine.Input.Inputs.IndexOf(this.Engine.Input.P_Gas)] = 1;
            #endregion
            #region NV_Gas
            //NV_Gas

            CPE_Data NV_Gas = new CPE_Data();
            NV_Gas.A = 1;
            NV_Gas.B = 0;
            NV_Gas.Attr = 1;
            NV_Gas.RegID = 20;
            this.Engine.CPE.Input.Nodes.Add(NV_Gas);
            this.Engine.CPE.ModeDetector.MinValues[19] = -100000000;
            this.Engine.CPE.ModeDetector.Delta[19] = 100000000;
            #endregion

            #region Preprocessor Settings
            // Set Parameters 1
            this.Engine.CPE.Preprocessor.const1[0] = 0;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[1] = this.agregate.Parameters1.P_Nom_MVt;
            else this.Engine.CPE.Preprocessor.const1[1] = this.common.Defaults.Parameters1.P_Nom_MVt;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[2] = this.agregate.Parameters1.N_Nom_Nd_RPM;
            else this.Engine.CPE.Preprocessor.const1[2] = this.common.Defaults.Parameters1.N_Nom_Nd_RPM;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[3] = this.agregate.Parameters1.N_Nom_Dble_RPM;
            else this.Engine.CPE.Preprocessor.const1[3] = this.common.Defaults.Parameters1.N_Nom_Dble_RPM;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[4] = this.agregate.Parameters1.P_Atm_kPa;
            else this.Engine.CPE.Preprocessor.const1[4] = this.common.Defaults.Parameters1.P_Atm_kPa;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[5] = this.agregate.Parameters1.Coeff_Conf_N;
            else this.Engine.CPE.Preprocessor.const1[5] = this.common.Defaults.Parameters1.Coeff_Conf_N;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[6] = this.agregate.Parameters1.Coeff_Topl_Ring_N;
            else this.Engine.CPE.Preprocessor.const1[6] = this.common.Defaults.Parameters1.Coeff_Topl_Ring_N;

            if (this.agregate.Parameters1.Initialized) this.Engine.CPE.Preprocessor.const1[7] = this.agregate.Parameters1.Fuel_Power;
            else this.Engine.CPE.Preprocessor.const1[7] = this.common.Defaults.Parameters1.Fuel_Power;
            #endregion Preprocessor Settings
            // Set Parameters 1
            //this.Engine.CPE.Preprocessor.const1[0] = 0;

            if (this.agregate.Parameters.Initialized) this.Engine.CPE.DG90_GL.Consts4[0] = this.agregate.Parameters.Delta_T;
            else this.Engine.CPE.DG90_GL.Consts4[0] = this.common.Defaults.Parameters.Delta_T;

            if (this.agregate.Parameters.Initialized) this.Engine.CPE.DG90_GL.Consts4[1] = this.agregate.Parameters.Delta_N_OK;
            else this.Engine.CPE.DG90_GL.Consts4[1] = this.common.Defaults.Parameters.Delta_N_OK;

            if (this.agregate.Parameters.Initialized) this.Engine.CPE.DG90_GL.Consts4[2] = this.agregate.Parameters.Delta_P_OK;
            else this.Engine.CPE.DG90_GL.Consts4[2] = this.common.Defaults.Parameters.Delta_P_OK;

            this.Engine.Output.Outputs.Clear();
            this.Engine.Output.Outputs.Add(new Sto_Input(common.Outputs.DeviationTemp, 141));
            this.Engine.CPE.Output.Positions.Add(new SlicePosition(3, 0, 141));
            this.Engine.Output.Outputs.Add(new Sto_Input(common.Outputs.DeviationRotation, 142));
            this.Engine.CPE.Output.Positions.Add(new SlicePosition(3, 1, 142));
            this.Engine.Output.Outputs.Add(new Sto_Input(common.Outputs.DeviationPressure, 143));
            this.Engine.CPE.Output.Positions.Add(new SlicePosition(3, 2, 143));
            this.Engine.Output.Tag = string.Format("CPE2DPE DG90 Output {0}, {1}", shop_id, agregate.Mashine_ID);
            return result;
        }

        public override bool Init()
        {
            bool result = true;
            this.Engine.Init();
            return result;
        }

        public override void Start()
        {
            this.Engine.Start();
        }

        public override void Stop()
        {
            this.Engine.Stop();
            this.Engine.DeInit();
        }
 

    }
}
