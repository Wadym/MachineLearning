﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using DPE_Interfaces;
using System.Threading;

namespace CPE_Metodic_STO
{
    public class DPE_Sto_FileInput : DPE_Sto_Input
    {
        private string filename = @"c:\Tehnekon\VD-SCADA\branches\3.1.ParamDiag_22.10.2015\Projects\DPE\Param_Diagnostic\CPE\CPE\Data\orsha3_160304.csv";
        public string Filename
        {
            get { return filename; }
            set { filename = value; }
        }

        private List<int> input_indexses = new List<int>()
        {
            0,
            0,
            47,
            48,
            46,
            0,
            1,
            14,
            15,
            20,
            31,
            40,
            0,
            0,
            2,
            19,
            21,
            0,
            16,
            0, // P_Gas
            0, // NV_Gas
        };

        public List<int> InputIndexes
        {
            get { return input_indexses; }
            set { input_indexses = value; }
        }

        private DateTime start_time = DateTime.Now;
        public DateTime StartTime
        {
            get { return start_time; }
            set { start_time = value; }
        }

        private int time_step = 2000;
        public int TimeStepMs
        {
            get { return time_step; }
            set { time_step = value; }
        }

        List<double[]> data_arrays = new List<double[]>();
        public override bool Init()
        {
            bool result = true;
            StreamReader reader = new StreamReader(File.OpenRead(this.filename));
            while (false == reader.EndOfStream)
            {
                string line = reader.ReadLine();
                line = line.Replace(',', '.');
                string[] lines = line.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                List<double> data = new List<double>();
                for (int i = 0; i < lines.Length; i++)
                {
                    data.Add(Convert.ToDouble(lines[i]));
                }
                data_arrays.Add(data.ToArray());
            }
            reader.Close();
            this.read_count = 0;
            return result;
        }
        int read_count = 0;

        public override bool Activate()
        {
            return true;
        }


        public event EventHandler EndOfArray;
        public override void Execute()
        {
            //base.Execute();
            bool result = true;
            if ((this.read_count >= this.data_arrays.Count) || (this.read_count > 100000))
            {
                if (this.EndOfArray != null) this.EndOfArray(this, null);
                //Thread.Sleep(10000000);
                this.read_count = 0;
            }
            DateTime Timestamp = this.start_time + new TimeSpan(0, 0, 0, 0, this.TimeStepMs * this.read_count);
            List<double> data = new List<double>();
            for (int i = 0; i < this.InputIndexes.Count; i++)
            {
                data.Add(data_arrays[this.read_count][this.InputIndexes[i]]);
            }
            this.read_count++;
            List<DataNode> datas = this.Dpe.GetFifo().GetList();

            for (int i = 0; i < Math.Min(data.Count, this.Inputs.Count); i++)
            {
                DataNodeDouble dnd = DataNodeDouble.CreateDataNodeDouble(this.Inputs[i].ID, data[i], DPE_Status.OK, Timestamp);
                datas.Add(dnd);
            }
            //datas[datas.Count - 2].Data = 0.6853;
            //datas[datas.Count - 1].Data = 33700.0;
        }
    }
}
