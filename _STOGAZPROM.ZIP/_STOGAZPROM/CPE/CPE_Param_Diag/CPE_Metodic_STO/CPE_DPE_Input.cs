﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using DPE_Interfaces;
using log4net;

namespace CPE_Metodic_STO
{
    public class CPE_Data
    {
        private double a = 1;
        public double A
        {
            get { return a; }
            set { a = value; }
        }

        private double b = 0;
        public double B
        {
            get { return b; }
            set { b = value; }
        }

        private int attr = -1;
        public int Attr
        {
            get { return attr; }
            set { attr = value; }
        }
        private int reg_id = 0;
        public int RegID
        {
            get { return reg_id; }
            set { reg_id = value; }
        }


        private DataNodeDouble dpe_node;
        public DataNodeDouble DPE_Node
        {
            get { return dpe_node; }
            set { dpe_node = value; }
        }
    }

    public class CPE_DPE_Input: SliceProcessing
    {
        
        private List<CPE_Data> nodes = new List<CPE_Data>();
        public List<CPE_Data> Nodes
        {
            get { return nodes; }
            set { nodes = value; }
        }
        ILog logger;
 
        public override void Config()
        {
        }

        public override void Init()
        {
            this.logger = LogManager.GetLogger(this.GetType());
        }

        public override bool Process(Slice input)
        {
            bool result = true;
            //return base.Process(input, output, history);
            List<double> data = new List<double>();
            List<int> status = new List<int>();
            for (int i = 0; i < this.Nodes.Count; i++)
            {
                if (this.Nodes[i].DPE_Node != null)
                {
                    double val = this.Nodes[i].DPE_Node.DataDouble * this.Nodes[i].A + this.Nodes[i].B;
                    int stat = 0;
                    if (this.Nodes[i].DPE_Node.State != DPE_Status.OK)
                    {
                        val = 0;
                        stat = -1;
                    }
                    status.Add(stat);
                    data.Add(val);
                }
                else
                {
                    data.Add(0);
                }
                input.Attr.Add(this.Nodes[i].Attr);
            }
            if ((this.Nodes[0].DPE_Node != null) && (this.Nodes.Count > 0)) input.Timestamp = this.Nodes[0].DPE_Node.Time;
            else
            {
                input.Timestamp = DateTime.Now;
            }
            input.Data.Add(data);
            input.Status.Clear();
            input.Status.AddRange(status);

            input.Pos_Name.Add(string.Format("CPE_DPE_Input[{0}]: входной массив данных {1},", input.Data.Count - 1, data.Count));
            string log_data = "";
            for (int i = 0; i < data.Count; i++)
            {
                log_data += string.Format("[{0}]={1}, ", i,data[i]);
            }
            this.logger.DebugFormat("Received data = {0}", log_data);
            return result;
        }

        public override void DeInit()
        {
            
        }
    }

}
