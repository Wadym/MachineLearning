﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE;
using log4net;
using CPE_Metodic_STO;

namespace CPE_Metodic_DG90
{
    public class DPE_DG90_Engine
    {
        private DPE_Sto_Input input = new DPE_Sto_Input();
        public DPE_Sto_Input Input
        {
            get { return input; }
            set { input = value; }
        }


        private CPE_Metodic_DG90_DPE cpe = new CPE_Metodic_DG90_DPE();
        public CPE_Metodic_DG90_DPE CPE
        {
            get { return cpe; }
            set { cpe = value; }
        }

        private DP_Engine dpe = new DP_Engine();
        public DP_Engine DPE
        {
            get { return dpe; }
            set { dpe = value; }
        }

        private DPE_Sto_Output output = new DPE_Sto_Output();
        public DPE_Sto_Output Output
        {
            get { return output; }
            set { output = value; }
        }

        private DPE_Sto_DataFileInput file_read = new DPE_Sto_DataFileInput();
        public DPE_Sto_DataFileInput FileRead
        {
            get { return file_read; }
            set { file_read = value; }
        }

        ILog logger;

        public void Config()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
            logger.InfoFormat("Config() = Config");
            this.DPE.Inputs.Add(this.Input);
            this.DPE.ProcessingBlocks.Add(FileRead);
            this.DPE.ProcessingBlocks.Add(this.cpe);
            this.Output.ConnectionUpdate = 60;
            this.DPE.Outputs.Add(this.Output);
        }

        public void Init()
        {
            logger.InfoFormat("Init() = Config");
            this.DPE.Init();
            //this.CPE.Init();
        }
        public void Start()
        {
            this.DPE.Activate();
        }

        public void Stop()
        {
            this.DPE.DeActivate();
        }
        public void DeInit()
        {
            this.DPE.DeInit();
        }
    }
}
