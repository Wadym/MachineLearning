﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_CommonBlocks;
using DPE_Interfaces;
using log4net;

namespace CPE_Metodic_STO
{
    public class CPE_Metodic_STO_DPE: DPE_Interfaces.Block
    {
        private List<int> input_regs = new List<int>()
        {
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20
        };
        public List<int> InputRegs
        {
            get { return input_regs; }
            set { input_regs = value; }
        }

        private List<int> output_regs = new List<int>()
        {
            100, 101,
        };
        public List<int> OutputRegs
        {
            get { return output_regs; }
            set { output_regs = value; }
        }


        CPE_Engine cpe_engine = new CPE_Engine();
        public CPE_Engine CPE_Engine
        {
            get { return cpe_engine; }
            set { cpe_engine = value; }
        }


        private CPE_ModeDetector mode_detector = new CPE_ModeDetector();
        public CPE_ModeDetector ModeDetector
        {
            get { return mode_detector; }
            set { mode_detector = value; }
        }

        private CPE_STO_GP_Preprocess preprocessor = new CPE_STO_GP_Preprocess();
        public CPE_STO_GP_Preprocess Preprocessor
        {
            get { return preprocessor; }
            set { preprocessor = value; }
        }

        private CPE_STO_GP_Guideline gp_gl = new CPE_STO_GP_Guideline();
        public CPE_STO_GP_Guideline GP_GL
        {
            get { return gp_gl; }
            set { gp_gl = value; }
        }

        private CPE_DPE_Input input = new CPE_DPE_Input();
        public CPE_DPE_Input Input
        {
            get { return input; }
            set { input = value; }
        }

        private CPE_DPE_Output output = new CPE_DPE_Output();
        public CPE_DPE_Output Output
        {
            get { return output; }
            set { output = value; }
        }

        public override bool Init()
        {
            this.logger = log4net.LogManager.GetLogger(this.GetType());
            this.cpe_engine.Slice_Process.Insert(0,this.input);
            this.cpe_engine.Slice_Process.Insert(1, this.mode_detector);
            this.Preprocessor.ReadParams = true;
            this.cpe_engine.Slice_Process.Insert(2, this.Preprocessor);
            this.cpe_engine.Slice_Process.Insert(3, this.gp_gl);
            this.cpe_engine.Slice_Process.Insert(4, this.output);
            this.cpe_engine.Init();

            //for (int i = 0; i < this.InputRegs.Count; i++)
            //{
            //    this.input.Nodes.Add((DataNodeDouble)this.Dpe.GetRegister(this.InputRegs[i]).Data);
            //}
            //for (int i = 0; i < this.Input.Nodes.Count; i++)
            //{
            //    this.Input.Nodes[i].DPE_Node = (DataNodeDouble)this.Dpe.GetRegister(this.Input.Nodes[i].RegID).Data;
            //}
            //for (int i = 0; i < this.Output.Positions.Count; i++)
            //{
            //    this.Dpe.GetRegister(this.OutputRegs[i]).Data = new DataNodeDouble();
            //    this.Dpe.GetRegister(this.OutputRegs[i]).Data.RegID = this.Output.Positions[i].RegID;
            //    this.output.Nodes.Add((DataNodeDouble)this.Dpe.GetRegister(this.OutputRegs[i]).Data);
            //}
            //for (int i = 0; i < this.OutputRegs.Count; i++)
            //{
            //    this.Dpe.GetRegister(this.OutputRegs[i]).Data = new DataNodeDouble();
            //    this.Dpe.GetRegister(this.OutputRegs[i]).Data.RegID = this.OutputRegs[i];
            //    this.output.Nodes.Add((DataNodeDouble)this.Dpe.GetRegister(this.OutputRegs[i]).Data);
            //}
            for (int i = 0; i < this.output.Positions.Count; i++)
            {
                DataRegister reg = this.Dpe.GetRegister(this.output.Positions[i].RegID);
                reg.Data = new DataNodeDouble();
                reg.Data.RegID = this.output.Positions[i].RegID;
                this.output.Nodes.Add((DataNodeDouble)reg.Data);
            }
            return base.Init();
        }
        public override bool Activate()
        {
            return base.Activate();
        }
        public override void DeActivate()
        {
            base.DeActivate();
        }
        public override void DeInit()
        {
            base.DeInit();
        }
        ILog logger;
        public override void Execute()
        {
            Slice slice = new Slice();
            //
            for (int i = 0; i < this.Input.Nodes.Count; i++)
            {
                this.Input.Nodes[i].DPE_Node = (DataNodeDouble)this.Dpe.GetRegister(this.Input.Nodes[i].RegID).Data;
            }
            this.cpe_engine.Process(slice);
            this.logger.DebugFormat("Execute: Positions.Count = {0}", this.Output.Positions.Count);
            for (int i = 0; i < this.Output.Positions.Count; i++)
            {
                this.logger.DebugFormat("Execute:[{0}] Data[{1}]={2}", i, this.Output.Positions[i].RegID, ((DataNodeDouble)this.Dpe.GetRegister(this.Output.Positions[i].RegID).Data).DataDouble);
                this.Output.Nodes[i] = (DataNodeDouble)this.Dpe.GetRegister(this.Output.Positions[i].RegID).Data;
                this.Dpe.GetRegister(this.Output.Positions[i].RegID).Updated = true;
            }
        }
    }
}
