﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using DPE_Interfaces;
using log4net;

namespace CPE_Metodic_STO
{
    public class SlicePosition
    {
        public SlicePosition(int pos, int index, int reg_id)
        {
            this.pos = pos;
            this.index = index;
            this.reg_id = reg_id;
        }

        private int pos = -1;
        public int Pos
        {
            get { return pos; }
            set { pos = value; }
        }

        private int index = -1;
        public int Index
        {
            get { return index; }
            set { index = value; }
        }

        private int reg_id;
        public int RegID
        {
            get { return reg_id; }
            set { reg_id = value; }
        }

    }

    public class CPE_DPE_Output : SliceProcessing
    {
        private List<DataNodeDouble> nodes = new List<DataNodeDouble>();
        public List<DataNodeDouble> Nodes
        {
            get { return nodes; }
            set { nodes = value; }
        }

        private List<SlicePosition> positions = new List<SlicePosition>();

        public List<SlicePosition> Positions
        {
            get { return positions; }
            set { positions = value; }
        }

        public override void Config()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
        }
        public override void Init()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
        }
        ILog logger;
        public override bool Process(Slice input)
        {
            logger.Debug("Process begin");
            bool result = true;
            for (int i = 0; i < this.Nodes.Count; i++)
            {
                logger.DebugFormat("Process: data[{0}] - [{1}][{2}], input.Data.Count= {3}", i, this.Positions[i].Pos, this.Positions[i].Index, input.Data.Count);
                this.Nodes[i].DataDouble = input.Data[this.Positions[i].Pos][this.Positions[i].Index];
                this.Nodes[i].State = DPE_Status.OK;
                this.Nodes[i].Time = input.Timestamp;
                logger.DebugFormat("Process: data[{0}] - {1}, time={2}:{3}", i, this.Nodes[i].DataDouble, input.Timestamp, input.Timestamp.Millisecond);
            }
            logger.Debug("Process end");
            return result;
        }

        public override void DeInit()
        {

        }
    }
}
