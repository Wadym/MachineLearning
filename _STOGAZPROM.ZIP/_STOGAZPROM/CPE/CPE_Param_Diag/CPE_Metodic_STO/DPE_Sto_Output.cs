﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_IO_Block;
using DPE_Interfaces;
using log4net;

namespace CPE_Metodic_STO
{
    public class DPE_Sto_Output : DPEOutputSDABlock
    {
        List<Sto_Input> outputs = new List<Sto_Input>()
        {
            new Sto_Input("R101", 100),
            new Sto_Input("R102", 101),
            new Sto_Input("R103", 102),
            new Sto_Input("R104", 103),
            new Sto_Input("R105", 104),
            new Sto_Input("R106", 105),
            new Sto_Input("R107", 106),
            new Sto_Input("R108", 107),
            new Sto_Input("R109", 108),
            new Sto_Input("R100", 109),
            new Sto_Input("R111", 110),
            new Sto_Input("R112", 111),
            new Sto_Input("R113", 112),
            new Sto_Input("R114", 113),
            new Sto_Input("R115", 114),
            new Sto_Input("R116", 115),
            new Sto_Input("R117", 116),
            new Sto_Input("R118", 117),
        };

        public List<Sto_Input> Outputs
        {
            get { return outputs; }
            set { outputs = value; }
        }

        ILog logger;
        public override bool Init()
        {
            logger = log4net.LogManager.GetLogger(this.GetType());
            logger.InfoFormat("Init() start");
            for (int i = 0; i < this.Outputs.Count; i++)
            {
                logger.InfoFormat("Init() Add nodes[{0}] Scada_Tag ={1}, ID={2}", i, this.Outputs[i].Scada_Tag, this.Outputs[i].ID);
                this.SDATags.Add(new SDANode(this.Outputs[i].Scada_Tag, this.Outputs[i].ID));
            }
            logger.InfoFormat("Init() done");
            bool result = base.Init();
            logger.InfoFormat("Init() done base");
            return result;
        }
        public override bool Activate()
        {
            return base.Activate();
        }
        public override void Execute()
        {
            this.logger.DebugFormat("Execute()");
            base.Execute();
            this.logger.DebugFormat("Execute() done");
        }

    }
}
