﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_IO_Block;
using DPE_Interfaces;
using System.Xml.Serialization;

namespace CPE_Metodic_STO
{

    public class Sto_Input
    {
        public Sto_Input()
        {
        }

        public Sto_Input(string tag, int id)
        {
            this.scada_tag = tag;
            this.id = id;
        }

        private string scada_tag = "R0";
        public string Scada_Tag
        {
            get { return scada_tag; }
            set { scada_tag = value; }
        }

        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
    }

    public class DPE_Sto_Input : DPEInputSDABlock 
    {
        List<Sto_Input> inputs = new List<Sto_Input>()
        {
            new Sto_Input("R1", 0),
            new Sto_Input("R2", 1),
            new Sto_Input("R3", 2),
            new Sto_Input("R4", 3),
            new Sto_Input("R5", 4),
            new Sto_Input("R6", 5),
            new Sto_Input("R7", 6),
            new Sto_Input("R8", 7),
            new Sto_Input("R9", 8),
            new Sto_Input("R10", 9),
            new Sto_Input("R11", 10),
            new Sto_Input("R12", 11),
            new Sto_Input("R13", 12),
            new Sto_Input("R14", 13),
            new Sto_Input("R15", 14),
            new Sto_Input("R16", 15),
            new Sto_Input("R17", 16),
            new Sto_Input("R18", 17),

            //new Sto_Input("R19", 18),
            //new Sto_Input("R20", 19),
        };
        [XmlIgnore]
        public List<Sto_Input> Inputs
        {
            get { return inputs; }
            set { inputs = value; }
        }

        public Sto_Input T_Atm_C
        {
            get { return inputs[0]; }
            set { inputs[0] = value; }
        }

        //Атмосферное бараметрическое давление
        public Sto_Input P_Atm_kPa
        {
            get { return inputs[1]; }
            set { inputs[1] = value; }
        }

        //Скорость вращения ротора низкого давления (двухвальная машина) или ротора ГТУ (одновальная)
        public Sto_Input N_rot_nd_RPM
        {
            get { return inputs[2]; }
            set { inputs[2] = value; }
        }
        //Скорость вращения ротора высокого давления (двухвальная машина).К одновальным не применимо.
        public Sto_Input N_rot_vd_RPM
        {
            get { return inputs[3]; }
            set { inputs[3] = value; }
        }

        //Скорость вращения ротора нагнетателя
        public Sto_Input N_rot_nag_RPM
        {
            get { return inputs[4]; }
            set { inputs[4] = value; }
        }

        //Температура газа на входе нагнетателя
        public Sto_Input T_In_Nag_C
        {
            get { return inputs[5]; }
            set { inputs[5] = value; }
        }

        //Температура газа на выходе нагнетателя
        public Sto_Input T_Out_Nag_C
        {
            get { return inputs[6]; }
            set { inputs[6] = value; }
        }

        //Избыточное давление на входе нагнетателя
        public Sto_Input P_Over_In_Nag_MPa
        {
            get { return inputs[7]; }
            set { inputs[7] = value; }
        }

        //Избыточное давление на выходе нагнетателя
        public Sto_Input P_Over_Out_Nag_MPa
        {
            get { return inputs[8]; }
            set { inputs[8] = value; }
        }

        //Перепад давления на входном конфузоре ЦБН
        public Sto_Input dP_In_Conf_kPa
        {
            get { return inputs[9]; }
            set { inputs[9] = value; }
        }

        //Температура на входе в осевой компрессор (t3)
        public Sto_Input T_In_Os_Compr_C
        {
            get { return inputs[10]; }
            set { inputs[10] = value; }
        }

        //Расчетная температура за ГГ
        public Sto_Input T_Calc_Gg_C
        {
            get { return inputs[11]; }
            set { inputs[11] = value; }
        }

        //Расход топливного газа через ЦБН, взятый с САУ
        public Sto_Input dTg_Over_CBN_sau
        {
            get { return inputs[12]; }
            set { inputs[12] = value; }
        }
        //Температура топливного газа
        public Sto_Input T_TG_C
        {
            get { return inputs[13]; }
            set { inputs[13] = value; }
        }

        //Избыточное давление топливного газа
        public Sto_Input P_Tg_Flow_MPa
        {
            get { return inputs[14]; }
            set { inputs[14] = value; }
        }

        //Перепад давления на диафрагме топливного газа
        public Sto_Input dP_Diafr_Tg_kPa
        {
            get { return inputs[15]; }
            set { inputs[15] = value; }
        }

        //Расход топливного газа взятый с САУ
        public Sto_Input dTg_sau
        {
            get { return inputs[16]; }
            set { inputs[16] = value; }
        }

        //P воздуха за ОК
        public Sto_Input P_OK_MPa
        {
            get { return inputs[17]; }
            set { inputs[17] = value; }
        }

        ////Плотность газа 
        //public Sto_Input P_Gas
        //{
        //    get { return inputs[18]; }
        //    set { inputs[18] = value; }
        //}

        //Sto_Input nv_gas = new Sto_Input();
        ////Низшая объемная теплотворная харакеристика топливного газа
        //public Sto_Input NV_Gas
        //{
        //    get { return inputs[19]; }
        //    set { inputs[19] = value; }
        //}

        


        public override bool Init()
        {
            for (int i = 0; i < this.inputs.Count; i++)
            {
                this.SDATags.Add(new SDANode(this.inputs[i].Scada_Tag, this.inputs[i].ID));
            }
            return base.Init();
        }
        public override bool Activate()
        {
            return base.Activate();
        }
        public override void Execute()
        {
            base.Execute();
            // Make input correction for every input node...
            //for (int i = 0; i < this.inputs.Count; i++)
            //{
            //    DataNodeDouble data_node = (DataNodeDouble)this.Dpe.GetRegister(this.inputs[i].ID).Data.Data;
            //    data_node.DataDouble = data_node.DataDouble * this.inputs[i].A + this.inputs[i].B;
            //}
        }
    }
}
