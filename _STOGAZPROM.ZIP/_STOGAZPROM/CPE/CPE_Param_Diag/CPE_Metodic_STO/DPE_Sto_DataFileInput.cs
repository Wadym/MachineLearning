﻿using System;
using System.Collections.Generic;
using System.Text;
using GPA_Blocks;

namespace CPE_Metodic_STO
{
    public class DPE_Sto_DataFileInput: DPE_FileDataAccess
    {

    }
}
