﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CPE_Metodic_STO;
using System.Xml.Serialization;
using System.IO;
using CTO_ParamDiag_Cfg;
using DPE_Sto_Cfg_Loaders;
using CPE_CommonBlocks;
using SCADA_PD_View.TabPageMain;
using SCADA_PD_View.Modules;
using SCADA_PD_View.SampleInterfaces;

namespace CPE_Param_Diag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CPE_Metodic_STO_DPE cpe = new CPE_Metodic_STO_DPE();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DPE_Sto_Engine sto_engine = new DPE_Sto_Engine();
            sto_engine.Config();
            sto_engine.Init();
            sto_engine.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            List<Metodic> block_xml = new List<Metodic>();
            ConfigPage block = new ConfigPD();
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).STO.Shops.Add(new Shop_STO_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).STO.Shops[i].Agregates.Add(new Agregate_STO_Config());
                }
            }
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).DG90.Shops.Add(new Shop_DG90_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).DG90.Shops[i].Agregates.Add(new Agregate_DG90_Config());
                }
            }
            List<Type> block_types = block.GetTypes(new List<Type>());
            XmlSerializer xmlS = new XmlSerializer(block_xml.GetType(), block_types.ToArray());

            Stream fr = new FileStream(@".\DataFiles\Check_Config.xml", FileMode.Open);
            StreamReader reader = new StreamReader(fr);
            List<Metodic> chech = (List<Metodic>)xmlS.Deserialize(reader);
            reader.Close();

            FileStream fs_w = new FileStream("Methodics_Config.xml", FileMode.Create);
            StreamWriter writer = new StreamWriter(fs_w);
            xmlS.Serialize(writer, block_xml);
            writer.Close();




            for (int i = 0; i < chech.Count; i++)
            {
                Metodic metod = chech[i];
                if (metod is Metodic_GP_2_35_113_2007)
                {
                    Metodic_GP_2_35_113_2007 sto_metodic = metod as Metodic_GP_2_35_113_2007;
                    for (int k = 0; k < sto_metodic.Shops.Count; k++)
                    {
                        for (int m = 0; m < sto_metodic.Shops[k].Agregates.Count; m++)
                        {
                            DPE_Sto_Cfg_Loader loader = new DPE_Sto_Cfg_Loader();
                            DPE_Sto_FileInput file_input = new DPE_Sto_FileInput();
                            loader.Engine.Input = file_input;
                            loader.Engine.DPE.UpdateRate = 1;

                            for (int s = 0; s < 5; s++)
                            {
                                CPE_ChartView chart_view = new CPE_ChartView();
                                file_input.EndOfArray += chart_view.DrawEventHandler;
                                chart_view.Pos = s;
                                loader.Engine.CPE.CPE_Engine.Slice_Process.Add(chart_view);
                            }
                            loader.Config(sto_metodic.Common, (uint)sto_metodic.Shops[k].Shop_ID, (Agregate_STO_Config)sto_metodic.Shops[k].Agregates[m], @"c:\ASTD-2\Data\");

                            loader.Init();
                            loader.Start();
                        }
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            List<Metodic> block_xml = new List<Metodic>();
            ConfigPage block = new ConfigPD();
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).STO.Shops.Add(new Shop_STO_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).STO.Shops[i].Agregates.Add(new Agregate_STO_Config());
                }
            }
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).DG90.Shops.Add(new Shop_DG90_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).DG90.Shops[i].Agregates.Add(new Agregate_DG90_Config());
                }
            }
            List<Type> block_types = block.GetTypes(new List<Type>());
            XmlSerializer xmlS = new XmlSerializer(block_xml.GetType(), block_types.ToArray());

            Stream fr = new FileStream(@".\DataFiles\Check_Config.xml", FileMode.Open);
            StreamReader reader = new StreamReader(fr);
            List<Metodic> chech = (List<Metodic>)xmlS.Deserialize(reader);
            reader.Close();

            Type[] pages_types = new Type[] 
                { 
                    typeof(PD_TabPage_Cfg), 
                    typeof(PD_Control_Cfg),
                    typeof(ParameterShow_Cfg),
                    typeof(DataControlModule_Cfg),
                    typeof(ChartXY_Cfg),
                    typeof(UpdateDrawModule_Cfg),
                };

            List<PD_Control_Cfg> ddd = new List<PD_Control_Cfg>();
            XmlSerializer xmlS_pages = new XmlSerializer(ddd.GetType(), pages_types);

            Stream fr_page = new FileStream(@".\DataFiles\VCS_DPView.xml", FileMode.Open);
            StreamReader reader_page = new StreamReader(fr_page);
            List<PD_Control_Cfg> pages = (List<PD_Control_Cfg>)xmlS_pages.Deserialize(reader_page);
            reader_page.Close();


            for (int i = 0; i < chech.Count; i++)
            {
                Metodic metod = chech[i];
                if (metod is Metodic_GP_2_35_113_2007)
                {
                    Metodic_GP_2_35_113_2007 sto_metodic = metod as Metodic_GP_2_35_113_2007;
                    for (int k = 0; k < sto_metodic.Shops.Count; k++)
                    {
                        for (int m = 0; m < sto_metodic.Shops[k].Agregates.Count; m++)
                        {
                            VCS_Sto_Cfg_Loader vcs_loader = new VCS_Sto_Cfg_Loader();
                            vcs_loader.Config(sto_metodic, (uint)sto_metodic.Shops[k].Shop_ID, sto_metodic.Shops[k].Agregates[m], pages[0]);
                            //DPE_Sto_FileInput file_input = new DPE_Sto_FileInput();
                            //loader.Engin
                            //e.Input = file_input;
                            //loader.Engine.DPE.UpdateRate = 1;

                            //for (int s = 0; s < 5; s++)
                            //{
                            //    CPE_ChartView chart_view = new CPE_ChartView();
                            //    file_input.EndOfArray += chart_view.DrawEventHandler;
                            //    chart_view.Pos = s;
                            //    loader.Engine.CPE.CPE_Engine.Slice_Process.Add(chart_view);
                            //}
                            //loader.Config(sto_metodic.Common, (uint)sto_metodic.Shops[k].Shop_ID, sto_metodic.Shops[k].Agregates[m]);

                            //loader.Init();
                            //loader.Start();
                        }
                    }
                }
                if (metod is Metodic_DG90)
                {
                    Metodic_DG90 dg90_metodic = metod as Metodic_DG90;
                    for (int k = 0; k < dg90_metodic.Shops.Count; k++)
                    {
                        for (int m = 0; m < dg90_metodic.Shops[k].Agregates.Count; m++)
                        {
                            VCS_DG90_Cfg_Loader vcs_loader = new VCS_DG90_Cfg_Loader();
                            vcs_loader.Config(dg90_metodic, (uint)dg90_metodic.Shops[k].Shop_ID, dg90_metodic.Shops[k].Agregates[m], pages[0]);
                            //DPE_Sto_Cfg_Loader loader = new DPE_Sto_Cfg_Loader();
                            //DPE_Sto_FileInput file_input = new DPE_Sto_FileInput();
                            //loader.Engine.Input = file_input;
                            //loader.Engine.DPE.UpdateRate = 1;

                            //for (int s = 0; s < 5; s++)
                            //{
                            //    CPE_ChartView chart_view = new CPE_ChartView();
                            //    file_input.EndOfArray += chart_view.DrawEventHandler;
                            //    chart_view.Pos = s;
                            //    loader.Engine.CPE.CPE_Engine.Slice_Process.Add(chart_view);
                            //}
                            //loader.Config(sto_metodic.Common, (uint)sto_metodic.Shops[k].Shop_ID, sto_metodic.Shops[k].Agregates[m]);

                            //loader.Init();
                            //loader.Start();
                        }
                    }
                }
            }
            FileStream fs = new FileStream("Temp_PD_Config_main.xml", FileMode.Create);
            StreamWriter writer = new StreamWriter(fs);
            xmlS_pages.Serialize(writer, pages);
            writer.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            List<Metodic> block_xml = new List<Metodic>();
            ConfigPage block = new ConfigPD();
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).STO.Shops.Add(new Shop_STO_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).STO.Shops[i].Agregates.Add(new Agregate_STO_Config());
                }
            }
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).DG90.Shops.Add(new Shop_DG90_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).DG90.Shops[i].Agregates.Add(new Agregate_DG90_Config());
                }
            }
            List<Type> block_types = block.GetTypes(new List<Type>());
            XmlSerializer xmlS = new XmlSerializer(block_xml.GetType(), block_types.ToArray());

            Stream fr = new FileStream(@".\DataFiles\Check_Config.xml", FileMode.Open);
            StreamReader reader = new StreamReader(fr);
            List<Metodic> chech = (List<Metodic>)xmlS.Deserialize(reader);
            reader.Close();


            for (int i = 0; i < chech.Count; i++)
            {
                Metodic metod = chech[i];
                if (metod is Metodic_DG90)
                {
                    Metodic_DG90 dg90_metodic = metod as Metodic_DG90;
                    for (int k = 0; k < dg90_metodic.Shops.Count; k++)
                    {
                        for (int m = 0; m < dg90_metodic.Shops[k].Agregates.Count; m++)
                        {
                            DPE_DG90_Cfg_Loader loader = new DPE_DG90_Cfg_Loader();
                            DPE_Sto_FileInput file_input = new DPE_Sto_FileInput();
                            loader.Engine.Input = file_input;
                            loader.Engine.DPE.UpdateRate = 1;

                            for (int s = 0; s < 4; s++)
                            {
                                CPE_ChartView chart_view = new CPE_ChartView();
                                file_input.EndOfArray += chart_view.DrawEventHandler;
                                chart_view.Pos = s;
                                loader.Engine.CPE.CPE_Engine.Slice_Process.Add(chart_view);
                            }
                            loader.Config(dg90_metodic.Common, (uint)dg90_metodic.Shops[k].Shop_ID, (Agregate_DG90_Config)dg90_metodic.Shops[k].Agregates[m], @"c:\ASTD-2\Data\");

                            loader.Init();
                            loader.Start();
                        }
                    }

                }
            }
        }

    }
}
