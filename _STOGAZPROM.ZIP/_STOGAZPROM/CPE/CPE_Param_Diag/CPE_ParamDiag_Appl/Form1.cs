﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CTO_ParamDiag_Cfg;
using System.Xml.Serialization;
using System.IO;
using DPE_Sto_Cfg_Loaders;
using CPE_Metodic_STO;
using CPE_CommonBlocks;
using log4net;

namespace CPE_ParamDiag_Appl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            logg_config.LogConfigTextBox(this.richTextBox1);
            logger = LogManager.GetLogger(this.GetType());
            //this.splitContainer1.Panel2.Controls.Add(dp_logger);
            //this.FillLogLevels();
            this.openFileDialog1.RestoreDirectory = true;
            LogManager.GetRepository().Threshold = log4net.Core.Level.Debug;
        }

        ILog logger;
        Tehnekon.Logger_Config logg_config = new Tehnekon.Logger_Config();

        private void button2_Click(object sender, EventArgs e)
        {
            this.openFileDialog1.Filter = "XML Configuration Files: (*.xml)|*.xml|Все файлы (*.*)|*.*";
            if (this.openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox1.Text = this.openFileDialog1.FileName;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loaders.Clear();
            List<Metodic> block_xml = new List<Metodic>();
            ConfigPage block = new ConfigPD();
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).STO.Shops.Add(new Shop_STO_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).STO.Shops[i].Agregates.Add(new Agregate_STO_Config());
                }
            }
            for (int i = 0; i < 1; i++)
            {
                ((ConfigPD)block).DG90.Shops.Add(new Shop_DG90_Config());
                for (int k = 0; k < 2; k++)
                {
                    ((ConfigPD)block).DG90.Shops[i].Agregates.Add(new Agregate_DG90_Config());
                }
            }
            List<Type> block_types = block.GetTypes(new List<Type>());
            XmlSerializer xmlS = new XmlSerializer(block_xml.GetType(), block_types.ToArray());
            List<Metodic> metodics;
            try
            {
                Stream fr = new FileStream(this.textBox1.Text, FileMode.Open);
                StreamReader reader = new StreamReader(fr);
                metodics = (List<Metodic>)xmlS.Deserialize(reader);
                reader.Close();
            }
            catch (Exception ex)
            {

                return;
            }

            for (int i = 0; i < metodics.Count; i++)
            {
                Metodic metod = metodics[i];
                if (metod is Metodic_GP_2_35_113_2007)
                {
                    Metodic_GP_2_35_113_2007 sto_metodic = metod as Metodic_GP_2_35_113_2007;
                    for (int k = 0; k < sto_metodic.Shops.Count; k++)
                    {
                        for (int m = 0; m < sto_metodic.Shops[k].Agregates.Count; m++)
                        {
                            DPE_Sto_Cfg_Loader loader = new DPE_Sto_Cfg_Loader();
                            if (this.checkBox1.Checked)
                            {
                                DPE_Sto_FileInput file_input = new DPE_Sto_FileInput();
                                loader.Engine.Input = file_input;
                                loader.Engine.DPE.UpdateRate = 1;

                                for (int s = 0; s < 5; s++)
                                {
                                    CPE_ChartView chart_view = new CPE_ChartView();
                                    file_input.EndOfArray += chart_view.DrawEventHandler;
                                    chart_view.Pos = s;
                                    loader.Engine.CPE.CPE_Engine.Slice_Process.Add(chart_view);
                                }
                            }
                            else
                            {
                                // - Updaterate must read from system
                                loader.Engine.DPE.UpdateRate = 2000;
                            }
                            loader.Config(sto_metodic.Common, (uint)sto_metodic.Shops[k].Shop_ID, (Agregate_STO_Config)sto_metodic.Shops[k].Agregates[m], @"c:\ASTD-2\Data\");

                            loader.Init();
                            loader.Start();
                            loaders.Add(loader);
                        }
                    }
                }
            }
        }
        List<DPE_Sto_Cfg_Loader> loaders = new List<DPE_Sto_Cfg_Loader>();

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < loaders.Count; i++)
            {
                loaders[i].Stop();
            }
        }
    }
}
