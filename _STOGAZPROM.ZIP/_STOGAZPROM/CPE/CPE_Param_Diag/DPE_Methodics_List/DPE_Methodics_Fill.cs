﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using DPEMethodicTests;

namespace DPE_Methodics_List
{
    public class DPE_Methodics_Fill
    {
        public static void FillMethodics()
        {
            Dictionary<string, Type> avalible_methodics = CPE_Lib.CPE_Methodic.GetMethodics();
            avalible_methodics.Add("CPE_Methodic", typeof(CPE_Methodic));
            avalible_methodics.Add("TestMethodic1", typeof(TestMethodic1));
            avalible_methodics.Add("TestMethodic2", typeof(TestMethodic2));
            //avalible_methodics.Add("CPE_Methodic_STO", typeof(CPE_Methodic_STO));
        }
    }
}
