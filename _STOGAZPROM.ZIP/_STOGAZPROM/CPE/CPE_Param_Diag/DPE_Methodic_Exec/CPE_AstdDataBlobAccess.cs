﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Tehnekon.ASTD2.Sdko2PathesLib;

namespace CPE_Lib
{
    public class CPE_AstdDataBlobAccess : CPE_DataBlobAccess
    {
        public CPE_AstdDataBlobAccess(UInt32 shopID, UInt32 machineID, String nameMethodic)
        {
            m_ShopID = shopID;
            m_MachineID = machineID;
            m_NameMethodic = nameMethodic;
        }

        public override Stream GetStream(String id, FileMode mode)
        {
            // Имя файла. Для начала получим имя
            String fileName = Path.GetFileName(id);
            // Теперь сформируем имя с учетом идентификаторов
            fileName = String.Format("S{0}_Mach{1}_Meth{2}_id:{3}", m_ShopID, m_MachineID, m_NameMethodic, id);
            String fullFileName = Path.Combine(ScadaInstallInfoProvider.Info.Pathes.DataMethodicData, fileName);

            switch(mode)
            {
                case FileMode.Create:
                case FileMode.CreateNew:
                case FileMode.OpenOrCreate:
                    {
                        return new FileStream(fullFileName, mode);
                    }
                case FileMode.Append:
                case FileMode.Open:
                case FileMode.Truncate:
                    {
                        if (File.Exists(fullFileName))
                        {
                            return new FileStream(fullFileName, mode);
                        }

                        break;
                    }
            }

            return null;
        }

        /// <summary>Идентификатор цеха</summary>
        private UInt32 m_ShopID;
        /// <summary>Идентификатор агрегата</summary>
        private UInt32 m_MachineID;
        /// <summary>Наименование методики</summary>
        private String m_NameMethodic;
    }
}
