﻿using System;
using System.Collections.Generic;
using System.Text;
using DPE_Diag_Config;
using CPE_Lib;
using System.Xml;
using DPE_Methodics_List;

namespace DPE_Methodic_Execute
{
    class DPE_Methodic_Main
    {
        static void Main(string[] args)
        {
            string filename = @"Config\test_xml_001.xml";
            if (0 == args.Length)
            {
                Console.WriteLine("Please define the config file to load! Default will be used!");
            }
            else
            {
                filename = args[0];
            }
            DPE_Methodics_Fill.FillMethodics();

            Dictionary<string, Type> methodics = CPE_Methodic.GetMethodics();
            //methodics.Add("CPE_Methodic", typeof(CPE_Methodic));

            List<DPE_Methodic_Cfg> config = DPE_Methodic_Cfg.LoadMethodic(filename);
            for (int s = 0; s < config.Count; s++)
            {
                for (int i = 0; i < config[s].Tuning.Count; i++)
                {
                    for (int m = 0; m < config[s].Tuning[i].Agregates.Count; m++)
                    {
                        UInt32 shopID = config[s].Tuning[i].Shop_ID;
                        UInt32 machineID = config[s].Tuning[i].Agregates[m].ID;
                        String methodicName = config[s].Name;

                        DPE_Methodic_Engine.DPE_Methodic_Exec exec = new DPE_Methodic_Engine.DPE_Methodic_Exec();
                        exec.Inputs.Config(config[s].Common.Inputs.Scada_Tags);
                        exec.Inputs.ShopID = shopID;
                        exec.Inputs.MachineID = machineID;
                        exec.Methodic.Methodic = (CPE_Methodic)Activator.CreateInstance(methodics[methodicName]);//new CPE_Methodic();
                        exec.File_Access = new CPE_AstdDataBlobAccess(shopID, machineID, methodicName);
                        if (config[s].Tuning[i].Agregates[m].MethodicConfig == null)
                        {
                            XmlNode[] nodes = config[s].Common.Defaults as XmlNode[];
                            for (int n = 0; n < nodes.Length; n++)
                            {
                                if (nodes[i].Name == "MethodicConfig")
                                {
                                    Console.WriteLine("{0}", nodes[i].Name);
                                    string res = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                                    res += nodes[i].OuterXml;
                                    exec.Methodic.Methodic.Config(res, exec.File_Access);
                                }
                            }
                        }
                        else
                        {
                            XmlNode[] nodes = config[s].Tuning[i].Agregates[m].MethodicConfig as XmlNode[];
                            string res = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                            res += "<MethodicConfig>";
                            for (int n = 0; n < nodes.Length; n++)
                            {
                                res += nodes[n].OuterXml;
                            }
                            res += "</MethodicConfig>";
                            exec.Methodic.Methodic.Config(res, exec.File_Access);
                        }
                        exec.Outputs.Config(config[s].Common.Outputs.Scada_Tags);
                        exec.Outputs.ShopID = shopID;
                        exec.Outputs.MachineID = machineID;
                        exec.Config();

                        exec.Init();
                        exec.Activate();
                    }
                }
            }
        }
    }
}
