﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using SCADA_PD_View.TabPageMain;

namespace DPE_Sto_Cfg_Loaders
{
    public abstract class VCS_Cfg_Loader_Base
    {
        public abstract Boolean Config(Metodic methodicBase, UInt32 shop_id, ConfigPage agregate, PD_Control_Cfg cfg);
    }
}
