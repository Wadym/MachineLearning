﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using SCADA_PD_View.TabPageMain;
using SCADA_PD_View.Modules;
using GaspromGuidelines;
using log4net;

namespace DPE_Sto_Cfg_Loaders
{
    public class VCS_Sto_Cfg_Loader : VCS_Cfg_Loader_Base
    {
        public VCS_Sto_Cfg_Loader()
        {
            this.logger = log4net.LogManager.GetLogger(this.GetType());
        }
        ILog logger;
        public override Boolean Config(Metodic methodicBase, UInt32 shop_id, ConfigPage agregateBase, PD_Control_Cfg cfg)
        {
            Model_STO_Config common = ((Metodic_GP_2_35_113_2007)methodicBase).Common;
            Agregate_STO_Config agregate = (Agregate_STO_Config)agregateBase;

            bool result = true;
            // Read server name
            this.logger.DebugFormat("Config Begin");
            //cfg.ServerName = "localhost";
            //cfg.ServerPort = 4100;
            // Common settings
            cfg.Enabled = true;
            //cfg.ShopID = shop_id;
            //cfg.MachineID = (uint)agregate.Mashine_ID;
            // Param gas settings...
            //d:\ASTD-2\Data\ParamGas\ParamGas_70_1.xml
//            string param_gas_folder = @"c:\ASTD-2\Data";
//            cfg.ParamGas.FileName = string.Format("{0}\\ParamGas\\ParamGas_{1}_{2}.xml", param_gas_folder, shop_id, agregate.Mashine_ID);
            cfg.ParamGas.FileName = string.Format("ParamGas_{0}_{1}.xml", shop_id, agregate.Mashine_ID);
            cfg.ParamGas.DefaultRo0 = common.P_Gas.Default_Value;
            cfg.ParamGas.DefaultQn = common.NV_Gas.Default_Value;

            //cfg.Group1Name
            //cfg.Group1_Cfg
            //cfg.Group2Name
            //cfg.Group2_Cfg
            this.logger.DebugFormat("Config Update ParamGas done");

            // Data Module Settings
            cfg.DataModule.BeginDate = common.Views.BeginDate;
            cfg.DataModule.MaxArraySize = 2000000;
            cfg.DataModule.Read_Updaterate_in_s = 60;
            // cfg.DataModule.ParamDiagReaderConfig
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ServerName = cfg.ServerName;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ServerPort = cfg.ServerPort;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ShopID = cfg.ShopID;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.MachineID = cfg.MachineID;

            cfg.DataModule.Inputs.Clear();
            for (int i = 0; i < 21; i++)
            {
                cfg.DataModule.Inputs.Add(new BlockRead_Cfg());
            }
            cfg.DataModule.Inputs[0].SCADA_Tag = common.Outputs.h_pol_raschet;
            cfg.DataModule.Inputs[0].Array_ID = 0;
            cfg.DataModule.Inputs[1].SCADA_Tag = common.Outputs.h_pol_raschet_filtered;
            cfg.DataModule.Inputs[1].Array_ID = 1;
            cfg.DataModule.Inputs[2].SCADA_Tag = common.Outputs.KTS_CBN;
            cfg.DataModule.Inputs[2].Array_ID = 2;
            cfg.DataModule.Inputs[3].SCADA_Tag = common.Outputs.H_Pol_Rashet_Nom;
            cfg.DataModule.Inputs[3].Array_ID = 3;
            cfg.DataModule.Inputs[4].SCADA_Tag = common.Outputs.K_Regim_CBN;
            cfg.DataModule.Inputs[4].Array_ID = 4;
            cfg.DataModule.Inputs[5].SCADA_Tag = common.Outputs.Effective_KPD_GTU;
            cfg.DataModule.Inputs[5].Array_ID = 5;
            cfg.DataModule.Inputs[6].SCADA_Tag = common.Outputs.Effective_KPD_GGPA;
            cfg.DataModule.Inputs[6].Array_ID = 6;
            cfg.DataModule.Inputs[7].SCADA_Tag = common.Outputs.Calc_Power_T;
            cfg.DataModule.Inputs[7].Array_ID = 7;
            cfg.DataModule.Inputs[8].SCADA_Tag = common.Outputs.Calc_Power_T_Filtered;
            cfg.DataModule.Inputs[8].Array_ID = 8;
            cfg.DataModule.Inputs[9].SCADA_Tag = common.Outputs.Calc_Power_T_Nom;
            cfg.DataModule.Inputs[9].Array_ID = 9;
            cfg.DataModule.Inputs[10].SCADA_Tag = common.Outputs.Calc_Temperature;
            cfg.DataModule.Inputs[10].Array_ID = 10;
            cfg.DataModule.Inputs[11].SCADA_Tag = common.Outputs.Calc_Power_N;
            cfg.DataModule.Inputs[11].Array_ID = 11;
            cfg.DataModule.Inputs[12].SCADA_Tag = common.Outputs.Calc_Power_N_Filtered;
            cfg.DataModule.Inputs[12].Array_ID = 12;
            cfg.DataModule.Inputs[13].SCADA_Tag = common.Outputs.Calc_Power_N_Nom;
            cfg.DataModule.Inputs[13].Array_ID = 13;
            cfg.DataModule.Inputs[14].SCADA_Tag = common.Outputs.Calc_RPM_TVD;
            cfg.DataModule.Inputs[14].Array_ID = 14;
            cfg.DataModule.Inputs[15].SCADA_Tag = common.Outputs.Gas_Consumption;
            cfg.DataModule.Inputs[15].Array_ID = 15;
            cfg.DataModule.Inputs[16].SCADA_Tag = common.Outputs.Gas_Cons_Nom;
            cfg.DataModule.Inputs[16].Array_ID = 16;
            cfg.DataModule.Inputs[17].SCADA_Tag = common.Inputs.N_rot_vd_RPM.Scada_Tag;
            cfg.DataModule.Inputs[17].Array_ID = 17;
            cfg.DataModule.Inputs[18].SCADA_Tag = common.Outputs.KTS_GTU_Pow_T;
            cfg.DataModule.Inputs[18].Array_ID = 18;
            cfg.DataModule.Inputs[19].SCADA_Tag = common.Outputs.KTS_GTU_Pow_N;
            cfg.DataModule.Inputs[19].Array_ID = 19;
            cfg.DataModule.Inputs[20].SCADA_Tag = common.Outputs.KTS_GTU_Gas;
            cfg.DataModule.Inputs[20].Array_ID = 20;

            this.logger.DebugFormat("Config Update Inputs done");

            #region Common Values

            #endregion Common Values

            #region Page 1

            Config_Params1_STO params1 = common.Defaults.Parameters1;
            if (agregate.Parameters1.Initialized) params1 = agregate.Parameters1;
            Config_Params2_STO params2 = common.Defaults.Parameters2;
            if (agregate.Parameters2.Initialized) params2 = agregate.Parameters2;
            cfg.TabPages[0].Enabled = true;
            cfg.TabPages[0].ChartXY.MinX = common.Views.Page1.Min_X;
            cfg.TabPages[0].ChartXY.MaxX = common.Views.Page1.Max_X;
            cfg.TabPages[0].ChartXY.MinY = common.Views.Page1.Min_Y;
            cfg.TabPages[0].ChartXY.MaxY = common.Views.Page1.Max_Y;
            cfg.TabPages[0].ChartTimeY.MinY = common.Views.Page1.Min_Y;
            cfg.TabPages[0].ChartTimeY.MaxY = common.Views.Page1.Max_Y;

            cfg.DataModule.Histograms[0].Enabled = true;
            cfg.DataModule.Histograms[0].MinX = common.Views.Page1.Min_X;
            cfg.DataModule.Histograms[0].MaxX = common.Views.Page1.Max_X;

            int cc = cfg.TabPages[0].DrawModule.XY_Fixed[0].Data.Count;
            double step = (cfg.TabPages[0].ChartXY.MaxX - cfg.TabPages[0].ChartXY.MinX) / (double)(cc - 1);
            Config_Polynom_2D map_cs_poly = common.Defaults.Polynoms.CBN_Map_CS;
            if (agregate.Polynoms.CBN_Map_CS.Initialized) map_cs_poly = agregate.Polynoms.CBN_Map_CS;

            // TODO: здесь должна браться константа для синей точки...X
            double p1_diff = Point.pynomial1(map_cs_poly.Max_Point_X, map_cs_poly.A);
            cfg.TabPages[0].ChartXY.X_Cursors[0].X = map_cs_poly.Max_Point_X;
            //double p1_diff = Point.pynomial1(params2.Qr_CS_Min + step*((double)cc/2.0), map_cs_poly.A);

            // Optional..... может быть предустановлено...
            // Политропный КПД/Приведенный расход - точки и зеленый крестик
            // 
            //cfg.DataModule.XY_Converters[0].X = 15;
            //cfg.DataModule.XY_Converters[0].Y = 1;
            //cfg.DataModule.XY_Converters[0].Output = 100;

            // Политроный КПД приведенный к номиналу/Расох приведенный к номинальной мощности - зеоеная точка на графике
            cfg.DataModule.XY_Converters[1].Default_X = map_cs_poly.Max_Point_X;
            //cfg.DataModule.XY_Converters[1].Y = 3;
            //cfg.DataModule.XY_Converters[1].Output = 101;

            // Синяя точка на графике - пока нет...
            cfg.DataModule.XY_Converters[2].Default_X = map_cs_poly.Max_Point_X;
            cfg.DataModule.XY_Converters[2].Default_Y = Point.pynomial1(map_cs_poly.Max_Point_X, map_cs_poly.A); ;
            //cfg.DataModule.XY_Converters[2].Output = 102;

            
            
            for (int i = 0; i < cc; i++)
            {
                double x = cfg.TabPages[0].ChartXY.MinX + step * i;
                double y = Point.pynomial1(x, map_cs_poly.A);
                cfg.TabPages[0].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[0].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[0].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[0].DrawModule.XY_Fixed[1].Data[i].y = y - p1_diff * (1 - 0.95);

            }
            //cfg.TabPages[0].DrawModule.XY_Fixed[0];
            #endregion //Page 1

            #region Page 2
            cfg.TabPages[1].Enabled = true;
            cfg.TabPages[1].ChartXY.MinX = common.Views.Page2.Min_X;
            cfg.TabPages[1].ChartXY.MaxX = common.Views.Page2.Max_X;
            cfg.TabPages[1].ChartXY.MinY = common.Views.Page2.Min_Y;
            cfg.TabPages[1].ChartXY.MaxY = common.Views.Page2.Max_Y;

            int cc_2 = cfg.TabPages[1].DrawModule.XY_Fixed[0].Data.Count;
            double step_2 = (cfg.TabPages[1].ChartXY.MaxX - cfg.TabPages[1].ChartXY.MinX) / (double)(cc_2 - 1);
            Config_Polynom map_GT_T2N = common.Defaults.Polynoms.map_GT_T2N;
            if (agregate.Polynoms.map_GT_T2N.Initialized) map_GT_T2N = agregate.Polynoms.map_GT_T2N;

            // TODO: здесь должна браться константа для синей точки... X
            double t_def = Point.pynomial1(params2.t_tnd_Min, map_GT_T2N.A);
            double step_def = (params2.t_tnd_Max - params2.t_tnd_Min) / 100;
            for (int i = 0; i < 100; i++)
            {
                t_def = params2.t_tnd_Min + step_def*i;
                double power = Point.pynomial1(t_def, map_GT_T2N.A);
                if (power >= params1.P_Nom_MVt)
                {
                    break;
                }
            }

            // Page 2 - серые точки и зеленый крестик
            //cfg.DataModule.XY_Converters[3].X = 10;
            //cfg.DataModule.XY_Converters[3].Y = 8;
            //cfg.DataModule.XY_Converters[3].Output = 103;

            // Page 2 - Зеленая точка, мощность приведенная к номиналу
            cfg.DataModule.XY_Converters[4].Default_X = t_def;
            //cfg.DataModule.XY_Converters[4].Y = 9;
            //cfg.DataModule.XY_Converters[4].Output = 104;

            // Page 2 - синяя точка
            cfg.DataModule.XY_Converters[5].Default_X = t_def;
            cfg.DataModule.XY_Converters[5].Default_Y = params1.P_Nom_MVt;
            //cfg.DataModule.XY_Converters[5].Output = 105;

            double p2_diff = Point.pynomial1(t_def, map_GT_T2N.A);
            for (int i = 0; i < cc_2; i++)
            {
                double x = cfg.TabPages[1].ChartXY.MinX + step_2 * i;
                double y = Point.pynomial1(x, map_GT_T2N.A);

                cfg.TabPages[1].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[1].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[1].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[1].DrawModule.XY_Fixed[1].Data[i].y = y - p2_diff * (1 - 0.95);
            }

            #endregion // Page 2
            
            #region Page 3
            cfg.TabPages[2].Enabled = true;
            cfg.TabPages[2].ChartXY.MinX = common.Views.Page3.Min_X;
            cfg.TabPages[2].ChartXY.MaxX = common.Views.Page3.Max_X;
            cfg.TabPages[2].ChartXY.MinY = common.Views.Page3.Min_Y;
            cfg.TabPages[2].ChartXY.MaxY = common.Views.Page3.Max_Y;

            int cc_3 = cfg.TabPages[2].DrawModule.XY_Fixed[0].Data.Count;
            double step_3 = (cfg.TabPages[2].ChartXY.MaxX - cfg.TabPages[2].ChartXY.MinX) / (double)(cc_3 - 1);
            Config_Polynom map_GT_n2N = common.Defaults.Polynoms.map_GT_n2N;
            if (agregate.Polynoms.map_GT_n2N.Initialized) map_GT_n2N = agregate.Polynoms.map_GT_n2N;

            // TODO: здесь должна браться константа для синей точки... X
            double step_n_def = (params2.n_vd_Max - params2.n_vd_Min) / 100;
            double n_deff = Point.pynomial1(params2.n_vd_Min, map_GT_n2N.A);
            for (int i = 0; i < 100; i++)
            {
                n_deff = params2.n_vd_Min + step_n_def * i;
                double power = Point.pynomial1(n_deff, map_GT_n2N.A);
                if (power > params1.P_Nom_MVt)
                {
                    break;
                }
            }
            double p3_diff = Point.pynomial1(n_deff, map_GT_n2N.A);

            // Page 3 - серые точки и зеленый крестик, приведенная мощность к оборотам от оборотов
            //cfg.DataModule.XY_Converters[6].X = 14; 
            //cfg.DataModule.XY_Converters[6].Y = 12;
            //cfg.DataModule.XY_Converters[6].Output = 106;

            // Page 3 - Зеленая точка, мощность приведенная к номиналу
            cfg.DataModule.XY_Converters[7].Default_X = n_deff;
            //cfg.DataModule.XY_Converters[7].Y = 13;
            //cfg.DataModule.XY_Converters[7].Output = 107;

            // Page 3 - синяя точка
            cfg.DataModule.XY_Converters[8].Default_X = n_deff;
            cfg.DataModule.XY_Converters[8].Default_Y = params1.P_Nom_MVt;
            //cfg.DataModule.XY_Converters[8].Output = 108;

            for (int i = 0; i < cc_3; i++)
            {
                double x = cfg.TabPages[2].ChartXY.MinX + step_3 * i;
                double y = Point.pynomial1(x, map_GT_n2N.A);

                cfg.TabPages[2].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[2].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[2].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[2].DrawModule.XY_Fixed[1].Data[i].y = y - p3_diff * (1 - 0.95);
            }
            #endregion // Page 3

            #region Page 4
            cfg.TabPages[3].Enabled = true;
            cfg.TabPages[3].ChartXY.MinX = common.Views.Page4.Min_X;
            cfg.TabPages[3].ChartXY.MaxX = common.Views.Page4.Max_X;
            cfg.TabPages[3].ChartXY.MinY = common.Views.Page4.Min_Y;
            cfg.TabPages[3].ChartXY.MaxY = common.Views.Page4.Max_Y;

            int cc_4 = cfg.TabPages[2].DrawModule.XY_Fixed[0].Data.Count;
            double step_4 = (cfg.TabPages[3].ChartXY.MaxX - cfg.TabPages[3].ChartXY.MinX) / (double)(cc_4 - 1);
            Config_Polynom map_GT_N2F = common.Defaults.Polynoms.map_GT_N2F;
            if (agregate.Polynoms.map_GT_N2F.Initialized) map_GT_N2F = agregate.Polynoms.map_GT_N2F;

            double p4_diff = Point.pynomial1(params1.P_Nom_MVt, map_GT_N2F.A);

            // Page 4 - серые точки и зеленый крестик, приведенный расход к приведенной мощности
            //cfg.DataModule.XY_Converters[9].X = 8;
            //cfg.DataModule.XY_Converters[9].Y = 15;
            //cfg.DataModule.XY_Converters[9].Output = 109;

            // Page 4 - Зеленая точка, мощность приведенная к номиналу
            cfg.DataModule.XY_Converters[10].Default_X = params1.P_Nom_MVt;
            //cfg.DataModule.XY_Converters[10].Y = 16;
            cfg.DataModule.XY_Converters[10].Output = 110;

            // Page 4 - синяя точка
            cfg.DataModule.XY_Converters[11].Default_X = params1.P_Nom_MVt;
            cfg.DataModule.XY_Converters[11].Default_Y = p4_diff;
            cfg.DataModule.XY_Converters[11].Output = 111;

            for (int i = 0; i < cc_4; i++)
            {
                double x = cfg.TabPages[3].ChartXY.MinX + step_4 * i;
                double y = Point.pynomial1(x, map_GT_N2F.A);

                cfg.TabPages[3].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[3].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[3].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[3].DrawModule.XY_Fixed[1].Data[i].y = y + p4_diff * (1 - 0.95);
            }
            for (int i = 0; i < 12; i++)
            {
                cfg.DataModule.XY_Converters[i].Enabled = true;
            }
            #endregion // Page 3
            return result;
        }
    }
}
