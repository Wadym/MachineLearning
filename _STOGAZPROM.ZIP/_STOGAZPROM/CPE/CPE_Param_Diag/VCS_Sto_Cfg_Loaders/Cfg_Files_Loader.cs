﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using System.Xml.Serialization;
using System.IO;
using SCADA_PD_View.TabPageMain;
using SCADA_PD_View.Modules;
using SCADA_PD_View.SampleInterfaces;
using log4net;

namespace DPE_Sto_Cfg_Loaders
{
    public class Cfg_Files_Loader
    {
        private static Type[] GetTypesForMetodics()
        {
            Type[] types = new Type[] 
                { 

                    typeof(Metodic),
                    typeof(ConfigPage),
                    typeof(ConfigPD),
                    typeof(Shop_STO_Config),
                    typeof(Agregate_STO_Config),
                    typeof(Shop_DG90_Config),
                    typeof(Agregate_DG90_Config)
                };

            return types;
        }
        
        public static List<Metodic> GetMethodics(string filename)
        {
            try
            {
                XmlSerializer xmlS = new XmlSerializer(typeof(List<Metodic>), GetTypesForMetodics());

                List<Metodic> result = null;
                using (Stream fr = new FileStream(filename, FileMode.Open))
                {
                    using (StreamReader reader = new StreamReader(fr))
                    {
                        result = (List<Metodic>)xmlS.Deserialize(reader);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                ILog logger = log4net.LogManager.GetLogger(typeof(Cfg_Files_Loader).ToString());
                logger.ErrorFormat("Сбой при разборе файла конфигурации методик. Exception = {0}", ex);
                throw ex;
            }
        }

        public static List<Metodic> GetMethodics(Byte[] data)
        {
            try
            {
                XmlSerializer xmlS = new XmlSerializer(typeof(List<Metodic>), GetTypesForMetodics());

                List<Metodic> result = null;
                using (MemoryStream metodics = new MemoryStream(data))
                {
                    using (StreamReader reader = new StreamReader(metodics))
                    {
                        result = (List<Metodic>)xmlS.Deserialize(reader);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                ILog logger = log4net.LogManager.GetLogger(typeof(Cfg_Files_Loader).ToString());
                logger.ErrorFormat("Сбой при разборе файла конфигурации методик. Exception = {0}", ex);
                throw ex;
            }
        }

        public static List<PD_Control_Cfg> LoadPages(string filename)
        {
            Type[] pages_types = new Type[] 
                { 
                    typeof(PD_TabPage_Cfg), 
                    typeof(PD_Control_Cfg),
                    typeof(ParameterShow_Cfg),
                    typeof(DataControlModule_Cfg),
                    typeof(ChartXY_Cfg),
                    typeof(UpdateDrawModule_Cfg),
                };

            List<PD_Control_Cfg> ddd = new List<PD_Control_Cfg>();
            XmlSerializer xmlS_pages = new XmlSerializer(ddd.GetType(), pages_types);

            Stream fr_page = new FileStream(filename, FileMode.Open);
            StreamReader reader_page = new StreamReader(fr_page);
            List<PD_Control_Cfg> result = (List<PD_Control_Cfg>)xmlS_pages.Deserialize(reader_page);
            reader_page.Close();
            return result;
        }
    }
}
