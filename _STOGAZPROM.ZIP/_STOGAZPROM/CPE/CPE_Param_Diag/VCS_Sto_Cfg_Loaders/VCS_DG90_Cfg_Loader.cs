﻿using System;
using System.Collections.Generic;
using System.Text;
using CTO_ParamDiag_Cfg;
using SCADA_PD_View.TabPageMain;
using SCADA_PD_View.Modules;
using GaspromGuidelines;
using log4net;

namespace DPE_Sto_Cfg_Loaders
{
    public class VCS_DG90_Cfg_Loader : VCS_Cfg_Loader_Base
    {
        public VCS_DG90_Cfg_Loader()
        {
            this.logger = log4net.LogManager.GetLogger(this.GetType());
        }
        ILog logger;
        public override Boolean Config(Metodic methodicBase, UInt32 shop_id, ConfigPage agregateBase, PD_Control_Cfg cfg)
        {
            Model_DG90_Config common = ((Metodic_DG90)methodicBase).Common;
            Agregate_DG90_Config agregate = (Agregate_DG90_Config)agregateBase;

            bool result = true;
            this.logger.DebugFormat("Config begin!");
            // Read server name
            cfg.Enabled = true;
            cfg.ServerName = "localhost";
            cfg.ServerPort = 4100;
            // Common settings
            cfg.Enabled = true;
            cfg.ShopID = shop_id;
            cfg.MachineID = (uint)agregate.Mashine_ID;
            // Param gas settings...
            //d:\ASTD-2\Data\ParamGas\ParamGas_70_1.xml
            //string param_gas_folder = @"c:\ASTD-2\Data";
            //cfg.ParamGas.FileName = string.Format("{0}\\ParamGas\\ParamGas_{1}_{2}.xml",param_gas_folder, shop_id, agregate.Mashine_ID);
            //cfg.ParamGas.DefaultRo0 = common.P_Gas.Default_Value;
            //cfg.ParamGas.DefaultQn = common.NV_Gas.Default_Value;
            cfg.ParamGas.FileName = string.Format("ParamGas_{0}_{1}.xml", shop_id, agregate.Mashine_ID);
            cfg.ParamGas.DefaultRo0 = common.P_Gas.Default_Value;
            cfg.ParamGas.DefaultQn = common.NV_Gas.Default_Value;

            //cfg.Group1Name
            //cfg.Group1_Cfg
            //cfg.Group2Name
            //cfg.Group2_Cfg

            // Data Module Settings
            cfg.DataModule.BeginDate = common.Views.BeginDate;
            cfg.DataModule.MaxArraySize = 2000000;
            cfg.DataModule.Read_Updaterate_in_s = 60;
            // cfg.DataModule.ParamDiagReaderConfig
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ServerName = cfg.ServerName;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ServerPort = cfg.ServerPort;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.ShopID = cfg.ShopID;
            cfg.DataModule.ParamDiagReaderConfig.ReaderConfig.MachineID = cfg.MachineID;

            //cfg.DataModule.Inputs.Clear();
            int count_inputs = cfg.DataModule.Inputs.Count;
            for (int i = 0; i < 3; i++)
            {
                cfg.DataModule.Inputs.Add(new BlockRead_Cfg());
            }
            cfg.DataModule.Inputs[count_inputs + 0].SCADA_Tag = common.Outputs.DeviationTemp;
            cfg.DataModule.Inputs[count_inputs + 0].Array_ID = 21;
            cfg.DataModule.Inputs[count_inputs + 1].SCADA_Tag = common.Outputs.DeviationRotation;
            cfg.DataModule.Inputs[count_inputs + 1].Array_ID = 22;
            cfg.DataModule.Inputs[count_inputs + 2].SCADA_Tag = common.Outputs.DeviationPressure;
            cfg.DataModule.Inputs[count_inputs + 2].Array_ID = 23;

            #region Common Values
            int count_xy = cfg.DataModule.XY_Converters.Count;
            for (int i = 0; i < 3; i++)
            {
                cfg.DataModule.XY_Converters.Add(new XY_Converter_Cfg());
            }
            // Температура от оборотов
            cfg.DataModule.XY_Converters[count_xy + 0].Enabled = true;
            cfg.DataModule.XY_Converters[count_xy + 0].X = 14; // Calc_RPM_TVD
            cfg.DataModule.XY_Converters[count_xy + 0].Y = 21; // DeviationTemp
            cfg.DataModule.XY_Converters[count_xy + 0].Output = 121;
            // Обороты от оборотов
            cfg.DataModule.XY_Converters[count_xy + 1].Enabled = true;
            cfg.DataModule.XY_Converters[count_xy + 1].X = 14; // Calc_RPM_TVD
            cfg.DataModule.XY_Converters[count_xy + 1].Y = 22; // DeviationRotation
            cfg.DataModule.XY_Converters[count_xy + 1].Output = 122;
            // Давление от оборотов
            cfg.DataModule.XY_Converters[count_xy + 2].Enabled = true;
            cfg.DataModule.XY_Converters[count_xy + 2].X = 14; // Calc_RPM_TVD
            cfg.DataModule.XY_Converters[count_xy + 2].Y = 23; // DeviationPressure
            cfg.DataModule.XY_Converters[count_xy + 2].Output = 123;
            
            #endregion Common Values

            Config_Params1_STO params1 = common.Defaults.Parameters1;
            if (agregate.Parameters1.Initialized) params1 = agregate.Parameters1;
            Config_Params2_STO params2 = common.Defaults.Parameters2;
            if (agregate.Parameters2.Initialized) params2 = agregate.Parameters2;

            Config_Params_DG_90 parameters = common.Defaults.Parameters;
            if (agregate.Parameters.Initialized) parameters = agregate.Parameters;

            #region Page 1

            cfg.TabPages[4].Enabled = true;
            cfg.TabPages[4].ChartXY.MinX = common.Views.Page1.Min_X;
            cfg.TabPages[4].ChartXY.MaxX = common.Views.Page1.Max_X;
            cfg.TabPages[4].ChartXY.MinY = common.Views.Page1.Min_Y;
            cfg.TabPages[4].ChartXY.MaxY = common.Views.Page1.Max_Y;

            cfg.DataModule.Histograms[1].Enabled = true;
            cfg.DataModule.Histograms[1].Input = 121;
            cfg.DataModule.Histograms[1].Output = 221;
            cfg.DataModule.Histograms[1].MinX = common.Views.Page1.Min_X;
            cfg.DataModule.Histograms[1].MaxX = common.Views.Page1.Max_X;

            int cc = cfg.TabPages[4].DrawModule.XY_Fixed[0].Data.Count;

            double step = (cfg.TabPages[4].ChartXY.MaxX - cfg.TabPages[4].ChartXY.MinX) / (double)(cc - 1);

            Config_Polynom mapGT_n2t = common.Defaults.Polynoms.mapGT_n2t;
            if (agregate.Polynoms.mapGT_n2t.Initialized) mapGT_n2t = agregate.Polynoms.mapGT_n2t;

            // TODO: здесь должна браться константа для синей точки...X
            double p1_diff = Point.pynomial1(cfg.TabPages[4].ChartXY.MinX + (cfg.TabPages[4].ChartXY.MaxX - cfg.TabPages[4].ChartXY.MinX) / 2, mapGT_n2t.A);

            for (int i = 0; i < cc; i++)
            {
                double x = cfg.TabPages[4].ChartXY.MinX + step * i;
                double y = Point.pynomial1(x, mapGT_n2t.A);
                cfg.TabPages[4].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[4].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[4].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[4].DrawModule.XY_Fixed[1].Data[i].y = y - p1_diff * (1 - 0.9);

                cfg.TabPages[4].DrawModule.XY_Fixed[2].Data[i].x = x;
                cfg.TabPages[4].DrawModule.XY_Fixed[2].Data[i].y = y + p1_diff * (1 - 0.9);
            }
            #endregion //Page 1

            #region Page 2

            cfg.TabPages[5].Enabled = true;
            cfg.TabPages[5].ChartXY.MinX = common.Views.Page2.Min_X;
            cfg.TabPages[5].ChartXY.MaxX = common.Views.Page2.Max_X;
            cfg.TabPages[5].ChartXY.MinY = common.Views.Page2.Min_Y;
            cfg.TabPages[5].ChartXY.MaxY = common.Views.Page2.Max_Y;


            //cfg.DataModule.Histograms[2].Input = 122;
            //cfg.DataModule.Histograms[2].Output = 222;
            cfg.DataModule.Histograms[2].Enabled = true;
            cfg.DataModule.Histograms[2].MinX = common.Views.Page2.Min_X;
            cfg.DataModule.Histograms[2].MaxX = common.Views.Page2.Max_X;



            Config_Polynom mapGT_n2n = common.Defaults.Polynoms.mapGT_n2n;
            if (agregate.Polynoms.mapGT_n2n.Initialized) mapGT_n2n = agregate.Polynoms.mapGT_n2n;

            // TODO: здесь должна браться константа для синей точки...X
            double p2_diff = Point.pynomial1(cfg.TabPages[5].ChartXY.MinX + (cfg.TabPages[5].ChartXY.MaxX - cfg.TabPages[5].ChartXY.MinX) / 2, mapGT_n2n.A);
            for (int i = 0; i < cc; i++)
            {
                double x = cfg.TabPages[5].ChartXY.MinX + step * i;
                double y = Point.pynomial1(x, mapGT_n2n.A);
                cfg.TabPages[5].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[5].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[5].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[5].DrawModule.XY_Fixed[1].Data[i].y = y - p2_diff * (1 - 0.9);

                cfg.TabPages[5].DrawModule.XY_Fixed[2].Data[i].x = x;
                cfg.TabPages[5].DrawModule.XY_Fixed[2].Data[i].y = y + p2_diff * (1 - 0.9);
            }
            #endregion //Page 2

            #region Page 3

            cfg.TabPages[6].Enabled = true;
            cfg.TabPages[6].ChartXY.MinX = common.Views.Page3.Min_X;
            cfg.TabPages[6].ChartXY.MaxX = common.Views.Page3.Max_X;
            cfg.TabPages[6].ChartXY.MinY = common.Views.Page3.Min_Y;
            cfg.TabPages[6].ChartXY.MaxY = common.Views.Page3.Max_Y;


            //cfg.DataModule.Histograms[2].Input = 122;
            //cfg.DataModule.Histograms[2].Output = 222;
            cfg.DataModule.Histograms[3].Enabled = true;
            cfg.DataModule.Histograms[3].MinX = common.Views.Page3.Min_X;
            cfg.DataModule.Histograms[3].MaxX = common.Views.Page3.Max_X;

            Config_Polynom mapGT_n2p = common.Defaults.Polynoms.mapGT_n2p;
            if (agregate.Polynoms.mapGT_n2p.Initialized) mapGT_n2p = agregate.Polynoms.mapGT_n2p;

            // TODO: здесь должна браться константа для синей точки...X
            double p3_diff = Point.pynomial1(cfg.TabPages[6].ChartXY.MinX + (cfg.TabPages[6].ChartXY.MaxX - cfg.TabPages[6].ChartXY.MinX) / 2, mapGT_n2p.A);

            for (int i = 0; i < cc; i++)
            {
                double x = cfg.TabPages[6].ChartXY.MinX + step * i;
                double y = Point.pynomial1(x, mapGT_n2p.A);
                cfg.TabPages[6].DrawModule.XY_Fixed[0].Data[i].x = x;
                cfg.TabPages[6].DrawModule.XY_Fixed[0].Data[i].y = y;

                cfg.TabPages[6].DrawModule.XY_Fixed[1].Data[i].x = x;
                cfg.TabPages[6].DrawModule.XY_Fixed[1].Data[i].y = y - p3_diff * (1 - 0.9);

                cfg.TabPages[6].DrawModule.XY_Fixed[2].Data[i].x = x;
                cfg.TabPages[6].DrawModule.XY_Fixed[2].Data[i].y = y + p3_diff * (1 - 0.9);
            }
            #endregion //Page 3
            
            return result;
        }
    }
}
