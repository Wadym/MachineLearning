﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace DPE_Diag_Config
{
    public class DPE_Methodic_Cfg
    {

        private string log_level = "ERROR";
        public string LogLevel
        {
            get { return log_level; }
            set { log_level = value; }
        }

        private string name = "";

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int asset_model_id = -1;
        public int AssetModelID
        {
            get { return asset_model_id; }
            set { asset_model_id = value; }
        }

        private DPE_Methodic_Common_Cfg common = new DPE_Methodic_Common_Cfg();
        public DPE_Methodic_Common_Cfg Common
        {
            get { return common; }
            set { common = value; }
        }

        private List<DPE_Methodic_Shop> tuning = new List<DPE_Methodic_Shop>();
        //[XmlElement("Shop")]
        [XmlArrayItem("Shop")]
        public List<DPE_Methodic_Shop> Tuning
        {
            get { return this.tuning; }
            set { this.tuning = value; }
        }

        public static List<DPE_Methodic_Cfg> LoadMethodic(string filename)
        {
            List<DPE_Methodic_Cfg> result = null;

            List<Type> types = new List<Type>();
            types.Add(typeof(DPE_Methodic_Cfg));
            types.Add(typeof(DPE_Defaults_Cfg));
            types.Add(typeof(DPE_Methodic_Common_Cfg));
            types.Add(typeof(DPE_Methodic_InOut));
            types.Add(typeof(DPE_View_Config));
            
            XmlSerializer xmlS = new XmlSerializer(typeof(List<DPE_Methodic_Cfg>), types.ToArray());

            using (Stream fr = new FileStream(filename, FileMode.Open))
            {
                using (StreamReader reader = new StreamReader(fr))
                {
                    result = (List<DPE_Methodic_Cfg>)xmlS.Deserialize(reader);
                }
            }

            return result;

        }

    }
}
