﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace DPE_Diag_Config
{
    public class DPE_Methodic_Common_Cfg
    {
        private DPE_Methodic_InOut inputs = new DPE_Methodic_InOut();
        public DPE_Methodic_InOut Inputs
        {
            get { return inputs; }
            set { inputs = value; }
        }

        private DPE_Methodic_InOut outputs= new DPE_Methodic_InOut();
        public DPE_Methodic_InOut Outputs
        {
            get { return outputs; }
            set { outputs = value; }
        }
        private DateTime begin_date = new DateTime(2015,01,01);
        public DateTime BeginDate
        {
            get { return begin_date; }
            set { begin_date = value; }
        }

        private List<DPE_View_Config> views = new List<DPE_View_Config>();
        [XmlArrayItem("Page")]
        public List<DPE_View_Config> Views
        {
            get { return views; }
            set { views = value; }
        }

        private object defaults = new object();

        public object Defaults
        {
            get { return defaults; }
            set { defaults = value; }
        }
    }
}
