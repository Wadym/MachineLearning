﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace DPE_Diag_Config
{
    public class DPE_Methodic_InOut
    {
        public DPE_Methodic_InOut()
        {
            for (int i = 0; i < this.scada_tags.Length; i++)
            {
                this.scada_tags[i] = string.Empty;
            }
        }

        private string[] scada_tags = new string[100];
        [XmlIgnore]
        public string[] Scada_Tags
        {
            get { return scada_tags; }
            set { scada_tags = value; }
        }

        public string Scada_Tag0
        {
            get { return this.scada_tags[0]; }
            set { this.scada_tags[0] = value; }
        }
        public string Scada_Tag1
        {
            get { return this.scada_tags[1]; }
            set { this.scada_tags[1] = value; }
        }
        public string Scada_Tag2
        {
            get { return this.scada_tags[2]; }
            set { this.scada_tags[2] = value; }
        }
        public string Scada_Tag3
        {
            get { return this.scada_tags[3]; }
            set { this.scada_tags[3] = value; }
        }
        public string Scada_Tag4
        {
            get { return this.scada_tags[4]; }
            set { this.scada_tags[4] = value; }
        }
        public string Scada_Tag5
        {
            get { return this.scada_tags[5]; }
            set { this.scada_tags[5] = value; }
        }
        public string Scada_Tag6
        {
            get { return this.scada_tags[6]; }
            set { this.scada_tags[6] = value; }
        }
        public string Scada_Tag7
        {
            get { return this.scada_tags[7]; }
            set { this.scada_tags[7] = value; }
        }
        public string Scada_Tag8
        {
            get { return this.scada_tags[8]; }
            set { this.scada_tags[8] = value; }
        }
        public string Scada_Tag9
        {
            get { return this.scada_tags[9]; }
            set { this.scada_tags[9] = value; }
        }
        public string Scada_Tag10
        {
            get { return this.scada_tags[10]; }
            set { this.scada_tags[10] = value; }
        }
        public string Scada_Tag11
        {
            get { return this.scada_tags[11]; }
            set { this.scada_tags[11] = value; }
        }
        public string Scada_Tag12
        {
            get { return this.scada_tags[12]; }
            set { this.scada_tags[12] = value; }
        }
        public string Scada_Tag13
        {
            get { return this.scada_tags[13]; }
            set { this.scada_tags[13] = value; }
        }
        public string Scada_Tag14
        {
            get { return this.scada_tags[14]; }
            set { this.scada_tags[14] = value; }
        }
        public string Scada_Tag15
        {
            get { return this.scada_tags[15]; }
            set { this.scada_tags[15] = value; }
        }
        public string Scada_Tag16
        {
            get { return this.scada_tags[16]; }
            set { this.scada_tags[16] = value; }
        }
        public string Scada_Tag17
        {
            get { return this.scada_tags[17]; }
            set { this.scada_tags[17] = value; }
        }
        public string Scada_Tag18
        {
            get { return this.scada_tags[18]; }
            set { this.scada_tags[18] = value; }
        }
        public string Scada_Tag19
        {
            get { return this.scada_tags[19]; }
            set { this.scada_tags[19] = value; }
        }
        public string Scada_Tag20
        {
            get { return this.scada_tags[20]; }
            set { this.scada_tags[20] = value; }
        }
        public string Scada_Tag21
        {
            get { return this.scada_tags[21]; }
            set { this.scada_tags[21] = value; }
        }
        public string Scada_Tag22
        {
            get { return this.scada_tags[22]; }
            set { this.scada_tags[22] = value; }
        }
        public string Scada_Tag23
        {
            get { return this.scada_tags[23]; }
            set { this.scada_tags[23] = value; }
        }
        public string Scada_Tag24
        {
            get { return this.scada_tags[24]; }
            set { this.scada_tags[24] = value; }
        }
        public string Scada_Tag25
        {
            get { return this.scada_tags[25]; }
            set { this.scada_tags[25] = value; }
        }
        public string Scada_Tag26
        {
            get { return this.scada_tags[26]; }
            set { this.scada_tags[26] = value; }
        }
        public string Scada_Tag27
        {
            get { return this.scada_tags[27]; }
            set { this.scada_tags[27] = value; }
        }
        public string Scada_Tag28
        {
            get { return this.scada_tags[28]; }
            set { this.scada_tags[28] = value; }
        }
        public string Scada_Tag29
        {
            get { return this.scada_tags[29]; }
            set { this.scada_tags[29] = value; }
        }
        public string Scada_Tag30
        {
            get { return this.scada_tags[30]; }
            set { this.scada_tags[30] = value; }
        }
        public string Scada_Tag31
        {
            get { return this.scada_tags[31]; }
            set { this.scada_tags[31] = value; }
        }
        public string Scada_Tag32
        {
            get { return this.scada_tags[32]; }
            set { this.scada_tags[32] = value; }
        }
        public string Scada_Tag33
        {
            get { return this.scada_tags[33]; }
            set { this.scada_tags[33] = value; }
        }
        public string Scada_Tag34
        {
            get { return this.scada_tags[34]; }
            set { this.scada_tags[34] = value; }
        }
        public string Scada_Tag35
        {
            get { return this.scada_tags[35]; }
            set { this.scada_tags[35] = value; }
        }
        public string Scada_Tag36
        {
            get { return this.scada_tags[36]; }
            set { this.scada_tags[36] = value; }
        }
        public string Scada_Tag37
        {
            get { return this.scada_tags[37]; }
            set { this.scada_tags[37] = value; }
        }
        public string Scada_Tag38
        {
            get { return this.scada_tags[38]; }
            set { this.scada_tags[38] = value; }
        }
        public string Scada_Tag39
        {
            get { return this.scada_tags[39]; }
            set { this.scada_tags[39] = value; }
        }
        public string Scada_Tag40
        {
            get { return this.scada_tags[40]; }
            set { this.scada_tags[40] = value; }
        }
        public string Scada_Tag41
        {
            get { return this.scada_tags[41]; }
            set { this.scada_tags[41] = value; }
        }
        public string Scada_Tag42
        {
            get { return this.scada_tags[42]; }
            set { this.scada_tags[42] = value; }
        }
        public string Scada_Tag43
        {
            get { return this.scada_tags[43]; }
            set { this.scada_tags[43] = value; }
        }
        public string Scada_Tag44
        {
            get { return this.scada_tags[44]; }
            set { this.scada_tags[44] = value; }
        }
        public string Scada_Tag45
        {
            get { return this.scada_tags[45]; }
            set { this.scada_tags[45] = value; }
        }
        public string Scada_Tag46
        {
            get { return this.scada_tags[46]; }
            set { this.scada_tags[46] = value; }
        }
        public string Scada_Tag47
        {
            get { return this.scada_tags[47]; }
            set { this.scada_tags[47] = value; }
        }
        public string Scada_Tag48
        {
            get { return this.scada_tags[48]; }
            set { this.scada_tags[48] = value; }
        }
        public string Scada_Tag49
        {
            get { return this.scada_tags[49]; }
            set { this.scada_tags[49] = value; }
        }
        public string Scada_Tag50
        {
            get { return this.scada_tags[50]; }
            set { this.scada_tags[50] = value; }
        }
        public string Scada_Tag51
        {
            get { return this.scada_tags[51]; }
            set { this.scada_tags[51] = value; }
        }
        public string Scada_Tag52
        {
            get { return this.scada_tags[52]; }
            set { this.scada_tags[52] = value; }
        }
        public string Scada_Tag53
        {
            get { return this.scada_tags[53]; }
            set { this.scada_tags[53] = value; }
        }
        public string Scada_Tag54
        {
            get { return this.scada_tags[54]; }
            set { this.scada_tags[54] = value; }
        }
        public string Scada_Tag55
        {
            get { return this.scada_tags[55]; }
            set { this.scada_tags[55] = value; }
        }
        public string Scada_Tag56
        {
            get { return this.scada_tags[56]; }
            set { this.scada_tags[56] = value; }
        }
        public string Scada_Tag57
        {
            get { return this.scada_tags[57]; }
            set { this.scada_tags[57] = value; }
        }
        public string Scada_Tag58
        {
            get { return this.scada_tags[58]; }
            set { this.scada_tags[58] = value; }
        }
        public string Scada_Tag59
        {
            get { return this.scada_tags[59]; }
            set { this.scada_tags[59] = value; }
        }
        public string Scada_Tag60
        {
            get { return this.scada_tags[60]; }
            set { this.scada_tags[60] = value; }
        }
        public string Scada_Tag61
        {
            get { return this.scada_tags[61]; }
            set { this.scada_tags[61] = value; }
        }
        public string Scada_Tag62
        {
            get { return this.scada_tags[62]; }
            set { this.scada_tags[62] = value; }
        }
        public string Scada_Tag63
        {
            get { return this.scada_tags[63]; }
            set { this.scada_tags[63] = value; }
        }
        public string Scada_Tag64
        {
            get { return this.scada_tags[64]; }
            set { this.scada_tags[64] = value; }
        }
        public string Scada_Tag65
        {
            get { return this.scada_tags[65]; }
            set { this.scada_tags[65] = value; }
        }
        public string Scada_Tag66
        {
            get { return this.scada_tags[66]; }
            set { this.scada_tags[66] = value; }
        }
        public string Scada_Tag67
        {
            get { return this.scada_tags[67]; }
            set { this.scada_tags[67] = value; }
        }
        public string Scada_Tag68
        {
            get { return this.scada_tags[68]; }
            set { this.scada_tags[68] = value; }
        }
        public string Scada_Tag69
        {
            get { return this.scada_tags[69]; }
            set { this.scada_tags[69] = value; }
        }
        public string Scada_Tag70
        {
            get { return this.scada_tags[70]; }
            set { this.scada_tags[70] = value; }
        }
        public string Scada_Tag71
        {
            get { return this.scada_tags[71]; }
            set { this.scada_tags[71] = value; }
        }
        public string Scada_Tag72
        {
            get { return this.scada_tags[72]; }
            set { this.scada_tags[72] = value; }
        }
        public string Scada_Tag73
        {
            get { return this.scada_tags[73]; }
            set { this.scada_tags[73] = value; }
        }
        public string Scada_Tag74
        {
            get { return this.scada_tags[74]; }
            set { this.scada_tags[74] = value; }
        }
        public string Scada_Tag75
        {
            get { return this.scada_tags[75]; }
            set { this.scada_tags[75] = value; }
        }
        public string Scada_Tag76
        {
            get { return this.scada_tags[76]; }
            set { this.scada_tags[76] = value; }
        }
        public string Scada_Tag77
        {
            get { return this.scada_tags[77]; }
            set { this.scada_tags[77] = value; }
        }
        public string Scada_Tag78
        {
            get { return this.scada_tags[78]; }
            set { this.scada_tags[78] = value; }
        }
        public string Scada_Tag79
        {
            get { return this.scada_tags[79]; }
            set { this.scada_tags[79] = value; }
        }
        public string Scada_Tag80
        {
            get { return this.scada_tags[80]; }
            set { this.scada_tags[80] = value; }
        }
        public string Scada_Tag81
        {
            get { return this.scada_tags[81]; }
            set { this.scada_tags[81] = value; }
        }
        public string Scada_Tag82
        {
            get { return this.scada_tags[82]; }
            set { this.scada_tags[82] = value; }
        }
        public string Scada_Tag83
        {
            get { return this.scada_tags[83]; }
            set { this.scada_tags[83] = value; }
        }
        public string Scada_Tag84
        {
            get { return this.scada_tags[84]; }
            set { this.scada_tags[84] = value; }
        }
        public string Scada_Tag85
        {
            get { return this.scada_tags[85]; }
            set { this.scada_tags[85] = value; }
        }
        public string Scada_Tag86
        {
            get { return this.scada_tags[86]; }
            set { this.scada_tags[86] = value; }
        }
        public string Scada_Tag87
        {
            get { return this.scada_tags[87]; }
            set { this.scada_tags[87] = value; }
        }
        public string Scada_Tag88
        {
            get { return this.scada_tags[88]; }
            set { this.scada_tags[88] = value; }
        }
        public string Scada_Tag89
        {
            get { return this.scada_tags[89]; }
            set { this.scada_tags[89] = value; }
        }
        public string Scada_Tag90
        {
            get { return this.scada_tags[90]; }
            set { this.scada_tags[90] = value; }
        }
        public string Scada_Tag91
        {
            get { return this.scada_tags[91]; }
            set { this.scada_tags[91] = value; }
        }
        public string Scada_Tag92
        {
            get { return this.scada_tags[92]; }
            set { this.scada_tags[92] = value; }
        }
        public string Scada_Tag93
        {
            get { return this.scada_tags[93]; }
            set { this.scada_tags[93] = value; }
        }
        public string Scada_Tag94
        {
            get { return this.scada_tags[94]; }
            set { this.scada_tags[94] = value; }
        }
        public string Scada_Tag95
        {
            get { return this.scada_tags[95]; }
            set { this.scada_tags[95] = value; }
        }
        public string Scada_Tag96
        {
            get { return this.scada_tags[96]; }
            set { this.scada_tags[96] = value; }
        }
        public string Scada_Tag97
        {
            get { return this.scada_tags[97]; }
            set { this.scada_tags[97] = value; }
        }
        public string Scada_Tag98
        {
            get { return this.scada_tags[98]; }
            set { this.scada_tags[98] = value; }
        }
        public string Scada_Tag99
        {
            get { return this.scada_tags[99]; }
            set { this.scada_tags[99] = value; }
        }

    }
}
