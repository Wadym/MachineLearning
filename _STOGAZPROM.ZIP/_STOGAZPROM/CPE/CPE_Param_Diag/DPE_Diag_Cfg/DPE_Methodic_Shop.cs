﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace DPE_Diag_Config
{
    public class DPE_Methodic_Shop
    {
        private uint shop_id = 1;
        public uint Shop_ID
        {
            get { return shop_id; }
            set { shop_id = value; }
        }

        private List<DPE_Methodic_Agregate> agregate = new List<DPE_Methodic_Agregate>();
        [XmlArrayItem("Agregate")]
        public List<DPE_Methodic_Agregate> Agregates
        {
            get { return agregate; }
            set { agregate = value; }
        }

    }
}
