﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DPE_Diag_Config
{
    public class DPE_Defaults_Cfg
    {
        private object methodic_config = null;
        public object MethodicConfig
        {
            get { return methodic_config; }
            set { methodic_config = value; }
        }
    }
}
