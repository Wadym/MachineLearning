﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace DPE_Diag_Config
{
    public class DPE_Methodic_Agregate
    {
        private uint id;

        public uint ID
        {
            get { return id; }
            set { id = value; }
        }

        private object methodic_config = new object();
        //[XmlArrayItem("MachineConfig")]
        public object MethodicConfig
        {
            get { return methodic_config; }
            set { methodic_config = value; }
        }
    }
}
