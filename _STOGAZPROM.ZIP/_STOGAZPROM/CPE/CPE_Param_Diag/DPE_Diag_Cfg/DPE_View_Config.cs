﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DPE_Diag_Config
{
    public class DPE_View_Config
    {
        private bool enable = true;
        public bool Enable
        {
            get { return enable; }
            set { enable = value; }
        }

        private float min_x = 0;

        public float Min_X
        {
            get { return min_x; }
            set { min_x = value; }
        }

        private float max_x = 1;

        public float Max_X
        {
            get { return max_x; }
            set { max_x = value; }
        }
        private float min_y = 0;

        public float Min_Y
        {
            get { return min_y; }
            set { min_y = value; }
        }
        private float max_y = 1;
        public float Max_Y
        {
            get { return max_y; }
            set { max_y = value; }
        }
    }
}
