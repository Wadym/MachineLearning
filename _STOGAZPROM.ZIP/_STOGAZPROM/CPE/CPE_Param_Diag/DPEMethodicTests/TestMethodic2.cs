﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;

namespace DPEMethodicTests
{
    public class TestMethodic2 : CPE_Methodic
    {
        public override void Execute(Slice data)
        {
            for (Int32 i = 0; i < data.OutputData.Length && i < data.InputData.Length; ++i)
            {
                data.OutputData[i] = data.InputData[i];
                data.OutputStatus[i] = data.InputStatus[i];
            }
        }
    }
}
