﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    public class Claster: Slice
    {

    }
}
