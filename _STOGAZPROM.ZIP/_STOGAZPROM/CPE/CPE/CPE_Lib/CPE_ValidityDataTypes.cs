﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    public enum CPE_ValidityDataTypes
    {
        /// <summary>Неопределенное (недопустимое) значение</summary>
        /// ISP:
        /// MODEDETECTOR:
        ValidityDataTypeUndefined = -1,
        /// <summary>Данное есть и оно достоверно</summary>
        /// ISP:Данное достоверно
        /// MODEDETECTOR:
        ValidityDataTypeGood = 0,
        /// <summary>Данное есть, но оно задано вручную</summary>
        /// ISP:Вручную заданные параметры из файла конфигурации
        /// MODEDETECTOR:
        ValidityDataTypeHandmade = 1,
        /// <summary>Данное есть, но оно устаревшее</summary>
        /// ISP:
        /// MODEDETECTOR: режим нестационарен в предполагаемое время отсчета
        ValidityDataTypeOutdated = 2,
        /// <summary>Данное есть, но оно сомнительно (недостоверно)</summary>
        /// ISP:
        /// MODEDETECTOR:параметер за пределами min/max
        ValidityDataTypeDoubtful = 3,
        /// <summary>Данного нет, ошибка получения или обработки</summary>
        /// ISP:данное недостоверно
        /// MODEDETECTOR:
        ValidityDataTypeError = 4,
        /// <summary>Данного нет, оно не было задано или установлено</summary>
        /// ISP:параметер выключен пользователем
        /// MODEDETECTOR:
        ValidityDataTypeNodata = 5,


    }

}



