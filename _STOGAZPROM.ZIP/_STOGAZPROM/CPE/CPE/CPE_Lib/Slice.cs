﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    //type for position in Slice

    public class Slice
    {


        public DateTime Timestamp { get; set; }
        public Dictionary<int, Dictionary<int, double>> Data { get; set; }
        public Dictionary<int, Dictionary<int, CPE_ValidityDataTypes>> DataStatus { get; set; }
        public List<List<string>> DataNames { set; get; }

        /// <summary>
        /// Массив входных значений. 
        public double[] InputData { set; get; }
        public string[] InputDataNames { get; set; }
        public Dictionary<int, int> InputDataDictionary { get; set; }
        public CPE_ValidityDataTypes[] InputStatus { get; set; }
        //массив выходных значений
        public double[] OutputData { get; set; }
        public string[] OutputDataNames { get; set; }
        public Dictionary<int, int> OutputDataDictionary { get; set; }
        public CPE_ValidityDataTypes[] OutputStatus { get; set; }

        public List<string> Pos_Name { get; set; }




        //constructor
        public Slice()
        {
            this.Data = new Dictionary<int, Dictionary<int, double>>();
            this.DataStatus = new Dictionary<int, Dictionary<int, CPE_ValidityDataTypes>>();
            this.DataNames = new List<List<string>>();


            this.Timestamp = new DateTime();
            this.InputData = new double[0];
            this.InputDataNames = new string[0];
            this.InputStatus = new CPE_ValidityDataTypes[0];
            this.OutputData = new double[0];
            this.OutputDataNames = new string[0];
            this.OutputStatus = new CPE_ValidityDataTypes[0];
            this.Pos_Name = new List<string>();
            InputDataDictionary = new Dictionary<int, int>();
            OutputDataDictionary = new Dictionary<int, int>();

        }

        public Slice(int input_count, int output_count)
            : this()
        {
            this.InputData = new double[input_count];
            this.InputStatus = new CPE_ValidityDataTypes[input_count];
            this.InputDataNames = new string[input_count];

            this.OutputData = new double[output_count];
            this.OutputStatus = new CPE_ValidityDataTypes[output_count];
            this.OutputDataNames = new string[output_count];
            for (int i = 0; i < output_count; i++)
            {
                this.OutputStatus[i] = CPE_ValidityDataTypes.ValidityDataTypeUndefined;
                this.OutputData[i] = CPE_Enum_Const.value_INCORRECT;
            }
        }

    }
}
