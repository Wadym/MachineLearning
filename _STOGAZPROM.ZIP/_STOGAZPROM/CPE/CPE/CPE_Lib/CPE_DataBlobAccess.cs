﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CPE_Lib
{
    public class CPE_DataBlobAccess
    {
        public virtual Stream GetStream(string id, FileMode mode, FileAccess access)
        {
            Stream result = new FileStream(id, mode, access);
            return result;
        }
    }
}
