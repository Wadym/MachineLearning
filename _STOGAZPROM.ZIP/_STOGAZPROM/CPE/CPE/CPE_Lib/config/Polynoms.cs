﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    //класс для описания полинома
    public class Polynoms
    {
        
        public int ID { get; set; }//ID
        public int Num { get; set; }//количество полиномов для кривой (2 или 1)
        public double Min { get; set; }//минимально допустимое значение для полинома
        public double Max { get; set; }//максимально допустимое значение для полинома
        public double Point { get; set; } //точка раздела полинома
        public double[] Coeff { get; set; } //коэффициенты полинома

        public Polynoms()
        {
            this.ID = new int();
            this.Num = new int();
            this.Min = new double();
            this.Max = new double();
            this.Point = new double();
            this.Coeff = new double[12];
        }
    }
}
