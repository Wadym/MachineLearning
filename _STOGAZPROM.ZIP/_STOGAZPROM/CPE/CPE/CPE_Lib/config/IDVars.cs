﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
   
    
    //класс связывающий ID c переменной
    public class IdVarsInt
    {
        public int ID { get; set; } //id
        public int Value { get; set; } //значение       
    }

    public class IdVarsDouble
    {
        public int ID { get; set; } //id
        public double Value { get; set; } //значение       
    }
    
}
