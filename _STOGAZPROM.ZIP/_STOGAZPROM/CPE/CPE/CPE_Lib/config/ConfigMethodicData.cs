﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace CPE_Lib
{
    public class ConfigMethodicData
    {

        //member
        public SettingInputs InputSetting { get; set; }
        public SettingParameters Parameters { get; set; }
        public List<IdVarsInt> OutputSetting { get; set; }

        //constructor
        public ConfigMethodicData()
        {
            this.InputSetting = new SettingInputs();
            this.Parameters = new SettingParameters();
            this.OutputSetting = new List<IdVarsInt>();
        }

        //0 - no unit;
        //1 - kPa->Pa ; kJ - >J;
        //2-MPa->Pa
        //3 -  C->K;
        //m3/h - > m3/s
        public double ConvertUnits(int unit, double value)
        {
            switch (unit)
            {
                case 1: return value * 1000;
                case 2: return value * 1000000;
                case 3: return value + 273.15;
                case 4: return value / 3600;
                default: return value;
            }
        }

        //function
        public bool ReadXml(string data)
        {
            bool result = false;
            XmlReaderSettings XmlSetting = new XmlReaderSettings();
            XmlSetting.IgnoreComments = true;
            XmlSetting.IgnoreWhitespace = true;
            XmlReader reader = XmlReader.Create(new StringReader(data), XmlSetting);
            try
            {
                if (reader.ReadToDescendant("MethodicConfig"))
                {
                    //read input setting
                    //read all before inputs
                    reader.ReadToDescendant("InputsSettings");
                    do
                    {

                        switch (reader.Name.ToString())
                        {
                            case "TimeStep":
                                InputSetting.TimeStepMs = reader.ReadElementContentAsInt();
                                break;
                            case "TimeSteady":
                                InputSetting.ProcessPeriodMs = reader.ReadElementContentAsInt();
                                break;
                            case "TimeSteadyShift":
                                InputSetting.ProcessPeriodShiftMs = reader.ReadElementContentAsInt();
                                break;
                            default:
                                reader.Read();
                                continue;
                        }
                    }

                    while ("Inputs" != reader.Name.ToString());


                    //read for each input
                    do
                    {
                        string str;
                        double dbl;
                        if ("Input" == reader.Name.ToString())
                        {
                            //Inputs temp = new Inputs();
                            // Console.WriteLine
                            InputSetting.ID.Add(Convert.ToInt32(reader["ID"]));
                            do    //reader input
                            {
                                switch (reader.Name.ToString())
                                {
                                    case "Attribute":
                                        InputSetting.Attribute.Add(reader.ReadElementContentAsInt());
                                        break;
                                    case "Min":
                                        str = reader.ReadElementContentAsString();
                                        dbl = 0;
                                        if (Double.TryParse(str, out dbl))
                                        {
                                            InputSetting.IspMinAttr.Add(0);
                                        }
                                        else
                                        {
                                            InputSetting.IspMinAttr.Add(1);
                                        }
                                        InputSetting.IspMin.Add(dbl);
                                        break;
                                    case "Max":
                                        str = reader.ReadElementContentAsString();
                                        dbl = 0;
                                        if (Double.TryParse(str, out dbl))
                                        {
                                            InputSetting.IspMaxAttr.Add(0);
                                        }
                                        else
                                        {
                                            InputSetting.IspMaxAttr.Add(1);
                                        }
                                        InputSetting.IspMax.Add(dbl);
                                        break;
                                    case "ModeDetectorMin":
                                        str = reader.ReadElementContentAsString();
                                        dbl = 0;
                                        if (Double.TryParse(str, out dbl))
                                        {
                                            InputSetting.ModeMinAttr.Add(0);
                                        }
                                        else
                                        {
                                            InputSetting.ModeMinAttr.Add(1);
                                        }
                                        InputSetting.ModeMin.Add(dbl);
                                        break;
                                    case "ModeDetectorDelta":
                                        str = reader.ReadElementContentAsString();
                                        dbl = 0;
                                        if (Double.TryParse(str, out dbl))
                                        {
                                            InputSetting.ModeDeltaAttr.Add(0);
                                        }
                                        else
                                        {
                                            InputSetting.ModeDeltaAttr.Add(1);
                                        }
                                        InputSetting.ModeDelta.Add(dbl);
                                        break;
                                    case "DefaultValue":
                                        InputSetting.Default.Add(reader.ReadElementContentAsDouble());
                                        break;
                                    default:
                                        reader.Read();
                                        continue;
                                }

                            }
                            while ("Input" != reader.Name.ToString());
                        }
                        reader.Read();
                    }
                    while ("Inputs" != reader.Name.ToString());

                    // reader.ReadEndElement("InputsSettings");

                    //read Parameter
                    while ("Parameters" != reader.Name.ToString()) reader.Read();
                    while ("Polynom" != reader.Name.ToString()) reader.Read();
                    do
                    {
                        if ("Polynom" == reader.Name.ToString())
                        {

                            //  Polynoms temp = new Polynoms();
                            Parameters.Polynom.Add(new Polynoms());
                            int index = Parameters.Polynom.Count - 1;
                            // Console.WriteLine
                            Parameters.Polynom[index].ID = Convert.ToInt32(reader["ID"]);
                            do    //reader input
                            {
                                switch (reader.Name.ToString())
                                {
                                    case "num":
                                        Parameters.Polynom[index].Num = reader.ReadElementContentAsInt();
                                        break;
                                    case "Min":
                                        Parameters.Polynom[index].Min = reader.ReadElementContentAsDouble();
                                        break;
                                    case "Max":
                                        Parameters.Polynom[index].Max = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a00":
                                        Parameters.Polynom[index].Coeff[0] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a01":
                                        Parameters.Polynom[index].Coeff[1] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a02":
                                        Parameters.Polynom[index].Coeff[2] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a03":
                                        Parameters.Polynom[index].Coeff[3] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a04":
                                        Parameters.Polynom[index].Coeff[4] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a05":
                                        Parameters.Polynom[index].Coeff[5] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a10":
                                        Parameters.Polynom[index].Coeff[6] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a11":
                                        Parameters.Polynom[index].Coeff[7] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a12":
                                        Parameters.Polynom[index].Coeff[8] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a13":
                                        Parameters.Polynom[index].Coeff[9] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a14":
                                        Parameters.Polynom[index].Coeff[10] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "a15":
                                        Parameters.Polynom[index].Coeff[11] = reader.ReadElementContentAsDouble();
                                        break;
                                    case "Point":
                                        Parameters.Polynom[index].Point = reader.ReadElementContentAsDouble();
                                        break;
                                    default:
                                        reader.Read();
                                        continue;
                                }

                            }
                            while ("Polynom" != reader.Name.ToString());
                        }
                        reader.Read();
                    }
                    while ("Polynoms" != reader.Name.ToString());


                    //read Nominal
                    while ("Nominals" != reader.Name.ToString()) reader.Read();
                    do
                    {
                        if ("Nominal" == reader.Name.ToString())
                        {
                            Parameters.Nominal.Add(new IdVarsDouble());
                            int index = Parameters.Nominal.Count - 1;
                            Parameters.Nominal[index].ID = Convert.ToInt32(reader["ID"]);
                            reader.Read();
                            if ("value" == reader.Name.ToString())
                                Parameters.Nominal[index].Value = reader.ReadElementContentAsDouble();
                            // reader.Read();
                        }
                        reader.Read();
                    }
                    while ("Nominals" != reader.Name.ToString());

                    //read Coefff
                    while ("CoefficientDiafr" != reader.Name.ToString()) reader.Read();
                    do
                    {
                        if ("Coeff" == reader.Name.ToString())
                        {
                            Parameters.CoeffisientDiafr.Add(new IdVarsDouble());
                            int index = Parameters.CoeffisientDiafr.Count - 1;
                            Parameters.CoeffisientDiafr[index].ID = Convert.ToInt32(reader["ID"]);
                            reader.Read();
                            if ("value" == reader.Name.ToString())
                                Parameters.CoeffisientDiafr[index].Value = reader.ReadElementContentAsDouble();
                            // reader.Read();
                        }
                        reader.Read();
                    }
                    while ("CoefficientDiafr" != reader.Name.ToString());

                    //read Output
                    while ("OutputsSettings" != reader.Name.ToString()) reader.Read();
                    do
                    {
                        if ("Output" == reader.Name.ToString())
                        {
                            OutputSetting.Add(new IdVarsInt());
                            int index = OutputSetting.Count - 1;
                            OutputSetting[index].ID = Convert.ToInt32(reader["ID"]);
                            reader.Read();
                            if ("MedianFilter" == reader.Name.ToString())
                                OutputSetting[index].Value = reader.ReadElementContentAsInt();

                        }
                        reader.Read();
                    }
                    while ("OutputsSettings" != reader.Name.ToString());


                    //convert set units
                    for (int i = 0; i < this.InputSetting.ID.Count; i++)
                    {
                        this.InputSetting.Units.Add(0);
                    }

                    //0 - no unit;
                    //1 - kPa->Pa ; kJ - >J;
                    //2-MPa->Pa
                    //3 -  C->K;
                    //4- m3/h - > m3/s
                    this.InputSetting.Units[0] = 1;
                    this.InputSetting.Units[1] = 0;
                    this.InputSetting.Units[2] = 0;
                    this.InputSetting.Units[3] = 0;
                    this.InputSetting.Units[4] = 3;
                    this.InputSetting.Units[5] = 3;
                    this.InputSetting.Units[6] = 2;
                    this.InputSetting.Units[7] = 2;
                    this.InputSetting.Units[8] = 1;
                    this.InputSetting.Units[9] = 3;
                    this.InputSetting.Units[10] = 3;
                    this.InputSetting.Units[11] = 4;
                    this.InputSetting.Units[12] = 3;
                    this.InputSetting.Units[13] = 2;
                    this.InputSetting.Units[14] = 1;
                    this.InputSetting.Units[15] = 4;
                    this.InputSetting.Units[16] = 2;
                    this.InputSetting.Units[17] = 0;
                    this.InputSetting.Units[18] = 1;
                    //convert
                    this.ConvertUnit();

                    result = true;
                    return result;

                }
            }
            catch (XmlException ex)
            {
                return result;
            }

            return result;
        }

        bool ConvertUnit()
        {
            bool result = false;
            for (int i = 0; i < this.InputSetting.ID.Count; i++)
            {
                this.InputSetting.IspMax[i] = this.ConvertUnits(this.InputSetting.Units[i], this.InputSetting.IspMax[i]);
                this.InputSetting.IspMin[i] = this.ConvertUnits(this.InputSetting.Units[i], this.InputSetting.IspMin[i]);
                this.InputSetting.ModeMin[i] = this.ConvertUnits(this.InputSetting.Units[i], this.InputSetting.ModeMin[i]);
                this.InputSetting.ModeDelta[i] = this.ConvertUnits(this.InputSetting.Units[i], this.InputSetting.ModeDelta[i]);
                this.InputSetting.Default[i] = this.ConvertUnits(this.InputSetting.Units[i], this.InputSetting.Default[i]);
                
            }


            return result;
        }

       
    }
}
