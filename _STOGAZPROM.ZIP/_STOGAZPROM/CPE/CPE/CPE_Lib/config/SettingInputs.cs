﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    //класс конфигурации входных сигналов
    public class SettingInputs
    {
        
        public int TimeStepMs { get; set; }           //time step system
        public int ProcessPeriodMs { get; set; }      //length staedy regim
        public int ProcessPeriodShiftMs { get; set; } //shift time between steady regim
        public List<int> ID { get; set; }            //массив ID           
        public List<int> Attribute { get; set; }     //массив атрибутов
        public List<double> IspMin { get; set; }     //массив минимальных значений ISP
        public List<int> IspMinAttr { get; set; }     //attributr минимальных значений ISP (0 - check max; 1-don't check)
        public List<double> IspMax { get; set; }     //массив max значений ISP
        public List<int> IspMaxAttr { get; set; }     //attributr минимальных значений ISP
        public List<double> ModeMin { get; set; }       //массив минимальных значений MODE DETECTOR
        public List<int> ModeMinAttr { get; set; }     //attributr массив минимальных значений MODE DETECTOR
        public List<double> ModeDelta { get; set; } //массив отклонений значений MODE DETECTOR
        public List<int> ModeDeltaAttr { get; set; } //attributr массив отклонений значений MODE DETECTOR
        public List<double> Default { get; set; }//массив  значений по умолчанию 
        public List<int> Units { get; set; }//массив  едениц измерения
        //constructor
        public SettingInputs()
        {
            this.TimeStepMs = 1000;
            this.ProcessPeriodMs = 1000 * 60;
            this.ProcessPeriodShiftMs = 600;
            this.ID = new List<int>();
            this.Attribute = new List<int>();
            this.IspMin = new List<double>();
            this.IspMax = new List<double>();
            this.IspMinAttr = new List<int>();
            this.IspMaxAttr = new List<int>();
            this.ModeMin = new List<double>();
            this.ModeMinAttr = new List<int>();
            this.ModeDelta = new List<double>();
            this.ModeDeltaAttr = new List<int>();
            this.Default = new List<double>();
            this.Units = new List<int>();
        }
    }
}
