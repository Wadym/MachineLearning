﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    public class SettingParameters
    {
              
        public List<Polynoms> Polynom { get; set; } //данные полиномов
        public List<IdVarsDouble> CoeffisientDiafr { get; set; } //коэффициенты расходов мерных устройств
        public List<IdVarsDouble> Nominal { get; set; } //значения параметров на номинале
       
        //constructor
        public SettingParameters()
        {
            this.Polynom = new List<Polynoms>();
            this.CoeffisientDiafr = new List<IdVarsDouble>();
            this.Nominal = new List<IdVarsDouble>();

        }
    }
}
