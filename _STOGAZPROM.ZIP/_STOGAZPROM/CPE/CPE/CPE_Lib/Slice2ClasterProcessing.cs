﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Lib
{
    public class Slice2ClasterProcessing
    {
        /// <summary>
        /// Обработка входного среза данных и расчет выходных кластеров
        /// </summary>
        /// <param name="samples">Срез входных данных</param>
        /// <param name="clasters">Результат расчета - набор кластеров</param>
        /// <param name="clasters_history">История кластеров</param>
        public virtual bool Process(List<Slice> samples)
        {
            bool result = false;
            return result;
        }
    }

}
