﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CPE_CommonBlocks
{
    //public class ClusterCenter
    //{
    //    private List<List<double>> XC = new List<List<double>>();
    //    public List<List<double>> xC
    //    {
    //        get { return XC; }
    //        set { XC = value; }
    //    }

    //    private List<List<double>> YC = new List<List<double>>();
    //    public List<List<double>> yC
    //    {
    //        get { return YC; }
    //        set { YC = value; }
    //    }

    //    private List<double> TC = new List<double>();
    //    public List<double> tC
    //    {
    //        get { return TC; }
    //        set { TC = value; }
    //    }
    //}

    public class ClussterProcessorInput
    {
        public double time;
        public List<double> input = new List<double>();
        public List<double> output = new List<double>();
    }

    public class ClussterProcessorOutput
    {
        public double time;
        public List<double> input = new List<double>();
        public List<double> output = new List<double>();
    }


    public class ClussterProcessor
    {



        public void Config(CPE_ClussterConfig_sample confdata, Stream stream1, Stream stream2)
        {
            Console.WriteLine("Config ClussterProcessor ");
            Console.WriteLine("stream 1={0} ", stream1);
            Console.WriteLine("stream 2={0} ", stream2);
        }

        public bool Execute(ClussterProcessorInput input, ClussterProcessorOutput output)
        {
            Console.WriteLine("Execute:");

            for (int i = 0; i < 1; i++)
            {
                output.output.Add(-5555);
                Console.WriteLine("input={0} / {1}", input.output[i], output.output[i]);
            }
            return true;
        }

        public bool Calculate(ClussterProcessorInput input, ClussterProcessorOutput output)
        {
            Console.WriteLine("Calc:");
            //output.time = input.time;
            //output.output = input.input;
            Console.WriteLine("time={0} / {1} ", input.time, output.time);
            for (int i = 0; i < 1; i++)
            {
                output.output.Add(0.6882);
                //    Console.WriteLine("input={0} / {1}", input.output[i], output.output[i]);
            }
            return true;
        }
    }

    public class CPE_ClussterConfig_sample
    {
        public virtual void CConfig() { }
        public virtual void Config() { }
        #region ClusterProcessorCfg
        private string funcid = "functionname";
        public string FuncID
        {
            get { return funcid; }
            set { funcid = value; }
        }

        private double alpha = 0.5;
        public double Alpha
        {
            get { return alpha; }
            set { alpha = value; }
        }

        private string cluster_centers_storage_name = "ClusterCenters_FuncID.xml";
        public string ClusterCentersStorageName
        {
            get { return cluster_centers_storage_name; }
            set { cluster_centers_storage_name = value; }
        }

        private int number_of_clusters = 100;
        public int NumberOfClusters
        {
            get { return number_of_clusters; }
            set { number_of_clusters = value; }
        }

        private double beta = 0.1;
        public double Beta
        {
            get { return beta; }
            set { beta = value; }
        }

        private int iteration_max = 100;
        public int IterationMax
        {
            get { return iteration_max; }
            set { iteration_max = value; }
        }

        private double delta_err_max = 0.05;
        public double DeltaErrMax
        {
            get { return delta_err_max; }
            set { delta_err_max = value; }
        }

        private string storage_name = "HistoryStorageName_FuncID.xml";
        public string StorageName
        {
            get { return storage_name; }
            set { storage_name = value; }
        }

        private long requireed_records_number_for_clusterization;
        public long RequireedRecordsNumberForClusterization
        {
            get { return requireed_records_number_for_clusterization; }
            set { requireed_records_number_for_clusterization = value; }
        }

        private long requireed_records_number_for_initial_clusterization = 7 * 24 * 60 * 60 / 2;
        public long RequireedRecordsNumberForInitialClusterization
        {
            get { return requireed_records_number_for_initial_clusterization; }
            set { requireed_records_number_for_initial_clusterization = value; }
        }

        private long max_records_number_for_clusterizationmyVar;
        public long MaxRecordsNumberForClusterization
        {
            get { return max_records_number_for_clusterizationmyVar; }
            set { max_records_number_for_clusterizationmyVar = value; }
        }

        //private ClusterCenter cluster_centers = new ClusterCenter();
        //public ClusterCenter СlusterСenters
        //{
        //    get { return cluster_centers; }
        //    set { cluster_centers = value; }
        //}

        #endregion ClusterProcessorCfg
    }
}
