﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace CPE_CommonBlocks.ChartView
{
    public partial class ChartViewData : Form
    {
        public ChartViewData()
        {
            InitializeComponent();
        }

        public TreeView Tree
        {
            get { return this.treeView1; }
        }

        public Chart DrawChart
        {
            get { return this.chart1; }
        }

        public Form form
        {
            get { return this; }
        }

        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            Console.WriteLine("treeView1_AfterCheck");
        }
    }
}
