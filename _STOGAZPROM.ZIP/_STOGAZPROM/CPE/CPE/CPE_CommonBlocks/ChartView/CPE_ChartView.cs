﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using CPE_Lib;
//using CPE_CommonBlocks.ChartView;
//using System.Windows.Forms.DataVisualization.Charting;

//namespace CPE_CommonBlocks
//{
//    public class CPE_ChartView : SliceProcessing
//    {
//        public override void Config()
//        {
            
//        }
//        public  void Init()
//        {
//            this.hist.Clear();
//            this.chart_view.Tree.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(Tree_AfterCheck);

//            this.chart_view.DrawChart.ChartAreas[0].CursorX.IsUserEnabled = true;
//            this.chart_view.DrawChart.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
//            this.chart_view.DrawChart.ChartAreas[0].CursorX.Interval = 0;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisX.ScaleView.Zoomable = true;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisX.ScrollBar.ButtonStyle = System.Windows.Forms.DataVisualization.Charting.ScrollBarButtonStyles.SmallScroll;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisX.ScaleView.SmallScrollMinSize = 0;

//            this.chart_view.DrawChart.ChartAreas[0].CursorY.IsUserEnabled = true;
//            this.chart_view.DrawChart.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;
//            this.chart_view.DrawChart.ChartAreas[0].CursorY.Interval = 0;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisY.ScaleView.Zoomable = true;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisY.ScrollBar.IsPositionedInside = true;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisY.ScrollBar.ButtonStyle = System.Windows.Forms.DataVisualization.Charting.ScrollBarButtonStyles.SmallScroll;
//            //this.chart_view.DrawChart.ChartAreas[0].AxisY.ScaleView.SmallScrollMinSize = 0;
//            //this.chart_view.ShowDialog();
//        }

//        void Tree_AfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
//        {
//            this.chart_view.DrawChart.ChartAreas[0].AxisX.Title = this.name;
//            this.chart_view.DrawChart.ChartAreas[0].AxisX.TitleAlignment = System.Drawing.StringAlignment.Far;

//            this.chart_view.DrawChart.Series.Clear();
//            for (int i = 0; i < this.chart_view.Tree.Nodes.Count; i++)
//            {
//                if (this.chart_view.Tree.Nodes[i].Checked)
//                {
//                    Series ser = new Series(this.chart_view.Tree.Nodes[i].Text);
//                    ser.Points.Clear();
//                    ser.ChartType = SeriesChartType.FastLine;
//                    //ser.Color = this.cfg.SeriesCfgs[i].LineColor;
//                    ser.BorderWidth = 1;
//                    ser.BorderDashStyle = ChartDashStyle.Solid;
//                    ser.MarkerStep = 1;
//                    ser.MarkerStyle = MarkerStyle.None;
//                    ser.MarkerSize = 1;
//                    ser.XValueType = ChartValueType.DateTime;
//                    this.chart_view.DrawChart.Series.Add(ser);

//                    ser.Points.SuspendUpdates();
//                    for (int k = 0; k < this.hist.Count; k++)
//                    {
//                        ser.Points.AddXY(time_hist[k], this.hist[k][i]);
//                    }
//                    ser.Points.ResumeUpdates();
//                }
//            }
//        }

//        List<List<double>> hist = new List<List<double>>();
//        List<DateTime> time_hist = new List<DateTime>();
//        string name = "";

//        bool draw = false;
//        public override bool Process(Slice input)
//        {
//            if (false == draw)
//            {

//                hist.Add(input.Data[this.Pos]);
//                time_hist.Add(input.Timestamp);
//                name = input.Pos_Name[this.Pos];
//            }
//            return true;
//        }

//        private int pos = 0;
//        public int Pos
//        {
//            get { return pos; }
//            set { pos = value; }
//        }

//        ChartViewData chart_view = new ChartViewData();
//        public void DrawEventHandler(object sender, EventArgs e)
//        {
//            for (int i = 0; i < hist[0].Count; i++)
//            {
//                chart_view.Tree.Nodes.Add(string.Format("Data[{0}][{1}]", this.Pos, i));
//            }
//            this.chart_view.form.Text = this.name;
//            //this.chart_view.ShowDialog();
//            this.draw = true;
//            this.chart_view.Show();
//        }
//    }
//}
