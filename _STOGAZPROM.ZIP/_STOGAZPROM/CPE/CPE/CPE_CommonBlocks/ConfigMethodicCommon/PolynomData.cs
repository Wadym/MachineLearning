﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;


namespace CPE_CommonBlocks.ConfigMethodicCommon
{
    public class PolynomData
    {
        [XmlAttribute("ID")]
        public string NameVariable { get; set; }//имя полинома
        [XmlElement("num")]
        public string Num { get; set; }//количество полиномов для кривой (2 или 1)
        [XmlElement("Min")]
        public string Min { get; set; }//минимально допустимое значение для полинома
        [XmlElement("Max")]
        public string Max { get; set; }//максимально допустимое значение для полинома
        [XmlElement("a00")]
        public string a00 { get; set; }//коэффициенты полинома
        [XmlElement("a01")]
        public string a01 { get; set; }//коэффициенты полинома
        [XmlElement("a02")]
        public string a02 { get; set; }//коэффициенты полинома
        [XmlElement("a03")]
        public string a03 { get; set; }//коэффициенты полинома
        [XmlElement("a04")]
        public string a04 { get; set; }//коэффициенты полинома
        [XmlElement("a05")]
        public string a05 { get; set; }//коэффициенты полинома
        [XmlElement("Point")]
        public string Point { get; set; } //точка раздела полинома
        [XmlElement("a10")]
        public string a10 { get; set; }//коэффициенты полинома
        [XmlElement("a11")]
        public string a11 { get; set; }//коэффициенты полинома
        [XmlElement("a12")]
        public string a12 { get; set; }//коэффициенты полинома
        [XmlElement("a13")]
        public string a13 { get; set; }//коэффициенты полинома
        [XmlElement("a14")]
        public string a14 { get; set; }//коэффициенты полинома
        [XmlElement("a15")]
        public string a15 { get; set; }//коэффициенты полинома 
    }


}
