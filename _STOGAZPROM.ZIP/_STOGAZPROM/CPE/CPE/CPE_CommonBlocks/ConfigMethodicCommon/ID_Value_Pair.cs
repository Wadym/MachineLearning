﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace CPE_CommonBlocks.ConfigMethodicCommon
{
    public class ID_Value_Pair
    {
        [XmlAttribute("ID")]        
        public string Name;

        public string Value;
    }
}
