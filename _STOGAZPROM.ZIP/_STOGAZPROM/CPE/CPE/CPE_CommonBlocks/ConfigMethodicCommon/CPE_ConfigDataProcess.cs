﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_CommonBlocks.ConfigMethodicCommon
{
    public class CPE_ConfigDataProcess
    {
    }
}
