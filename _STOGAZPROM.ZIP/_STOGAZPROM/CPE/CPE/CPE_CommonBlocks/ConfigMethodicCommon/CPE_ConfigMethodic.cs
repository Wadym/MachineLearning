﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using CPE_Lib;
using System.ComponentModel;

namespace CPE_CommonBlocks.ConfigMethodicCommon
{
  //class for methodix
    public class CPE_ConfigDataMethodic
    {
        public CPE_ConfigDataXML DataXML { get; set; }
        public CPE_ConfigDataProcess DataProcess { get; set; }


        public virtual T  ReadXml<T>(string data,T temp_only_for_type )
        {
            //deserialize
            
            XmlSerializer serialize = new XmlSerializer(typeof(T));
            TextReader reader = new StringReader(data);
            return (T)serialize.Deserialize(reader);               
        }

                //method to read data from xml to cfgdata
        public virtual void GetData(string data) //Set all field "DataProcess"
        {
        }
        

       

        public void  CheckDictionaryKey<T1,T2>(string name_process,T1[]keys,Dictionary<T1,T2> dict)
        {
         for (int i = 0; i < keys.Length; i++)
            {
                if (!dict.ContainsKey(keys[i]))
                {
                    throw new Exception(string.Format("ощибка конфигурации блока {0}. Не все данные заданы.\n Не задано :{1}", name_process, keys[i]));
                }
            }
        }


        //convert polynom XML to usual
        public Polynoms ConvertPolynom(PolynomData polynomXML)
        {
            Polynoms polynom = new Polynoms();
            polynom.Max = this.ConvertStringDouble(polynomXML.Max,"read polynom data");
            polynom.Min = this.ConvertStringDouble(polynomXML.Min, "read polynom data");
            polynom.Num = this.ConvertStringInt(polynomXML.Num);
            polynom.Coeff[0] = this.ConvertStringDouble(polynomXML.a00, "read polynom data");
            polynom.Coeff[1] = this.ConvertStringDouble(polynomXML.a01, "read polynom data");
            polynom.Coeff[2] = this.ConvertStringDouble(polynomXML.a02, "read polynom data");
            polynom.Coeff[3] = this.ConvertStringDouble(polynomXML.a03, "read polynom data");
            polynom.Coeff[4] = this.ConvertStringDouble(polynomXML.a04, "read polynom data");
            polynom.Coeff[5] = this.ConvertStringDouble(polynomXML.a05, "read polynom data");
            polynom.Coeff[6] = this.ConvertStringDouble(polynomXML.a10, "read polynom data");
            polynom.Coeff[7] = this.ConvertStringDouble(polynomXML.a11, "read polynom data");
            polynom.Coeff[8] = this.ConvertStringDouble(polynomXML.a12, "read polynom data");
            polynom.Coeff[9] = this.ConvertStringDouble(polynomXML.a13, "read polynom data");
            polynom.Coeff[10] = this.ConvertStringDouble(polynomXML.a14, "read polynom data");
            polynom.Coeff[11] = this.ConvertStringDouble(polynomXML.a15, "read polynom data");
            return polynom;
        }

        //convert string to name_va



        
        public List<double> ConvertStringListDouble(string str,string message)
        {
            List<double> res = new List<double>();
            string[] lines = str.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                res.Add(ConvertStringDouble(lines[i], message));
            }
            return res;
        }


        

       

       

        //convert string to double
        public double ConvertStringDouble(string str,string message)
        {
            double res;

            if (!Double.TryParse(str, out res))
            {
                throw new Exception(String.Format("{0}\n использовани недопустимый символ при заполнении файла конфигурации:\"{1}\"", message, str));
            }

            return res;
        }


       

        public int ConvertStringInt(string str)
        {
            int res;

            if (!Int32.TryParse(str, out res))
            {
                throw new Exception(String.Format("использовани недопустимый символ при заполнении файла конфигурации:\"{0}\"", str));
            }

            return res;
        }

        public void ConvertStringDoubleBool(string str,out double res,out bool res1 )
        {
           res1=false;
           res = CPE_Enum_Const.value_INCORRECT;
            if (str != "*")
            {
                if (Double.TryParse(str, out res))
                {
                    res1 = true;
                }

                else
                {
                    throw new Exception(String.Format("использовани недопустимый символ при заполнении файла конфигурации:\"{0}\"", str));
                }
            }
            return;
        }
    }
}
