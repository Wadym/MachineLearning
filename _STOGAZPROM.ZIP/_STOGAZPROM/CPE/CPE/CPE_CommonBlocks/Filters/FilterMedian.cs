﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_CommonBlocks
{
    public class FilterMedian: FilterCommon
    {
            //        tuning[0] = 30; // [minutes]
            //tuning[1] = 5; //  [minutes]        
            //tuning[2] = 2; //  [minutes]
            //tuning[3] = 2; //  [sec]       
            //tuning[4] = 10; // [-]
            //GCU.tuning = tuning;

        private int delay = 2000;
        public int Delay
        {
            get { return delay; }
            set 
            { 
                delay = value;
                if (delay < 1) delay = 1;
            }
        }

        List<double> delay_line = new List<double>();
        public override double Process(double data)
        {
            this.delay_line.Add(data);
            while (this.delay_line.Count > this.Delay)
            {
                this.delay_line.RemoveAt(0);
            }

            List<double> temp = new List<double>();
            temp.AddRange(this.delay_line);
            temp.Sort();
            int med = delay_line.Count / 2;
            return temp[med];
        }

    }
}
