﻿using System;
using System.Collections.Generic;
using System.Text;




namespace CPE_CommonBlocks
{
    public class FilterMovingAverage: FilterCommon
    {
            //        tuning[0] = 30; // [minutes]
            //tuning[1] = 5; //  [minutes]        
            //tuning[2] = 2; //  [minutes]
            //tuning[3] = 2; //  [sec]       
            //tuning[4] = 10; // [-]
            //GCU.tuning = tuning;

        private int delay = 2000;
        public int Delay
        {
            get { return delay; }
            set 
            { 
                delay = value;
                if (delay < 1) delay = 1;
            }
        }

        List<double> delay_line = new List<double>();
        public override double Process(double data)
        {
            this.delay_line.Add(data);
            while (this.delay_line.Count > this.Delay)
            {
                this.delay_line.RemoveAt(0);
            }

            double temp = 0;
            for (int i = 0; i < this.delay_line.Count; i++)
            {
                temp = temp + this.delay_line[i];
            }
            temp = temp / this.delay_line.Count;
            return temp;
        }

    }
}
