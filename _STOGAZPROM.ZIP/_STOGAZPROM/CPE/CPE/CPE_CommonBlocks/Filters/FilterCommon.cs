﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_CommonBlocks
{
    public class FilterCommon
    {
        public virtual double Process(double data)
        {
            double result = data;

            return result;
        }
    }
}
