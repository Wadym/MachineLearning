﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using System.IO;
using ClusterProcessorClassLibrary;

namespace CPE_CommonBlocks
{
    public class CPE_ClusterProcessor_cfg
    {
      //  public List<CPE_ClussterConfig_sample> Node { get; set; }  //Nodes
        public List<List<int[]>> InputName { get; set; }             //Input var for Node [node#][var#][0]-> position (column) [node#][var#][1]-> position (variable)
        public List<List<int[]>> OutputName { get; set; }            // -
        public List<List<double>> InputPredictValue { get; set; }                   //[node#][var#] -> value 
        public List<List<int[]>> OutputPredictName { get; set; }     //
        public List<int> NodeDecimation { get; set; }              //reduction for node
        public List<CProcessorNodeCfg> Node { get; set; }
        public string NameMethodic { get; set; }                           
     
        public CPE_ClusterProcessor_cfg()
        {
            InputName = new List<List<int[]>>();
            OutputName = new List<List<int[]>>();
            InputPredictValue = new List<List<double>>();
            OutputPredictName = new List<List<int[]>>();
            Node = new List<CProcessorNodeCfg>();
            NodeDecimation = new List<int>();
        }
    }

    public class CPE_ClusterProcessor : SliceProcessing
    {
        public CPE_ClusterProcessor_cfg cfg { get; set; }
        public List<CProcessorNodeBase<CHistoryInputNode, CRTInputNode>> Node { get; set; }

        List<int> node_decimation_count = new List<int>();       //var for count decimation
        List<DateTime> time_output_last = new List<DateTime>();
        private object batonCPE_ = new object();
        public object batonCPE
        {
            get { return batonCPE_; }
            set { batonCPE_ = value; }
        }
        public CPE_ClusterProcessor()
        {
            cfg = new CPE_ClusterProcessor_cfg();
            Node = new List<CProcessorNodeBase<CHistoryInputNode, CRTInputNode>>();
            time_output_last = new List<DateTime>();
        }

        public void Config(CPE_ClusterProcessor_cfg confdata, CPE_DataBlobAccess data_access)
        {
            cfg = confdata;
            string message_public = "Не правильно сконфигурирован модуль CPE_ClusterProcessor\n";
            Func.Util_CheckSameNumberList("ClusterProcessingReal", cfg.InputName, cfg.OutputName, cfg.Node, cfg.NodeDecimation);
            // for ()
            for (int i = 0; i < cfg.InputName.Count; i++)
            {
                if ((0 == cfg.InputName[i].Count) || (0 == cfg.OutputName[i].Count))
                {
                    throw new Exception(string.Format("{0}Не заданы InputName или OutputName для кластера.", message_public));
                }
                if (cfg.InputPredictValue[i].Count > 0)
                {
                    if (0 == cfg.OutputPredictName[i].Count)
                    {
                        throw new Exception(string.Format("{0}Не заданы OutputPredictName для кластера.", message_public));
                    }

                    if (cfg.InputPredictValue[i].Count != cfg.InputName[i].Count)
                    {
                        throw new Exception(string.Format("{0}(Не все InputPredictValue соответствуют InputName)", message_public));
                    }
                    if (0 == cfg.OutputPredictName[i].Count)
                    {
                        throw new Exception(string.Format("{0}(Не заданы  OutputPredictName )", message_public));
                    }
                }
            }

            //config node
            for (int i = 0; i < cfg.Node.Count; i++)
            {


                string line1 = string.Format("stream_ClusterProcess_{0}_{1}_1", cfg.NameMethodic, i);
                string line2 = string.Format("stream_ClusterProcess_{0}_{1}_2", cfg.NameMethodic, i);
                Stream stream1 = data_access.GetStream(line1, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                Stream stream2 = data_access.GetStream(line2, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                Node.Add(new CProcessorNode<CHistoryInputNode, CRTInputNode>());
                object NodeID = new object();
                NodeID = i;
                Node[i].Config(cfg.Node[i], stream1, stream2,NodeID);
                node_decimation_count.Add(0);
                time_output_last.Add(DateTime.MinValue);
                stream1.Close();
                stream2.Close();
            }
        }

        public override bool Process(Slice input)
        {
            bool result = false;
            for (int i = 0; i < Node.Count; i++)
            {
                node_decimation_count[i]++;
                //if (1 == node_decimation_count[i])
                int r = new int();
                Math.DivRem(node_decimation_count[i],cfg.NodeDecimation[i],out r);
                //if (1 == r)
                if (0 == r)
                {
                    CRTInputNode cluster_input = new CRTInputNode();
                    COutput cluster_output = new COutput(1);
                    ClusterCenter cluster_centers = new ClusterCenter();
                    if (true ==
                        PrepareInputOutputForCluster(input, cfg.InputName[i], cfg.OutputName[i], cluster_input, cluster_output))
                    {
                        //lock (Node[i].crt.baton)//cluster_input)
                        lock (batonCPE)
                        {
                            Node[i].Exe(cluster_input, ref cluster_centers, ref cluster_output);
                        }
                    }
                    if (cfg.InputPredictValue[i].Count > 0)
                    {                      
                        CRTInputNode cluster_input_predict = new CRTInputNode();
                        if (true == PrepareInputOutputForClusterPediction(input, cfg.InputPredictValue[i], cluster_input_predict))
                        {
                            COutput cluster_output_predict = new COutput(1);//cfg.InputPredictValue[i].Count
                            //lock (Node[i].crt.baton)//cluster_input)
                            lock (batonCPE)
                            {
                                if (true == Node[i].Calc(cluster_input_predict, ref cluster_centers, ref cluster_output_predict) &&
                                    (null != cluster_output_predict.output) &&
                                    (cluster_output_predict.output.Count == cfg.OutputPredictName[i].Count))
                                {
                                    if (time_output_last[i].ToOADate() < cluster_output_predict.thetaT[0])
                                    {

                                        time_output_last[i] = DateTime.FromOADate(cluster_output.thetaT[0]);

                                        SaveDataFromOutputSlice(input, cluster_output_predict, cfg.OutputPredictName[i], CPE_ValidityDataTypes.ValidityDataTypeGood);
                                        result = true;
                                    }
                                    else
                                    {
                                        SaveDataFromOutputSlice(input, cluster_output_predict, cfg.OutputPredictName[i], CPE_ValidityDataTypes.ValidityDataTypeHandmade);
                                        result = true;
                                    }
                                }
                                else
                                {
                                    SaveDataFromOutputSlice(input, cluster_output, cfg.OutputPredictName[i], CPE_ValidityDataTypes.ValidityDataTypeError);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (cfg.NodeDecimation[i] == node_decimation_count[i])
                    {
                        node_decimation_count[i] = 0;
                    }
                }
            }



            return result;
        }



            bool PrepareInputOutputForCluster(Slice input, List<int[]> variable_name_input,
                List<int[]> variable_name_output, CRTInputNode cluster_input, 
               COutput cluster_output)
        
        {
            bool result = true;
            List<double> data_in = new List<double>();
            List<double> data_out = new List<double>();
            if ((true == MadeListDoubleFromNames(input, variable_name_input, ref data_in)) &&
                (true == MadeListDoubleFromNames(input, variable_name_output, ref data_out)))
            {
                cluster_input.Tm = input.Timestamp.ToOADate();
                cluster_input.Input = data_in;
                cluster_input.Output = data_out;
            }
            else
            {
                result = false;
            }
            return result;
        }



        bool PrepareInputOutputForClusterPediction(Slice input, List<double> value,CRTInputNode cluster_input)

        {
            bool result = true;

            cluster_input.Tm = input.Timestamp.ToOADate();
            cluster_input.Input = value;

            return result;
        }


        bool SaveDataFromOutputSlice(Slice input, COutput ouput, List<int[]> name_coord_output, CPE_ValidityDataTypes status)


        {
            bool result = false;

            if ((CPE_ValidityDataTypes.ValidityDataTypeError != status) &&
                (name_coord_output.Count == ouput.output.Count))
            {
                for (int i = 0; i < name_coord_output.Count; i++)
                {

                    int position = name_coord_output[i][0];
                    int name_variable = name_coord_output[i][1];
                    input.Data[position][name_variable] = ouput.output[0][i]; 
                    input.DataStatus[position][name_variable] = status;


                }
                result = true;
            }
            else
            {
                for (int i = 0; i < name_coord_output.Count; i++)
                {
                    int position = name_coord_output[i][0];
                    int name_variable = name_coord_output[i][1];
                    input.Data[position][name_variable] = CPE_Enum_Const.value_INCORRECT;
                    input.DataStatus[position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeError;
                }
                result = false;
            }

            return result;
        }

        bool MadeListDoubleFromNames(Slice input, List<int[]> variable_coord, ref List<double> variable_value)
        {
            bool result = true;
            for (int j = 0; j < variable_coord.Count; j++)
            {
                int position = variable_coord[j][0];
                int name_variable = variable_coord[j][1];

                if ((CPE_ValidityDataTypes.ValidityDataTypeGood == input.DataStatus[position][name_variable]) ||
                  (CPE_ValidityDataTypes.ValidityDataTypeHandmade == input.DataStatus[position][name_variable]))
                {
                    variable_value.Add(input.Data[position][name_variable]);
                }
                else
                {
                    result = false;
                    break;
                }
            }
            return result;
        }
    }
}