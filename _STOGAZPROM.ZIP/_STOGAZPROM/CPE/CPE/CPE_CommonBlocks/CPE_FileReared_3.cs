﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using System.IO;

namespace CPE_CommonBlocks
{
    public class CPE_FileReared_3
    {
        StreamReader reader_data;

        public string Filename {get;set;}    
        public int ReadCount {get;set;}   
        public DateTime StartTime {get;set;}
        public int TimeStepMs { get; set; }


        private int[] index { get; set; }  //номер столбца (начиная с 1 ) для параметра во входном файле
        private int num_col{get;set;}      //количество столбцов на входе
        private double[] A { get; set; }      //перевод входного сигнала в виде AX+B
        private double[] B { get; set; }      //перевод входного сигнала в виде AX+B


        //constructor
        public CPE_FileReared_3()
        {
            this.ReadCount = 0;

            this.TimeStepMs = 2000;
            this.num_col = 19;

            //position_colum      (if -1 don't use) 
            this.index = new int[this.num_col];
            this.index[0] = 1;
            this.index[1] = 2;
            this.index[2] = 3;
            this.index[3] = 4;
            this.index[4] = 5;
            this.index[5] = 6;
            this.index[6] = 7;
            this.index[7] = 8;
            this.index[8] = 9;
            this.index[9] = 10;
            this.index[10] = 11;
            this.index[11] = 12;
            this.index[12] = 13;
            this.index[13] = 14;
            this.index[14] = 15;
            this.index[15] = 16;
            this.index[16] = 17;
            this.index[17] = 18;
            this.index[18] = 19;


            this.A = new double[this.num_col];
            for (int i = 0; i < this.num_col; i++) this.A[i] = 1.0;
            //this.A[0] = 1.333e-4;
            //this.A[6] = 0.001;
            //this.A[7] = 0.001;
            //this.A[13] = 0.001;
            //this.A[16] = 0.001;
            //this.A[8] = 0.001;
            //this.A[14] = 0.001;




            this.B = new double[this.num_col];
            for (int i = 0; i < this.num_col; i++) this.B[i] = 0.0;


            this.StartTime = new DateTime(2016, 01, 01);
        }


        public CPE_FileReared_3(int inTimeStepMs):this()
        {
         //this.Filename= @"..\..\..\..\Data\orsha3_160304.csv";  
         this.Filename = @"..\..\..\..\Data\res5.csv";
         this.reader_data = new StreamReader(File.OpenRead(this.Filename));
         this.TimeStepMs = inTimeStepMs;
       
        }

        public CPE_FileReared_3(string name):this()
        {
            this.Filename = name;
            this.reader_data = new StreamReader(File.OpenRead(this.Filename));
        }


        public bool ReadLine(Slice input)
        {
            string line = reader_data.ReadLine();
            bool result = true;
            if (line == null)
            {
                this.reader_data.Close();
                return false;
            }
           
           //read data****
            //coma vs dot
            line = line.Replace(',', '.');
           // line = line.Replace('.', ',');
            //line = line.Replace(',', ',');
            string[] lines = line.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
      
    
            List<double> data_read = new List<double>();
            for (int i = 0; i < lines.Length; i++)
            {
                data_read.Add(Convert.ToDouble(lines[i]));
            }
            //*************
            input.Timestamp = this.StartTime + new TimeSpan(0, 0, this.TimeStepMs/1000 * this.ReadCount);


            double[] data = new double[this.num_col];
            CPE_ValidityDataTypes[] attr = new CPE_ValidityDataTypes[this.num_col];
 
            //set default values
            for (int i = 0; i < this.num_col; i++)
            {
                data[i]=CPE_Enum_Const.value_INCORRECT;
                attr[i] = CPE_ValidityDataTypes.ValidityDataTypeNodata;
            }

            //override position for input  data
            for (int i = 0; i < this.num_col; i++)
            {
                if (index[i]>0)
                {
                    data[i] = data_read[this.index[i] - 1] * this.A[i] + this.B[i];
                    attr[i] = CPE_ValidityDataTypes.ValidityDataTypeGood;    
                }
            }

           // attr[0] = CPE_ValidityDataTypes.ValidityDataTypeError;

          //  attr[1] = CPE_ValidityDataTypes.ValidityDataTypeError;

            if (this.ReadCount % 50000 == 0)
            {
                Console.WriteLine();
                Console.Write("{0}--:", DateTime.Now);
            }
         //debug
            if (this.ReadCount % 10000 == 0)  Console.Write("*{0} rows*", this.ReadCount);
            //Console.WriteLine("*{0} rows*", this.ReadCount);

           //add data slice
           for (int i=0;i<this.num_col;i++)
           {
            input.InputData[i]=data[i];
            input.InputStatus[i] = attr[i];
           }
            
            this.ReadCount++;
            return result;
        }
    }
}