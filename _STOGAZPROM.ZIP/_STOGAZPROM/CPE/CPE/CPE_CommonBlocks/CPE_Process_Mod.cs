﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;


namespace CPE_CommonBlocks
{
    public class CPE_CfgData_Process_Mod
    {
        public int ProcessPeriod_ms { get; set; }    //length steady regim
        public int UpdatePeriod_ms { get; set; }    //shift steady regim  
        public List<double> Delta { get; set; }      //max alowable deviation on steady regim
        public List<double> MinValues { get; set; }  //max alowable minValue on steady regim
        public List<bool> DeltaAttr { get; set; }     //attribute for Delta
        public List<bool> MinValuesAttr { get; set; } //attribute for min
        public Dictionary<int, int> NameVariableProcess { get; set; }  //<name_var,input>
        public int PosInp { get; set; }    //Position in Slice.Data inputs
        public int PosOutMean { get; set; }    //Position in Slice.Data to put Mean
        public int PosOutDelta { get; set; }    //Position in Slice.Data to put Delta
        //constructor
        public CPE_CfgData_Process_Mod()
        {
            this.Delta = new List<double>();
            this.MinValues = new List<double>();
            this.DeltaAttr = new List<bool>();
            this.MinValuesAttr = new List<bool>();
            this.NameVariableProcess = new Dictionary<int, int>();
        }
    }

    public class CPE_Process_Mod : SliceProcessing
    {
        CPE_CfgData_Process_Mod cfg; //data config

        ////link to config
        //public int ProcessPeriod_ms { get { return this.cfg.ProcessPeriod_ms; } }    //length steady regim
        //public int UpdatePeriod_ms { get { return this.cfg.UpdatePeriod_ms; } }   //shift steady regim  
        //public List<double> Delta { get { return this.cfg.Delta; } }  //max alowable deviation on steady regim
        //public List<double> MinValues { get { return this.cfg.MinValues; } }  //max alowable minValue on steady regim
        //public List<bool> DeltaAttr { get { return this.cfg.DeltaAttr; } }   //attribute for Delta
        //public List<bool> MinValuesAttr { get { return this.cfg.MinValuesAttr; } }//attribute for min
        //public Dictionary<CPE_NV, int> NameVariableProcess { get { return this.cfg.NameVariableProcess; } }
        //public CPE_NameSliceColumn PosInp { get { return this.cfg.PosInp; } } //Position in Slice.Data inputs
        //public CPE_NameSliceColumn PosOutMean { get { return this.cfg.PosOutMean; } }    //Position in Slice.Data to put Mean
        //public CPE_NameSliceColumn PosOutDelta { get { return this.cfg.PosOutDelta; } }  //Position in Slice.Data to put Delta




        //member
        //privat
        DateTime reference_time = new DateTime(1900, 01, 01);
        List<Dictionary<int, double>> history = new List<Dictionary<int,double>>();
        List<DateTime> history_t = new List<DateTime>();


        //config
        public void Config(CPE_CfgData_Process_Mod confdata)
        {
            this.cfg = confdata;
            Func.Util_CheckSameNumberList("ModeDetector", cfg.MinValues, cfg.MinValuesAttr, cfg.NameVariableProcess,
                cfg.Delta, cfg.DeltaAttr);

        }

        public override void Init(Slice input)
        {
            //if there are not position add
            if (false == input.Data.ContainsKey(cfg.PosInp))
            {
                input.Data.Add(cfg.PosInp, new Dictionary<int, double>());
                input.DataStatus.Add(cfg.PosInp, new Dictionary<int, CPE_ValidityDataTypes>());
            }

            if (false == input.Data.ContainsKey(cfg.PosOutMean))
            {
                input.Data.Add(cfg.PosOutMean, new Dictionary<int, double>());
                input.DataStatus.Add(cfg.PosOutMean, new Dictionary<int, CPE_ValidityDataTypes>());
            }

            if (false == input.Data.ContainsKey(cfg.PosOutDelta))
            {
                input.Data.Add(cfg.PosOutDelta, new Dictionary<int, double>());
                input.DataStatus.Add(cfg.PosOutDelta, new Dictionary<int, CPE_ValidityDataTypes>());
            }
        }



        public override bool Process(Slice input)
        {
            bool result = true;
            int del_count = 0;



            ///******end make place for output
            ///3.пропуск времени между режимами
            ///

            //1
            Dictionary<int, double> data_in_dic=input.Data[cfg.PosInp];
            Dictionary<int, CPE_ValidityDataTypes> status_in_dic = input.DataStatus[cfg.PosInp];

            Dictionary<int, double> data_mean = input.Data[cfg.PosOutMean];
            Dictionary<int, CPE_ValidityDataTypes> status_mean = input.DataStatus[cfg.PosOutMean];

            Dictionary<int, double> data_delta = input.Data[cfg.PosOutDelta];
            Dictionary<int, CPE_ValidityDataTypes> status_delta = input.DataStatus[cfg.PosOutDelta];



            if ((this.reference_time - input.Timestamp) <= new TimeSpan(0, 0, this.cfg.ProcessPeriod_ms / 1000))
            {
                ///4 if status wrong clear history exit
                foreach (KeyValuePair<int, int> kv in cfg.NameVariableProcess)
                {
                    if (((true == cfg.MinValuesAttr[kv.Value]) || (true == cfg.DeltaAttr[kv.Value])) &&
                        (status_in_dic[kv.Key] != CPE_ValidityDataTypes.ValidityDataTypeGood) &&
                        (status_in_dic[kv.Key] != CPE_ValidityDataTypes.ValidityDataTypeHandmade))
                    {
                        this.history.Clear();
                        this.history_t.Clear();
                        result = false;
                        break;
                    }
                }

                if (true == result)
                {
                    history.Add(data_in_dic);
                    history_t.Add(input.Timestamp);

                    //if history enough

                    if ((input.Timestamp - history_t[0]) >= new TimeSpan(0, 0, this.cfg.ProcessPeriod_ms / 1000))
                    {
                        int del_count_min = 0;
                        int del_count_delta = 0;
                        Dictionary<int, double> res_delta = new Dictionary<int, double>();
                        Dictionary<int, double> min_delta = new Dictionary<int, double>();
                        Dictionary<int, double> max_delta = new Dictionary<int, double>();
                        foreach (int key in history[0].Keys)
                        {
                            res_delta.Add(key, 0);
                            min_delta.Add(key, Double.MaxValue);
                            max_delta.Add(key, Double.MinValue);
                        }


                        for (int i = history_t.Count - 1; i >= 0; i--)
                        { 
                            
                            //check delta

                            foreach (int key in history[0].Keys)
                            {
                                if (min_delta[key] > history[0][key]) min_delta[key] = history[i][key];
                                if (max_delta[key] < history[i][key]) max_delta[key] = history[i][key];
                                res_delta[key] = Math.Abs(max_delta[key] - min_delta[key]);
                            }

                            foreach (KeyValuePair<int, int> kv in cfg.NameVariableProcess)
                            {
                                //check min

                                if ((true == cfg.MinValuesAttr[kv.Value]))
                                {
                                    if (cfg.MinValues[kv.Value] > history[i][kv.Key])
                                    {
                                        result = false;
                                        del_count_min = i;
                                        break;
                                    }
                                }

                                if (true == cfg.DeltaAttr[kv.Value])
                                {
                                    if (cfg.Delta[kv.Value] < res_delta[kv.Key])
                                    {
                                        result = false;
                                        del_count_delta = i;
                                        break;
                                    }
                                }
                            }
                            if (false == result)
                            {
                                break;
                            }
                        }
                        if (false != result)
                        {
                            //find average
                            double mean;

                            foreach (int key in history[0].Keys)
                            {
                                mean = 0;
                                for (int i = 0; i < history.Count; i++)
                                {
                                    mean += history[i][key];
                                }
                                mean = mean / history.Count;
                                data_mean[key] = mean;
                                status_mean[key] = status_in_dic[key];
                                data_delta[key] = res_delta[key];
                                status_delta[key] = status_in_dic[key];
                            }

                            this.reference_time = history_t[0] +
                               new TimeSpan(0, 0, cfg.ProcessPeriod_ms / 1000) +
                               new TimeSpan(0, 0, cfg.UpdatePeriod_ms / 1000);

  
                            int del_count_loc = 0;
                            while (history_t[del_count_loc] - history_t[0] < new TimeSpan(0, 0, cfg.UpdatePeriod_ms / 1000))
                                del_count_loc++;
                            history_t.RemoveRange(0, del_count_loc + 1);
                            history.RemoveRange(0, del_count_loc + 1);

                            return result;
                        }
                        else
                        {
                            del_count = Math.Max(del_count_delta, del_count_min) + 1;
                            history.RemoveRange(0, del_count);
                            history_t.RemoveRange(0, del_count);
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
            else
            {
                result = false;
                history.Clear();
                history_t.Clear();
            }
            //end place

            if (this.reference_time == input.Timestamp)
            {
                for (int i = 0; i < input.OutputData.Length; i++)
                {
                    input.OutputStatus[i] = CPE_ValidityDataTypes.ValidityDataTypeOutdated;
                }
            }
            return result;
        }
    }
}
