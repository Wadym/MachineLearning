﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;

namespace CPE_CommonBlocks
{

    public class CPE_Converter : SliceProcessing
    {


        //member
        public Slice.Col PosInp { get; set; }    //Position in Slice.Data to put
        public Slice.Col PosOut { get; set; }    //Position in Slice.Data to put



        public CPE_Converter()
        {
                //set pos
            this.PosInp = Slice.Col.ISP;
            this.PosOut = Slice.Col.Converter;

           }

        

        public override bool Process(Slice input, Slice output, List<Slice> history)
        {
            bool result = false;
            List<double> in_data = new List<double>();
            List<int> in_attr_data = new List<int>();
            List<double> out_data = new List<double>();
            List<int> out_attr_data = new List<int>();

            int[] index;

            //initialize****************
            in_data = input.Links[PosInp];
            in_attr_data = input.LinksAttr[PosInp];

            for (int i = 0; i < in_data.Count; i++)
            {
                out_data.Add(-999);
                out_attr_data.Add(-1);
            }
            //**************************

            //---data with good (no convert) units
            index = new int[] { 1,2,3,17 };
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]] = in_attr_data[index[i]];
                out_data[index[i]] = this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 1, 0);
            }
            //kPa->Pa , kJ->
            index = new int[] { 0,8,14,18};
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]] = in_attr_data[index[i]];
                out_data[index[i]] = this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 1000, 0);
            }
            //MPa->Pa
            index = new int[] { 16 };
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]] = in_attr_data[index[i]];
                out_data[index[i]] = this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 1000000, 0);                
            }
            //C->K
            index = new int[] { 4,5,9,10,12 };
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]] = in_attr_data[index[i]];
                out_data[index[i]] = this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 0, 273.15); 
               
            }
            //MPa->absolute Pa
            index = new int[] { 6, 7, 13  };
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]]=Func.CompareAttribute(in_attr_data[0], in_attr_data[index[i]]);
                this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 1000000, out_data[0]);               
            }
            //m3/h(kg/h)->m3/s(kg/s)
            index = new int[] { 6, 7, 13 };
            for (int i = 1; i < index.Length; i++)
            {
                out_attr_data[index[i]] = in_attr_data[index[i]];
                out_data[index[i]] = this.ConvertValue(out_attr_data[index[i]], in_data[index[i]], 1 / 3600, 0);          
            }
            //output
            input.Data.Add(out_data);
            input.DataAttr.Add(out_attr_data);
            input.Links.Add(PosOut, input.Data[input.Data.Count - 1]);
            input.LinksAttr.Add(PosOut, input.DataAttr[input.DataAttr.Count - 1]);
            input.Pos_Name.Add(string.Format("CPE_Converter[{0}]: значения в СИ (и давление абсолютное) xMean[{1}]", input.Data.Count - 1, input.Data[input.Data.Count - 1].Count));

            result = true;
            return result;
        }
    }
}
