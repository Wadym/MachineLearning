﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using System.IO;

namespace CPE_CommonBlocks
{
    public class CPE_FileReared
{
        StreamReader reader_data;

        public string Filename {get;set;}            
        public DateTime StartTime {get;set;}
        public int TimeStepMs { get; set; }

        public int StartRow;
        public int ColumnTime;
        public List<int> ColumnCsv { get; set; }  //номер столбца (начиная с 1 ) для параметра во входном файле
        public List<int> ColumnSlice { get; set; }  //номер куда ложить в Slice  
        public List<double> A { get; set; }      //перевод входного сигнала в виде AX+B
        public List<double> B { get; set; }      //перевод входного сигнала в виде AX+B

        int ReadCount { get; set; }
        public bool StatusRead{get;set;} //flag to check that we miss first StartRow rows
       
        //constructor
        public CPE_FileReared()
        {
            StatusRead = false ;
            Filename = @"..\..\..\..\input.csv";
            ReadCount = 0;
            TimeStepMs = 2000;
            StartRow = 0;
            StartTime = DateTime.MinValue;
            
        }


        public CPE_FileReared(int inTimeStepMs):this()
        {
         //this.Filename= @"..\..\..\..\Data\orsha3_160304.csv";  
         this.Filename = @"..\Data\res5.csv";
         this.reader_data = new StreamReader(File.OpenRead(this.Filename));
         this.TimeStepMs = inTimeStepMs;
       
        }

        public CPE_FileReared(string name):this()
        {
            this.Filename = name;
            this.reader_data = new StreamReader(File.OpenRead(this.Filename));
        }

        public CPE_FileReared(string name, int start_row)
            : this(name)
        {
            StartRow = start_row;
        }

        public CPE_FileReared(string file_name, int row_start, int col_time,List<int> col_csv,
            List<int> col_slice,List<double> a,List<double> b):this(file_name,row_start)
        {
            //Filename = file_name;
            //StartRow = row_start;
            
            ColumnCsv = col_csv;
            ColumnSlice = col_slice;
            ColumnTime = col_time;
            A = a;
            B = b;
            Func.Util_CheckSameNumberList("file reader",ColumnCsv,col_slice,A,B);
        }


        public bool ReadLine(Slice input)
        {
            
            
            string line = reader_data.ReadLine();
            ReadCount++;
            bool result = true;
            while (false == StatusRead)
            {
                line = reader_data.ReadLine();
                ReadCount++;
                if (ReadCount>StartRow) StatusRead = true;
            }
            if (line == null)
            {
                this.reader_data.Close();
                return false;
            }

           //read data****
            //coma vs dot
            line = line.Replace(',', '.');
           // line = line.Replace('.', ',');
            //line = line.Replace(',', ',');
            string[] lines = line.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
      
    
            List<double> data_read = new List<double>();
            for (int i = 0; i < lines.Length; i++)
            {
                data_read.Add(Convert.ToDouble(lines[i]));
            }
            //*************

            input.Timestamp = DateTime.FromOADate(data_read[ColumnTime]);
           //     this.StartTime + new TimeSpan(0, 0, this.TimeStepMs/1000 * this.ReadCount);


            //override position for input  data
            for (int i = 0; i < ColumnCsv.Count; i++)
            {
                int col_csv=ColumnCsv[i];
                int col_slice=ColumnSlice[i];
                input.InputData[col_slice] = data_read[col_csv]*A[i]+B[i];
                input.InputStatus[col_slice] = (CPE_ValidityDataTypes)data_read[col_csv + 1];
  
                }
            

           // attr[0] = CPE_ValidityDataTypes.ValidityDataTypeError;

          //  attr[1] = CPE_ValidityDataTypes.ValidityDataTypeError;

            if(ReadCount % 50000 == 0)
            {
                Console.WriteLine();
                Console.Write("{0}--:", DateTime.Now);
            }
         //debug
            if (this.ReadCount % 5000 == 0)  Console.Write("*{0} rows*", this.ReadCount);
            //Console.WriteLine("*{0} rows*", this.ReadCount);

         //   for debug
            //if (ReadCount > 20000)
            //{
            //    result = false;
            //}
           
            return result;
        }
    }
}
