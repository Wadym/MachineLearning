﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;

namespace CPE_CommonBlocks
{
    public class CPE_cfg_Output
    {
        public List<int[]> ListVariable { get; set; } //output [output#][0] - (position (column)) [output#][1] - name var
        
       
        public CPE_cfg_Output()
        {
            ListVariable = new List<int[]>();
        }
    }
    public class CPE_Output : SliceProcessing
    {
        public CPE_cfg_Output cfg;

        public CPE_Output()
        {
            cfg = new CPE_cfg_Output();
        }

        public void Config(CPE_cfg_Output confdata)
        {
            string message_public = "Не правильно сконфигурирован модуль CPE_Output\n";
            cfg = confdata;
            
            if (0 == cfg.ListVariable.Count)
            {
                throw new Exception(string.Format("{0}(не заданы переменные для вывода)", message_public));
            }

            for (int i=0; i < cfg.ListVariable.Count;i++ )
            {
                if (2!=cfg.ListVariable[i].Length)
                {
                    throw new Exception(string.Format("{0}(неправильно указана позиция переменной для вывода)", message_public));
                }

            }

        }

        public override bool Process(Slice input)
        {
            bool result = true;
            for (int i = 0; i < cfg.ListVariable.Count;i++ )
            {
                int position = cfg.ListVariable[i][0];
                int name = cfg.ListVariable[i][1];
                input.OutputData[i] = input.Data[position][name];
                input.OutputStatus[i] = input.DataStatus[position][name];
            }

            return result;
        }
    }
}
