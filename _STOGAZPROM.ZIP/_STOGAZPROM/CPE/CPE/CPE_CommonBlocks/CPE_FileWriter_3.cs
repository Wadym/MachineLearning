﻿//using System;
//using System.Collections.Generic;
//using System.Text;
//using CPE_Lib;
//using System.IO;
//using System.Windows.Forms;
//using System.Diagnostics;


//namespace CPE_CommonBlocks
//{
//    public class CPE_FileWriter_3
//    {
//        public StreamWriter writer;
//        public string Filename { get; set; }
//        public CPE_NameSliceColumn Pos { get; set; }
//        int first_line = 0;

//        public CPE_FileWriter_3()
//        {
//            this.Filename = @"..\..\..\..\Data\out.csv";
//            this.writer = new StreamWriter(this.Filename);
//        }

//        public CPE_FileWriter_3(string file_name, CPE_NameSliceColumn position)
//        {
//            this.Filename = file_name;
//            this.writer = new StreamWriter(this.Filename);
//            this.Pos = position;
//        }


//        public bool Write(Slice input)
//        {
            
//            try
//            {              
//                if (true == input.LinkData.ContainsKey(this.Pos))
//                {
//                   //print head line
//                    string data = "";
//                    if (0 == first_line)
//                    {
                        
//                        string[] name_variable = new string[input.LinkDictionary[Pos].Count];
//                        foreach (KeyValuePair<CPE_NV, int> kv in input.LinkDictionary[Pos])
//                        {
//                            name_variable[kv.Value] = kv.Key.ToString();
//                        }
//                        for (int i = 0; i < name_variable.Length; i++)
//                        {
//                             data += name_variable[i]+";";
//                        }
//                        data += "Time";
//                        writer.WriteLine(data);
//                        first_line = 1;
//                    }

//                    data = "";
//                        for (int j = 0; j < input.LinkData[Pos].Count; j++)
//                        {
//                            data += string.Format("{0:g6};", input.LinkData[Pos][j]);
//                        }
                    
//                    data += string.Format("{0:g12}", input.Timestamp.ToOADate());
//                    data = data.Replace(',', '.');
//                    writer.WriteLine(data);
//                }


//            }
//            catch (Exception ex)
//            {
//                Debug.WriteLine(ex.Message);
//            }
//            return true;
//        }

//        public void Close()
//        {
//            writer.Close();
//        }
//    }
//}
