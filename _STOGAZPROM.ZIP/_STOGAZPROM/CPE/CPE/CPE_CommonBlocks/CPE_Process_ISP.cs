﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;



namespace CPE_CommonBlocks
{
    //config data
    public class CPE_CfgData_Process_ISP
    {
        public List<CPE_cfg_Attr> Attribute { get; set; }            //attribute from input data
        public List<CPE_cfg_defValue> AttributeDefault { get; set; } //attribute default values(0 - usual/1-if status !=0 use default/ 2 - in any case use default value)
        public List<double> DefaultValue { get; set; }             //Default values
        public List<bool> AttrMax { get; set; } //attribute for test Max (true-check max; false - don't check)
        public List<double> Max { get; set; }
        public List<bool> AttrMin { get; set; } //attribute for test Min (true-check min; false - don't check)       
        public List<double> Min { get; set; }
        //public Dictionary<int, int> NameVariableProcess { get; set; } //dictuionary related only variable for process ISP
        public Dictionary<int, int> NameVariable { get; set; } //name  related InputData Dictionary <name var in slice,input#>
        public int Position { get; set; }



        public CPE_CfgData_Process_ISP()
        {
            //initialize
            this.Attribute = new List<CPE_cfg_Attr>();
            this.AttributeDefault = new List<CPE_cfg_defValue>();
            this.DefaultValue = new List<double>();
            this.AttrMin = new List<bool>();
            this.Min = new List<double>();
            this.AttrMax = new List<bool>();
            this.Max = new List<double>();
            NameVariable = new  Dictionary<int,int>();
            //this.NameVariableProcess = new Dictionary<CPE_NV, int>();
            //this.NameVariableInputData = new Dictionary<CPE_NV, int>();
        }



    }

    public class CPE_Process_ISP : SliceProcessing
    {
        //member
        CPE_CfgData_Process_ISP cfg = new CPE_CfgData_Process_ISP();


        //constructor
        public CPE_Process_ISP()
        {
        }



        //config
        public void Config(CPE_CfgData_Process_ISP confdata)
        {
            this.cfg = confdata;
            if (0 != cfg.NameVariable.Count)
            {
                Func.Util_CheckSameNumberList("ISP", cfg.Attribute, cfg.AttributeDefault, cfg.AttrMax, cfg.AttrMin,
                   cfg.DefaultValue, cfg.Max, cfg.Min, cfg.NameVariable);
            }
            else
            {
                Func.Util_CheckSameNumberList("ISP", cfg.Attribute, cfg.AttributeDefault, cfg.AttrMax, cfg.AttrMin,
                   cfg.DefaultValue, cfg.Max, cfg.Min);
                for (int i = 0; i < cfg.Attribute.Count; i++)
                {
                    cfg.NameVariable.Add(i,i);
                }
            }          
        }

        public override void Init(Slice input)
        {
            //if there are not position add
            if (false == input.Data.ContainsKey(cfg.Position))
            {
                input.Data.Add(cfg.Position, new Dictionary<int, double>());
                input.DataStatus.Add(cfg.Position, new Dictionary<int, CPE_ValidityDataTypes>());
            }
        }

        //PROCESS
        public override bool Process(Slice input)
        {
            
            bool result = false;
            //clear previous state
            foreach (int position in input.Data.Keys)
            {
                input.Data[position].Clear();
                input.DataStatus[position].Clear();
            }
            //
            foreach (int name_variable in cfg.NameVariable.Keys)      
              {
                int i = cfg.NameVariable[name_variable]; //# input
                if ((CPE_cfg_Attr.Use == cfg.Attribute[i]) ||
                    (CPE_cfg_Attr.UseOption == cfg.Attribute[i]))
                {
                    if ((CPE_ValidityDataTypes.ValidityDataTypeGood == input.InputStatus[i]) ||
                        (CPE_ValidityDataTypes.ValidityDataTypeHandmade == input.InputStatus[i]))
                    {
                        if (CPE_cfg_defValue.Forced == cfg.AttributeDefault[i])
                        {
                            input.Data[cfg.Position][name_variable] = cfg.DefaultValue[i];
                            input.DataStatus[cfg.Position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeHandmade;
                        }
                        else
                        {
                            input.Data[cfg.Position][name_variable] = input.InputData[i];
                            input.DataStatus[cfg.Position][name_variable] = input.InputStatus[i];
                        }
                    }
                    else
                    {
                        if ((CPE_cfg_defValue.Use == this.cfg.AttributeDefault[i]) ||
                           (CPE_cfg_defValue.Forced == this.cfg.AttributeDefault[i]))
                        {
                            input.Data[cfg.Position][name_variable] = cfg.DefaultValue[i];
                            input.DataStatus[cfg.Position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeHandmade;
                        }
                        else
                        {
                            input.Data[cfg.Position][name_variable] = input.InputData[i];
                            input.DataStatus[cfg.Position][name_variable] = input.InputStatus[i];
                            continue;
                        }

                    }
                    //min_max
                    if (this.cfg.AttrMin[i] && (this.cfg.Min[i] > input.Data[cfg.Position][name_variable]))
                    {
                        input.DataStatus[cfg.Position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeDoubtful;
                    }
                    if (this.cfg.AttrMax[i] && (this.cfg.Max[i] < input.Data[cfg.Position][name_variable]))
                    {
                        input.DataStatus[cfg.Position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeDoubtful;
                    }
                }
                else
                {
                    input.Data[cfg.Position][name_variable] = input.InputData[i];
                    input.DataStatus[cfg.Position][name_variable] = CPE_ValidityDataTypes.ValidityDataTypeNodata;
                }
            }

            //in any case return true
            result = true;
            return result;
        }
    }
}