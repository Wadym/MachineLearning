﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;

namespace CPE_CommonBlocks
{
    public class Polynoms
    {

        public int ID { get; set; }//ID
        public int Num { get; set; }//количество полиномов для кривой (2 или 1)
        public double Min { get; set; }//минимально допустимое значение для полинома
        public double Max { get; set; }//максимально допустимое значение для полинома
        public double Point { get; set; } //точка раздела полинома
        public double[] Coeff { get; set; } //коэффициенты полинома

        public Polynoms()
        {
            this.ID = new int();
            this.Num = new int();
            this.Min = new double();
            this.Max = new double();
            this.Point = new double();
            this.Coeff = new double[12];
        }


        public CPE_ValidityDataTypes Status(double X)
        {
            if ((Min > X) || (X > Max))
            {
                return CPE_ValidityDataTypes.ValidityDataTypeDoubtful;
            }
            else
            {
                return CPE_ValidityDataTypes.ValidityDataTypeGood;
            }

        }

        public double Value(double X)
        {
            double result = 0;
            if ((this.Min < X) && (X < this.Max))
            {
                if ((this.Num > 1) && (this.Point < X))
                {
                    for (int i = 6; i < 12; i++) result += this.Coeff[i] * Math.Pow(X, i - 6);
                }
                else
                {
                    for (int i = 0; i < 6; i++) result += this.Coeff[i] * Math.Pow(X, i);
                }
            }
            else
            {
                result = -999;
            }
            return result;
        }

        public int Attr(double X)
        {
            int result = -1;
            if ((this.Min < X) && (X < this.Max))
            {
                result = 0;
            }
            else
            {
                result = -1;
            }
            return result;
        }



    }
}
