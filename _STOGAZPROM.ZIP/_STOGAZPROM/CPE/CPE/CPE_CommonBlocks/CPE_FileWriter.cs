﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;


namespace CPE_CommonBlocks
{
    public class CPE_FileWriter
    {
        public StreamWriter writer {get;set;}
        public string Filename { get; set; }
        public int position { get; set;}
        public bool write_status;



        public List<int> name_variable=new List<int>();
        public bool headline=false;     

        public CPE_FileWriter()
        {
            Filename = @"..\..\..\..\Data\out.csv";
           // writer = new StreamWriter(this.Filename);
            write_status = false;
            
        }
        
        public CPE_FileWriter(string file_name)
        {
            this.Filename = file_name;
            write_status = false;
           
            this.writer = new StreamWriter(this.Filename);
           
        }

        public CPE_FileWriter(string file_name, int position)
               : this(file_name)
        {
              this.position = position;
        }



        public CPE_FileWriter(string file_name, int position, bool status_input)
               : this(file_name, position)
           {
               write_status = status_input;
      
           }

        
           public bool Write<T>(Slice input) where T:struct,IConvertible
           {
               string data="Time;";
               if (input.Data[position].Count > 0)
               {
                   if ((false == headline) )
                   {
                       foreach (int name in input.Data[position].Keys)
                       {
                           name_variable.Add(name);
                           data += ((T)(object)name).ToString();
                           data += ";";
                           if (true == write_status)
                           {
                               data += "STATUS_"+((T)(object)name).ToString();
                               data += ";";
                           }
                       }

                       writer.WriteLine(data);
                       headline = true;
                   }

                   Write(input);

                   return true;
               }
               else
                   return false;

           }

           public void WriteHeadLine<T>(Slice input) where T : struct, IConvertible
           {
               
               //make list
              
               foreach (int name in input.Data[position].Keys)
               {
                   if ((name_variable.Count==0)||(!name_variable.Exists(x => x == name)))
                   {
                       name_variable.Add(name);
                   }
               }

               //print
               string data = "Time;";
               for (int i=0; i< name_variable.Count;i++)
               {
                   data += ((T)(object)name_variable[i]).ToString();
                   data += ";";
                   if (true == write_status)
                   {
                       data += "STATUS_" + ((T)(object)name_variable[i]).ToString();
                       data += ";";
                   }

               }

               writer.WriteLine(data);
               headline = true;;
               return;
               }

           
         
         
        
        public bool Write(Slice input)
           {
               try
               {                   
                   if (true == input.Data.ContainsKey(position))
                   {
                       string data = "";
                       string temp = "";
                       string temp1 = "";
                   
                                                                                                                           
                       if (true != write_status)
                       {
                           data += string.Format("{0:g12};", input.Timestamp.ToOADate());
                           for (int j = 0; j < name_variable.Count; j++)
                           {
                               if (input.Data[position].ContainsKey(name_variable[j]))
                               {
                                   temp = input.Data[position][name_variable[j]].ToString();


                               }
                               else
                               {
                                   temp = "";
                               }
                               data =data+temp+ ";";
                               
                              // data += string.Format("{0:g6};", input.Data[position][name_variable[j]]);
                           }
                           data = data.Replace(',', '.');
                           writer.WriteLine(data);
                       }
                       else
                       {
                           data = "";
                           data += string.Format("{0:g12};", input.Timestamp.ToOADate());
                           for (int j = 0; j < name_variable.Count; j++)
                           {
                               if (input.Data[position].ContainsKey(name_variable[j]))
                               {
                                   temp = input.Data[position][name_variable[j]].ToString();
                                   temp1 = ((int)input.DataStatus[position][name_variable[j]]).ToString();
                               }
                               else
                               {
                                   temp = "";
                                   temp1 = "";
                               }
                               data =data+temp+";"+temp1+";";
                               
                            //   data += string.Format("{0:g6};", input.Data[position][name_variable[j]]);
                            //   data += string.Format("{0};", (int)input.DataStatus[position][name_variable[j]]);
                           }
                           data = data.Replace(',', '.');
                           writer.WriteLine(data);
                       }
                   }
               }
               catch (Exception ex)
               {
                   Debug.WriteLine(ex.Message);
               }
               return true;
           }
          
        



        public void Close()
        {
            writer.Close();
        }
    }
}
