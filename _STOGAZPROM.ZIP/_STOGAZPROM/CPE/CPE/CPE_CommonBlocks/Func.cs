﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using System.Collections;



namespace CPE_CommonBlocks
{
    public class Func
    {
        //класс Констант
        static public double PrivTemperature(double t_c, double tambient_C) //приведение по температуре (K)
        {
            return (t_c + 273.15) * 288.15 / (tambient_C + 273.15) - 273.15;
        }
        static public double PrivPressure(double Pressure, double PressureAmbient_MPa) //приведение по температуре (K)
        {
            return Pressure * 101325 / PressureAmbient_MPa / 1000000;
        }

        static public double PrivPower(double N, double tambient_C, double Pambient_MPa) //приведение по мощности (K,Па)
        {
            return N * 101325 / Pambient_MPa / 1000000 * Math.Sqrt(288.15 / (tambient_C + 273.15));
        }

        static public double PrivRPM(double n, double tambient_C) //приведение оборотов
        {
            return n * Math.Sqrt(288.15 / (tambient_C + 273.15));
        }

        //политропный КПД согласно СТО   
        static public double EfficiencyPolytropCBN(double t1_c, double t2_c, double P1_MPa, double P2_Mpa, double DensityUnderNormalCondition)
        {
            double tmean = (t2_c + t1_c) / 2;
            double m_t = Math.Log10((t2_c + 273.15) / (t1_c + 273.15)) / Math.Log10(P2_Mpa / P1_MPa);
            double k_k_1 = 4.16 + 0.0041 * (tmean - 10) + 3.93 * (DensityUnderNormalCondition / 1.2044 - 0.55) + 5.0 * (m_t - 0.3);
            return 1 / k_k_1 / m_t;
        }
        //коэффициент сжимаемости газа согласно СТО
        static public double GasCompressibility(double t_C, double P_MPa, double DensityUnderNormalCondition)
        {
            return 1 - ((10.2 * P_MPa - 6) * (0.345E-2 * DensityUnderNormalCondition / 1.2044 - 0.446E-3) + 0.015) * (1.3 - 0.0144 * (t_C + 273.15 - 283.2));
        }
        //плотность газа
        static public double GasDensity(double t_C, double P_MPa, double R_JkgK, double z) //плотность газа (К, Па, Дж/кг)
        {
            return P_MPa * 1000000 / R_JkgK / (t_C + 273.15) / z;
        }


        //0 - no unit;
        //1 - kPa->MPa ; J - >kJ; (*0.001)
        //2- C->K;                 (+273.15) 
        //3 -kg/s->kg/h            (*3600)
        //m3/h - > m3/s
        static public double ConvertUnits(int unit, double value)
        {
            switch (unit)
            {
                //case 2: return value * 3600;
                case 1: return 0.001 * value;
                default: return value;
            }
        }


        //расход мерное устройство
        //A коэф расхода (1/м2); DropPressure - Па; Density - плотность кг/м3
        static public double FlowMasDiafr(double A_kgs, double DropPressure_MPa, double Density_kgm3)
        {
            return A_kgs * Math.Sqrt(DropPressure_MPa / 9.80665e-6 * Density_kgm3);
        }
        //раздел утилит





        static public CPE_ValidityDataTypes Utill_Status(Dictionary<int, CPE_ValidityDataTypes> status, int[] name_in)
        {
            //make array with index and data
            CPE_ValidityDataTypes result = CPE_ValidityDataTypes.ValidityDataTypeGood;
            for (int i = 0; i < name_in.Length; i++)
            {
                int name = name_in[i];
                if ((CPE_ValidityDataTypes.ValidityDataTypeGood != status[name]) &&
                 (CPE_ValidityDataTypes.ValidityDataTypeHandmade != status[name]))
                {
                    result = CPE_ValidityDataTypes.ValidityDataTypeError;
                    break;
                }
                else
                    if (CPE_ValidityDataTypes.ValidityDataTypeHandmade== status[name])
                    {
                        result = CPE_ValidityDataTypes.ValidityDataTypeHandmade;
                    }
            }
            return result;
        }

        public delegate double model(Slice x);
        ///**********************************************************
        //procedure to calculate with attribute
        //key_out - output name
        //keys - inputs names
        //calculate if status== Good or Handmade
        //          if status another -value=incorect status=Error               
        //      note: if use variable which is not in key -> get exception   
        static public void CalcWithAttributeNew<T1,T2>(int[] pos_name_out,
            Dictionary<int,int[]> pos_name_in, Slice slice,
            model function)
        {
            //make array with index and data
            int pos_out = pos_name_out[0];
            int name_out = pos_name_out[1];
            foreach (KeyValuePair<int, int[]> pos_name in pos_name_in)
            {
                int position = pos_name.Key;
                for (int i = 0; i < pos_name.Value.Length; i++)
                {
                    int name = pos_name.Value[i];

                    if ((slice.DataStatus[position][name] != CPE_ValidityDataTypes.ValidityDataTypeGood) &&
                     (slice.DataStatus[position][name] != CPE_ValidityDataTypes.ValidityDataTypeHandmade))
                    {
                        slice.DataStatus[pos_out][name_out] = CPE_ValidityDataTypes.ValidityDataTypeError;
                        break;
                    }
                    else if (slice.DataStatus[position][name] != CPE_ValidityDataTypes.ValidityDataTypeGood)
                    {
                        slice.DataStatus[pos_out][name_out] = CPE_ValidityDataTypes.ValidityDataTypeHandmade;
                    }
                }
            }

            if ((slice.DataStatus[pos_out][name_out] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
                 (slice.DataStatus[pos_out][name_out] == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
            {
                try
                {
                    slice.Data[pos_out][name_out] = function(slice);
                }
                catch (KeyNotFoundException)
                {
                    throw new Exception(string.Format("ошибка при вычислении формул"));
                }
            }
            else
            {
                slice.Data[pos_out][name_out] = CPE_Enum_Const.value_INCORRECT;
                slice.DataStatus[pos_out][name_out] = CPE_ValidityDataTypes.ValidityDataTypeError;
            }

            //check for infinity 
            if ((Double.IsInfinity(slice.Data[pos_out][name_out])) || (Double.IsNaN(slice.Data[pos_out][name_out])))
            {
                slice.Data[pos_out][name_out] = CPE_Enum_Const.value_INCORRECT;
                slice.DataStatus[pos_out][name_out] = CPE_ValidityDataTypes.ValidityDataTypeError;
            }
            return;
        }



















        ////*********************************
        // //**********************************************************
        //procedure to calculate with attribute
        //key_out - output name
        //keys - inputs names
        //calculate if status== Good or Handmade
        //          if status another -value=incorect status=Error               
        //      note: if use variable which is not in key -> get exception   
        //static public void CalcWithAttributeNew(CPE_NV key_out, CPE_NV[] keys,
        //         Dictionary<CPE_NV, double> data_dic_in, Dictionary<CPE_NV, CPE_ValidityDataTypes> status_dic_in, simulation_new model)
        //{
        //    //make array with index and data

        //    CPE_ValidityDataTypes status_res;

        //    Dictionary<CPE_NV, double> data_dic = new Dictionary<CPE_NV, double>();
        //    Dictionary<CPE_NV, CPE_ValidityDataTypes> status_dic = new Dictionary<CPE_NV, CPE_ValidityDataTypes>();


        //    for (int i = 0; i < keys.Length; i++)
        //    {
        //        data_dic.Add(keys[i], data_dic_in[keys[i]]);
        //        status_dic.Add(keys[i], status_dic_in[keys[i]]);
        //    }
        //    status_res = CPE_ValidityDataTypes.ValidityDataTypeGood;
        //    foreach (KeyValuePair<CPE_NV, CPE_ValidityDataTypes> kv in status_dic)
        //    {
        //        if ((kv.Value != CPE_ValidityDataTypes.ValidityDataTypeGood) &&
        //         (kv.Value != CPE_ValidityDataTypes.ValidityDataTypeHandmade))
        //        {
        //            status_res = CPE_ValidityDataTypes.ValidityDataTypeError;
        //            break;
        //        }
        //        else if (kv.Value != CPE_ValidityDataTypes.ValidityDataTypeGood)
        //        {
        //            status_res = CPE_ValidityDataTypes.ValidityDataTypeHandmade;
        //        }
        //    }

        //    if ((status_res == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
        //         (status_res == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
        //    {

        //        try
        //        {

        //            AddElementToDictionary(key_out, model(data_dic, status_dic), status_res, data_dic_in, status_dic_in);

        //        }
        //        catch (KeyNotFoundException)
        //        {
        //            throw new Exception(string.Format("Сылка на недопустимый (неопределенный)элемент словоря"));
        //        }
        //    }
        //    else
        //    {
        //        AddElementToDictionary(key_out, CPE_Enum_Const.value_INCORRECT, CPE_ValidityDataTypes.ValidityDataTypeError,data_dic_in, status_dic_in);
               
        //    }

        //    //check for infinity 
        //    if ((Double.IsInfinity(data_dic_in[key_out])) || (Double.IsNaN(data_dic_in[key_out])))
        //    {
        //        AddElementToDictionary(key_out, CPE_Enum_Const.value_INCORRECT, CPE_ValidityDataTypes.ValidityDataTypeError, data_dic_in, status_dic_in);
        //    }
        //    return;
        //}








        //**********************************







        static public void AddElementToDictionary<T, T1, T2>(T key, T1 data_value, T2 data_status, Dictionary<T, T1> data_dic, Dictionary<T, T2> status_dic)
        {
            if (data_dic.ContainsKey(key))
            {
                data_dic[key] = data_value;
                status_dic[key] = data_status;
            }
            else
            {
                data_dic.Add(key,data_value);
                status_dic.Add(key,data_status);
            }
        }





        //public delegate double simulation(double[] data);
        //public delegate double simulation_new(Dictionary<CPE_NV, double> data, Dictionary<CPE_NV, CPE_ValidityDataTypes> status);

        //static public void CalcWithAttribute(int option, int[] index, int out_index, List<double> in_data, List<int> in_attr,
        //                                        List<double> out_data, List<int> out_attr, simulation model)
        //{
        //    //make array with index and data
        //    int[] ind = new int[index.Length];
        //    double[] temp_attr = new double[index.Length];
        //    double[] temp_data = new double[index.Length];


        //    for (int i = 0; i < index.Length; i++)
        //    {

        //        ind[i] = index[i];
        //        temp_data[i] = in_data[index[i]];
        //        temp_attr[i] = in_attr[index[i]];
        //    }


        //    //check attribute
        //    if (option == 0)
        //    {
        //        if (Array.Exists(temp_attr, x => (x == -1))) out_attr[out_index] = -1;
        //        else if (Array.Exists(temp_attr, x => (x == 1))) out_attr[out_index] = 1;
        //        else out_attr[out_index] = 0;
        //    }
        //    else
        //    {
        //        if (Array.Exists(temp_attr, x => (x == 1))) out_attr[out_index] = 1;
        //        else if (Array.Exists(temp_attr, x => (x == 0))) out_attr[out_index] = 0;
        //        else out_attr[out_index] = -1;
        //    }
        //    if (out_attr[out_index] == -1)
        //        out_data[out_index] = -999;
        //    else
        //    {
        //        out_data[out_index] = model(temp_data);
        //        //check for infinity 
        //        if ((Double.IsInfinity(out_data[out_index])) || (Double.IsNaN(out_data[out_index])))
        //        {
        //            out_data[out_index] = -999;
        //            out_attr[out_index] = -1;
        //        }
        //    }
        //    return;
        //}


//****************Utilities for work

        public static void Utill_CheckDictionaryKey<T1, T2>(string name_process, T1[] keys, Dictionary<T1, T2> dict)
        {
            for (int i = 0; i < keys.Length; i++)
            {
                if (!dict.ContainsKey(keys[i]))
                {
                    throw new Exception(string.Format("ощибка конфигурации блока {0}. Не все данные заданы.\n Не задано :{1}", name_process, keys[i]));
                }
            }
        }
        //check that we have the same number and exception if no
        static public void Util_CheckSameNumberList(string name_class, params ICollection [] list) 
        {
            int count = list[0].Count;
            for (int i = 0; i < list.Length; i++)
            {
                if (count != list[i].Count)
                {
                    throw new Exception(string.Format("Неправильно сконфигурирован модуль {0}. Не все параметры заданы.\n(не совпадает число элементов в списках исходных данных)", name_class));
                }             
            }
        }



        ////procedure get data from Slice
        //static public void Utill_GetData(Slice input, CPE_NameSliceColumn position,
        //        ref Dictionary<CPE_NV, double> data, ref Dictionary<CPE_NV, CPE_ValidityDataTypes> status)
        //{
        //   foreach(KeyValuePair <CPE_NV,int> kv in input.LinkDictionary[position])
        //   {
        //       data.Add(kv.Key, input.LinkData[position][kv.Value]);
        //       status.Add(kv.Key, input.LinkStatus[position][kv.Value]);
        //   }
        //}


       ////save data to Slice
       ////if there are not "position"-> make new and save
       ////if there are "position" in Slice -> override data
       // static public void Utill_SaveData(Slice input, CPE_NameSliceColumn position,
       //        ref Dictionary<CPE_NV, double> data_dic, ref Dictionary<CPE_NV, CPE_ValidityDataTypes> status_dic)
       // {
       //    //add new position
       //     if (false == input.LinkDictionary.ContainsKey(position))
       //     {
       //         List<double> data_list = new List<double>();
       //         List<CPE_ValidityDataTypes> status_list = new List<CPE_ValidityDataTypes>();
       //         Dictionary<CPE_NV, int> name_dic = new Dictionary<CPE_NV, int>();
       //         int i = 0;
       //         foreach (CPE_NV key in data_dic.Keys)
       //         {
       //             data_list.Add(data_dic[key]);
       //             status_list.Add(status_dic[key]);
       //             name_dic.Add(key, i);
       //             i++;
       //         }

       //         input.Data.Add(data_list);
       //         input.DataStatus.Add(status_list);
       //         input.LinkData.Add(position, input.Data[input.Data.Count - 1]);
       //         input.LinkStatus.Add(position, input.DataStatus[input.Data.Count - 1]);
       //         input.LinkDictionary.Add(position, name_dic);
       //     }
       //     else
       //     {
       //         int i = input.LinkData[position].Count;
       //         foreach (CPE_NV key in data_dic.Keys)
       //         {
       //             if (false == input.LinkDictionary[position].ContainsKey(key))
       //             {
       //                 input.LinkData[position].Add(data_dic[key]);
       //                 input.LinkStatus[position].Add(status_dic[key]);
       //                 input.LinkDictionary[position].Add(key, i);
       //                 i++;
       //             }
       //             else
       //             {
       //                 int index=input.LinkDictionary[position][key] ;
       //                 input.LinkData[position][index] = data_dic[key];
       //                 input.LinkStatus[position][index] = status_dic[key];
       //             }
       //         }
       //     }

       // }
            
    }
}
