﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;

//CPE
using CPE_Lib;
using CPE_CommonBlocks;
using CPE_Methodics_STO.ConfigMethodicSTO;

namespace CPE_Methodics_STO
{
   


    class CPE_Methodic_STO : CPE_Methodic
    {
        CPE_Engine cpe_engine = new CPE_Engine();
        public Polynoms[] Polynom { get; set; }


        public CPE_Methodic_STO()
        {
            Polynom = new Polynoms[4];
        }


       
        public override bool Config(string data, CPE_DataBlobAccess data_access)
        {

            //get data
            CPE_ConfigMethodic_STO confdata = new CPE_ConfigMethodic_STO();
            //confdata.SetNameVariable();
            confdata.GetData(data); //read xml

           
            //isp
            CPE_Process_ISP isp = new CPE_Process_ISP();
            isp.Config(confdata.DataProcess.Isp);
            cpe_engine.Slice_Process.Add(isp);

            //pre
            CPE_Process1_Pre_STO pre = new CPE_Process1_Pre_STO();
            pre.Config(confdata.DataProcess.Pre);
            cpe_engine.Slice_Process.Add(pre);

            //mode
            CPE_Process_Mod mode = new CPE_Process_Mod();
            mode.Config(confdata.DataProcess.ModeDetector);
            cpe_engine.Slice_Process.Add(mode);


            ////nominal data
            CPE_Process3_Nominal nominal = new CPE_Process3_Nominal();
            nominal.Config(confdata.DataProcess.Nom);
            cpe_engine.Slice_Process.Add(nominal);

            ////cluster
            CPE_Process4_cluster_simulate cluster = new CPE_Process4_cluster_simulate();
            cluster.Config(confdata.DataProcess.Cluster);
         //   cpe_engine.Slice_Process.Add(cluster);

            //real cluster
            CPE_ClusterProcessor cluster_real = new CPE_ClusterProcessor();
            cluster_real.Config(confdata.DataProcess.ClusterReal, data_access);
            cpe_engine.Slice_Process.Add(cluster_real);

            //post
            CPE_Process5_post post = new CPE_Process5_post();
            post.Config(confdata.DataProcess.Post);
            cpe_engine.Slice_Process.Add(post);

           // output
            CPE_Output output = new CPE_Output();
            output.Config(confdata.DataProcess.Output);
            cpe_engine.Slice_Process.Add(output);

            Polynom[0] = cluster.cfg.PolynomDict[CPE_NamePolynom.ef_cbn_V1];
            Polynom[1] = cluster.cfg.PolynomDict[CPE_NamePolynom.N_T04];
            Polynom[2] = cluster.cfg.PolynomDict[CPE_NamePolynom.N_n2];
            Polynom[3] = cluster.cfg.PolynomDict[CPE_NamePolynom.G_t_N];
            bool result = true;
            return result;
        }

        public override void Init(Slice data)
        {
            for (int i = 0; i < cpe_engine.Slice_Process.Count; i++)
            {
                cpe_engine.Slice_Process[i].Init(data);
            }
        }

        public override void Activate()
        {
            for (int i = 0; i < cpe_engine.Slice_Process.Count; i++)
            {
                cpe_engine.Slice_Process[i].Activate();
            }
        }

        public override void Execute(Slice data)
        {
            cpe_engine.Process(data);
        }

        public override void DeActivate()
        {
            for (int i = 0; i < cpe_engine.Slice_Process.Count; i++)
            {
                cpe_engine.Slice_Process[i].DeActivate();
            }
        }

        public override void DeInit()
        {
            for (int i = 0; i < cpe_engine.Slice_Process.Count; i++)
            {
                cpe_engine.Slice_Process[i].DeInit();
            }
        }
    }
}
