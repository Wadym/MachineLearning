﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_CommonBlocks.ConfigMethodicCommon;
using CPE_CommonBlocks;
using ClusterProcessorClassLibrary;

using System.Xml.Serialization;
using CPE_Lib;

namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    [XmlType("MethodicConfig")] 
    public class ConfigDataXML_STO:CPE_ConfigDataXML
    {
        [XmlElement("MethodicName")]
        public string MethodicName { get; set; }
        public InputsSetting InputsSetting { get; set; }
        public ParametersSetting ParametersSetting { get; set; }
        public ClusterSetting ClustersSetting { get; set; }

       
        //constructor
        public ConfigDataXML_STO()
        {
            this.InputsSetting = new InputsSetting();
            this.ParametersSetting = new ParametersSetting();
            ClustersSetting = new ClusterSetting();
        }

    }

    public class InputsSetting
    {
        
        [XmlElement("TimeSteady")] 
        public string ProcessPeriodMs { get; set; }      //length staedy regim
        
        [XmlElement("TimeSteadyShift")]
        public string ProcessPeriodShiftMs { get; set; } //shift time between steady regim


        [XmlArray("Inputs")]
        [XmlArrayItem("Input")]
        public List<Inputs> Input { get; set; }

        //constructor
        public InputsSetting()
        {
            this.Input = new List<Inputs>();

           
           
        }
    }


    public class ParametersSetting
    {
        [XmlArray("Polynoms")]
        [XmlArrayItem("Polynom")]
        public List<PolynomData> Polynom { get; set; }

        [XmlArray("Nominals")]
        [XmlArrayItem("Nominal")]
        public List<ID_Value_Pair> Nominal = new List<ID_Value_Pair>();



        [XmlArray("CoefficientDiafr")]
        [XmlArrayItem("Coeff")]
        public List<ID_Value_Pair> Coeff { get; set; }


        //constructor1
        public ParametersSetting()
        {
                                  
            ///polynom
            this.Polynom = new List<PolynomData>();

            //nominal
            this.Nominal = new List<ID_Value_Pair>();

            //const
            this.Coeff = new List<ID_Value_Pair>();

        }
    }

    

    public class Inputs
    {
        [XmlAttribute("ID")]
        public string NameVariable { get; set; }

        [XmlElement("Attribute")]
        public string Attribute { get; set; }

        [XmlElement("Min")]
        public string Min { get; set; }

        [XmlElement("Max")]
        public string Max { get; set; }

        [XmlElement("ModeDetectorMin")]
        public string ModeDetectorMin { get; set; }

        [XmlElement("ModeDetectorDelta")]
        public string ModeDetectorDelta { get; set; }

        [XmlElement("DefaultValue")]
        public string DefaultValue { get; set; }

        [XmlElement("DefaultValueAttribute")]
        public string DefaultValueAttribute { get; set; }

        //constructor
        public Inputs()
        {
        }
    }
    public class CPE_ClusterProcessorCfg_Node : CProcessorNodeCfg
    {

        [XmlElement("InputVariables")]
        public string InputVariables {get;set;}
        [XmlElement("OutputVariables")]
        public string OutputVariables {get;set;}
        [XmlElement("InputPredictValue")]
        public string InputPredictValue { get; set; }
        [XmlElement("OutputPredictName")]
        public string OutputPredictName { get; set; }

        [XmlElement("NodeDecimation")]
        public string NodeDecimation { get; set; }
        public CPE_ClusterProcessorCfg_Node():base()
        {
        }
    }

    public class ClusterSetting
    {
        [XmlArray("Nodes")]
        [XmlArrayItem("Node")]
        public List<CPE_ClusterProcessorCfg_Node> Nodes = new List<CPE_ClusterProcessorCfg_Node>();

    }
    

}
