﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_CommonBlocks;
using CPE_CommonBlocks.ConfigMethodicCommon;

namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    public class CPE_ConfigDataProcess_STO:CPE_ConfigDataProcess
    {
         public CPE_CfgData_Process_ISP Isp;
         public CPE_CfgData_Process_Mod ModeDetector;
         public CPE_cgf_Process1_Pre_STO Pre;
         public CPE_cgf_CPE_Process3_Nominal Nom;
         public CPE_cgf_CPE_Process4_cluster_simulate Cluster;
         public CPE_cgf_CPE_Process5_post Post;
         public CPE_ClusterProcessor_cfg ClusterReal;
         public CPE_cfg_Output Output;



         public CPE_ConfigDataProcess_STO()
        {
            Isp = new CPE_CfgData_Process_ISP();
            ModeDetector = new CPE_CfgData_Process_Mod();
            Pre = new CPE_cgf_Process1_Pre_STO();
            Nom = new CPE_cgf_CPE_Process3_Nominal();
            Cluster = new CPE_cgf_CPE_Process4_cluster_simulate();
            Post = new CPE_cgf_CPE_Process5_post();
            ClusterReal = new CPE_ClusterProcessor_cfg();
            Output = new CPE_cfg_Output();
        }
    }
}
