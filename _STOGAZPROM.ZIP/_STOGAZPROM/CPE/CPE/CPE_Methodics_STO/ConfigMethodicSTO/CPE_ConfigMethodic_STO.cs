﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_CommonBlocks.ConfigMethodicCommon;
using CPE_Methodics_STO.ConfigMethodicSTO;
using System.IO;
using System.Xml.Serialization;
using CPE_Lib;
using CPE_CommonBlocks;
using ClusterProcessorClassLibrary;

namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    public class CPE_ConfigMethodic_STO : CPE_ConfigDataMethodic
    {
        public new ConfigDataXML_STO DataXML { get; set; }
        public new CPE_ConfigDataProcess_STO DataProcess { get; set; }

        public CPE_ConfigMethodic_STO()
        {
            this.DataXML = new ConfigDataXML_STO();
            this.DataProcess = new CPE_ConfigDataProcess_STO();
        }

        //convert string to list name
        public List<CPE_NV> ConvertStringListNameVariables(string str)
        {
            List<CPE_NV> res = new List<CPE_NV>();
            string[] lines = str.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                res.Add(ConvertStringNameVariable(lines[i]));
            }
            return res;
        }

        public T ConvertStringEnum<T>(string str) where T : struct, IConvertible
        {
            T temp = default(T);
            T res;
            try
            {
                res = (T)Enum.Parse(temp.GetType(), str);
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("использовани недопустимый символ для имени переменной при заполнении файла конфигурации:\"{0}\"", str));
            }

            return res;
        }



        //convert string to double
        public CPE_NV ConvertStringNameVariable(string str)
        {
            CPE_NV res;

            try
            {
                res = (CPE_NV)Enum.Parse(typeof(CPE_NV), str);
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("использовани недопустимый символ для имени переменной при заполнении файла конфигурации:\"{0}\"", str));
            }
            return res;
        }

        //convert string to NamePolynom
        public CPE_NamePolynom ConvertStringNamePolynom(string str)
        {
            CPE_NamePolynom res;

            try
            {
                res = (CPE_NamePolynom)Enum.Parse(typeof(CPE_NamePolynom), str);
            }
            catch (ArgumentException)
            {
                throw new Exception(String.Format("использовани недопустимый символ при заполнении файла конфигурации:\"{0}\"", str));
            }
            return res;
        }


        //method to read data from xml to cfgdata
        public override void GetData(string data)
        {
            this.DataXML = this.ReadXml(data, this.DataXML);


            //Fill data isp
            for (int i = 0; i < DataXML.InputsSetting.Input.Count; i++)
            {
                //  int temp_int;
                double temp_double;
                bool temp_bool;

                //attribute
                this.DataProcess.Isp.Attribute.Add((CPE_cfg_Attr)this.ConvertStringInt(this.DataXML.InputsSetting.Input[i].Attribute));

                //min
                this.ConvertStringDoubleBool(this.DataXML.InputsSetting.Input[i].Min, out temp_double, out temp_bool);
                this.DataProcess.Isp.Min.Add(temp_double);
                this.DataProcess.Isp.AttrMin.Add(temp_bool);

                //max
                this.ConvertStringDoubleBool(this.DataXML.InputsSetting.Input[i].Max, out temp_double, out temp_bool);
                this.DataProcess.Isp.Max.Add(temp_double);
                this.DataProcess.Isp.AttrMax.Add(temp_bool);

                //default value
                this.DataProcess.Isp.DefaultValue.Add(this.ConvertStringDouble(this.DataXML.InputsSetting.Input[i].DefaultValue, "config ISP"));

                //default Attribute
                this.DataProcess.Isp.AttributeDefault.Add((CPE_cfg_defValue)this.ConvertStringDouble(this.DataXML.InputsSetting.Input[i].DefaultValueAttribute, "config ISP"));


                DataProcess.Isp.NameVariable.Add((int)ConvertStringEnum<CPE_NV>(DataXML.InputsSetting.Input[i].NameVariable), i);
            }
            //name


            //isp
            DataProcess.Isp.Position = (int)CPE_NameSliceColumn.ISP;
            //  DataProcess.Isp.NameVariableProcess = DataProcess.Isp.NameVariableInputData;


            ////fill pre
            DataProcess.Pre.NameVariable = DataProcess.Isp.NameVariable;
            for (int i = 0; i < DataXML.InputsSetting.Input.Count; i++)
            {
                DataProcess.Pre.AttributeInput.Add((CPE_cfg_Attr)ConvertStringInt(DataXML.InputsSetting.Input[i].Attribute));
            }
            for (int i = 0; i < DataXML.ParametersSetting.Coeff.Count; i++)
            {
                DataProcess.Pre.CoeffDiafr.Add(
                    ConvertStringNameVariable(DataXML.ParametersSetting.Coeff[i].Name), ConvertStringDouble(DataXML.ParametersSetting.Coeff[i].Value, "config Pre"));
            }

            for (int i = 0; i < DataXML.ParametersSetting.Nominal.Count; i++)
            {
                DataProcess.Pre.Nominal.Add(
                    ConvertStringNameVariable(DataXML.ParametersSetting.Nominal[i].Name), ConvertStringDouble(DataXML.ParametersSetting.Nominal[i].Value, "config Pre"));
            }
            DataProcess.Pre.Pos = (int)CPE_NameSliceColumn.ISP;




            //**************Fill  mode**
            DataProcess.ModeDetector.ProcessPeriod_ms = (int)ConvertStringInt(DataXML.InputsSetting.ProcessPeriodMs) * 1000;
            DataProcess.ModeDetector.UpdatePeriod_ms = (int)ConvertStringInt(DataXML.InputsSetting.ProcessPeriodShiftMs) * 1000;
            for (int i = 0; i < DataXML.InputsSetting.Input.Count; i++)
            {
                double temp_double;
                bool temp_bool;
                //min
                ConvertStringDoubleBool(DataXML.InputsSetting.Input[i].ModeDetectorMin, out temp_double, out temp_bool);
                DataProcess.ModeDetector.MinValues.Add(temp_double);
                DataProcess.ModeDetector.MinValuesAttr.Add(temp_bool);
                //delta
                ConvertStringDoubleBool(DataXML.InputsSetting.Input[i].ModeDetectorDelta, out temp_double, out temp_bool);
                DataProcess.ModeDetector.Delta.Add(temp_double);
                DataProcess.ModeDetector.DeltaAttr.Add(temp_bool);
            }

            DataProcess.ModeDetector.PosInp = (int)CPE_NameSliceColumn.ISP;
            DataProcess.ModeDetector.PosOutDelta = (int)CPE_NameSliceColumn.ModeDetectDelta;
            DataProcess.ModeDetector.PosOutMean = (int)CPE_NameSliceColumn.ModeDetectMean;
            DataProcess.ModeDetector.NameVariableProcess = DataProcess.Isp.NameVariable;

            //**********************************



            //***fill Nominal
            //nominal
            for (int i = 0; i < DataXML.ParametersSetting.Nominal.Count; i++)
            {

                DataProcess.Nom.NominalDict.Add((int)ConvertStringEnum<CPE_NV>(DataXML.ParametersSetting.Nominal[i].Name),
                    ConvertStringDouble(DataXML.ParametersSetting.Nominal[i].Value, "config Nominal"));
            }
            //polynom
            for (int i = 0; i < DataXML.ParametersSetting.Polynom.Count; i++)
            {
                DataProcess.Nom.PolynomDict.Add(
                    ConvertStringNamePolynom(DataXML.ParametersSetting.Polynom[i].NameVariable),
                    ConvertPolynom(DataXML.ParametersSetting.Polynom[i]));
            }

            //position           
            DataProcess.Nom.Pos = CPE_NameSliceColumn.ModeDetectMean;



            //*********************fill simulation cluster (old methodics)
            //polynom
            for (int i = 0; i < DataXML.ParametersSetting.Polynom.Count; i++)
            {
                DataProcess.Cluster.PolynomDict.Add(
                    ConvertStringNamePolynom(DataXML.ParametersSetting.Polynom[i].NameVariable),
                    ConvertPolynom(DataXML.ParametersSetting.Polynom[i]));
            }

            //Output position
            DataProcess.Cluster.Pos = (int)CPE_NameSliceColumn.ModeDetectMean;


            //***fill postprocessor (old and new)
            //position
            DataProcess.Post.Pos = (int)CPE_NameSliceColumn.ModeDetectMean;





            //***fill real cluster           
            for (int i = 0; i < DataXML.ClustersSetting.Nodes.Count; i++)
            {
                DataProcess.ClusterReal.Node.Add((CProcessorNodeCfg)DataXML.ClustersSetting.Nodes[i]);
                // DataProcess.ClusterReal.InputName.Add(ConvertStringListNameVariables(DataXML.ClustersSetting.Nodes[i].InputVariables));
                // DataProcess.ClusterReal.OutputName.Add(ConvertStringListNameVariables(DataXML.ClustersSetting.Nodes[i].OutputVariables));
                //  DataProcess.ClusterReal.OutputPredictName.Add(ConvertStringListNameVariables(DataXML.ClustersSetting.Nodes[i].OutputPredictName));
                //  DataProcess.ClusterReal.InputPredictValue.Add(ConvertStringListDouble(DataXML.ClustersSetting.Nodes[i].InputPredictValue, "config Real Cluster"));
                DataProcess.ClusterReal.NodeDecimation.Add(ConvertStringInt(DataXML.ClustersSetting.Nodes[i].NodeDecimation));
            }
            DataProcess.ClusterReal.NameMethodic = DataXML.MethodicName;
            DataProcess.ClusterReal.InputName = new List<List<int[]>>()
                                                            { new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean, (int)CPE_NV.V1pr_cbn}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean, (int)CPE_NV.T04pr}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean, (int)CPE_NV.n2pr}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean, (int)CPE_NV.Npr}}};
            DataProcess.ClusterReal.OutputName = new List<List<int[]>>()
                                                            {new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.ef_cbn}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.Npr}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.Npr}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.Gpr_t}}};
            DataProcess.ClusterReal.InputPredictValue = new List<List<double>>()
                            {{new List<double>(){DataProcess.Nom.NominalDict[(int)CPE_NV.nom_V_cbn]}},
                             {new List<double>(){DataProcess.Nom.NominalDict[(int)CPE_NV.nom_T04]}},
                             {new List<double>(){DataProcess.Nom.NominalDict[(int)CPE_NV.nom_n2]}},
                             {new List<double>(){DataProcess.Nom.NominalDict[(int)CPE_NV.nom_N]}}};
            DataProcess.ClusterReal.OutputPredictName = new List<List<int[]>>()
                                                            {new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.clus_ef_cbn_V1}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.cluss_Npr_T04}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.clus_N_n2}},
                                                            new List<int[]>() {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.clus_G_t_N}}};



            //output
            DataProcess.Output.ListVariable = new List<int[]>()
                          {new int[] {(int)CPE_NameSliceColumn.ModeDetectMean,(int)CPE_NV.KTS_cbn}};



            return;
        }
    }
}
