﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;

using CPE_Lib;


using CPE_CommonBlocks;
using CPE_CommonBlocks.ConfigMethodicCommon;


namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    public class CPE_ConfigDataProcess_STO
    {
        //public Dictionary<CPE_NameSliceColumn, Dictionary<CPE_NameVar, int>> LinkNameVar;
        public CfgData_CPE_Process_ISP isp { get; set; }
     //   public CfgData_CPE_Process_Mod mod { get; set; }


        public CPE_ConfigDataProcess_STO()
        {
       //     this.LinkNameVar.Add(CPE_NameSliceColumn.ISP, this.isp.variable_name);
            this.isp = new CfgData_CPE_Process_ISP();
            //this.mod = new CfgData_CPE_Process_Mod();
        }

      
                //method to read data from xml to cfgdata
        public CPE_ConfigDataProcess_STO GetData(string data)
        {
        bool result = false;



        //deserialize
        XmlSerializer serialize = new XmlSerializer(typeof(ConfigDataXML_STO));
        TextReader reader = new StringReader(data);
        ConfigDataXML_STO confdataxml = (ConfigDataXML_STO)serialize.Deserialize(reader);


        //block verification XML
        int num_input = 19;

        //check validity attribute
            List<List<int>> attr = new List<List<int>>();
            List<int> temp = new List<int>() {0,1};
            for (int i = 0; i < num_input; i++) attr.Add(temp);
            attr[11].Add(2);
            attr[15].Add(2);

            for (int i = 0; i < num_input; i++)
            {
                int flag = 1;
                int attval = Convert.ToInt32(CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].Attribute));
                for (int j = 0; j < attr[i].Count; j++)
                {
                    if (attr[i][j] == attval)
                    {
                        flag = 0;
                    }
                }
                if (1 == flag)
                {
                    throw new Exception(String.Format("использовани недопустимый attribut: \"{0}\" для входа:\"{1}\"", attval, i));
                }
            }

            //check DefaultValueAttribute
            for (int i = 0; i < num_input; i++)
            {
                int attval = Convert.ToInt32(CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].DefaultValueAttribute));
                if ((0 != attval) && (1 != attval) && (2 != attval))
                {
                    throw new Exception(String.Format("использовани недопустимый DefaultValueAttribute: \"{0}\" для входа:\"{1}\"", attval, i));
                }
            }

            //check Number Polynom
            for (int i = 0; i < confdataxml.ParametersSetting.Polynom.Count; i++)
            {
                int num_pol = Convert.ToInt32(CfgMethodicsMethod.ConvertData(confdataxml.ParametersSetting.Polynom[i].Num));
                if ((1 != num_pol) && (2 != num_pol))
                {
                    throw new Exception(String.Format("использовани недопустимое количество полиномов: \"{0}\" для полинома:\"{1}\"", num_pol, i));
                }
            }

            //check that all input data filled
            for (int i = 0; i < num_input; i++)
            {
                if ((confdataxml.InputsSetting.Input[i].Max == null) ||
                    (confdataxml.InputsSetting.Input[i].Min == null) ||
                    (confdataxml.InputsSetting.Input[i].ModeDetectorDelta == null) ||
                    (confdataxml.InputsSetting.Input[i].ModeDetectorMin == null) ||
                    (confdataxml.InputsSetting.Input[i].DefaultValue == null) ||
                    (confdataxml.InputsSetting.Input[i].DefaultValueAttribute == null) ||
                    (confdataxml.InputsSetting.Input[i].Attribute == null))
                {
                    throw new Exception(String.Format("не заполнены все поля исходных данных \"Input Setting\"в xml. Пожалуйста исправьте."));
                }
            }

            //Fill data isp

            //make empty fields
           

            for (int i = 0; i < num_input; i++)
            {
               
                CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].Attribute, this.isp.Attribute);
                CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].Min, this.isp.Min, this.isp.AttrMin);
                CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].Max, this.isp.Max, this.isp.AttrMax);
                CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].DefaultValue, this.isp.DefaultValue);
                CfgMethodicsMethod.ConvertData(confdataxml.InputsSetting.Input[i].DefaultValueAttribute, this.isp.AttributeDefault);
            }

          

            return this;
        }

        //public void SetNameVariable()
        //{
            

        //    this.isp.variable_name = name;


        //}

    }

}
