﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_CommonBlocks.ConfigMethodicCommon;

namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    public class CPE_ConfigDataName_STO
    {
       

//        CPE_ConfigDataName_STO():base()
//        {
//          //made array with all names
//            Dictionary<CPE_NameVar, int> dict_local = new Dictionary<CPE_NameVar, int>();
//            dict_local.Add(CPE_NameVar.B, 0);
//            dict_local.Add(CPE_NameVar.n1, 1);
//            dict_local.Add(CPE_NameVar.n2, 2);
//            dict_local.Add(CPE_NameVar.n3, 3);
//            dict_local.Add(CPE_NameVar.T1_cbn, 4);
//            dict_local.Add(CPE_NameVar.T2_cbn, 5);
//            dict_local.Add(CPE_NameVar.Pi01_cbn, 6);
//            dict_local.Add(CPE_NameVar.Pi02_cbn, 7);
//            dict_local.Add(CPE_NameVar.Pd_cbn_conf, 8);
//            dict_local.Add(CPE_NameVar.T01, 9);
//            dict_local.Add(CPE_NameVar.T04, 10);
//            dict_local.Add(CPE_NameVar.G_cbn_sau_temp, 11);
//            dict_local.Add(CPE_NameVar.t_t_diafr, 12);
//            dict_local.Add(CPE_NameVar.Pi_t_diafr, 13);
//            dict_local.Add(CPE_NameVar.Pd_t_diafr, 14);
//            dict_local.Add(CPE_NameVar.G_t_sau_temp, 15);
//            dict_local.Add(CPE_NameVar.P02, 16);
//            dict_local.Add(CPE_NameVar.ro_t, 17);
//            dict_local.Add(CPE_NameVar.Q_t, 18);
//            dict_local.Add(CPE_NameVar.P01_cbn, 19);
//            dict_local.Add(CPE_NameVar.P02_cbn, 20);
//            dict_local.Add(CPE_NameVar.P_t_diafr, 21);
//            dict_local.Add(CPE_NameVar.G_cbn_sau, 22);
//            dict_local.Add(CPE_NameVar.G_t_sau, 23);
//            dict_local.Add(CPE_NameVar.G_cbn_diafr, 24);
//            dict_local.Add(CPE_NameVar.G_t_diafr, 25);
//            dict_local.Add(CPE_NameVar.G_cbn, 26);
//            dict_local.Add(CPE_NameVar.G_t_gtd, 27);
//            dict_local.Add(CPE_NameVar.ef_cbn, 28);
//            dict_local.Add(CPE_NameVar.N, 29);
//            dict_local.Add(CPE_NameVar.ef, 30);
//            dict_local.Add(CPE_NameVar.ef_gpa, 31);
//            dict_local.Add(CPE_NameVar.V1_cbn, 32);
//            dict_local.Add(CPE_NameVar.V1pr_cbn, 33);
//            dict_local.Add(CPE_NameVar.n1pr, 34);
//            dict_local.Add(CPE_NameVar.n2pr, 35);
//            dict_local.Add(CPE_NameVar.n3pr, 36);
//            dict_local.Add(CPE_NameVar.P02pr, 37);
//            dict_local.Add(CPE_NameVar.Npr, 38);
//            dict_local.Add(CPE_NameVar.T04pr, 39);
//            dict_local.Add(CPE_NameVar.Gpr_t, 40);
//            dict_local.Add(CPE_NameVar.ef_cbn_V1pr, 41);
//            dict_local.Add(CPE_NameVar.Npr_nom_t, 43);
//            dict_local.Add(CPE_NameVar.Npr_nom_n, 44);
//            dict_local.Add(CPE_NameVar.Gpr_t_N_nom, 45);
//            dict_local.Add(CPE_NameVar.N_nom, 46);
//            dict_local.Add(CPE_NameVar.T04_nom, 47);
//            dict_local.Add(CPE_NameVar.n2_nom, 48);
//            dict_local.Add(CPE_NameVar.n3_nom, 49);
//            dict_local.Add(CPE_NameVar.G_t_nom, 50);
//            dict_local.Add(CPE_NameVar.ef_nom_cbn, 51);
//            dict_local.Add(CPE_NameVar.Vpr_nom_cbn, 52);
//            dict_local.Add(CPE_NameVar.ef_cbn_Vpr_form, 53);
//            dict_local.Add(CPE_NameVar.Coef_regim, 54);
//            dict_local.Add(CPE_NameVar.KTS_cbn, 55);
//            dict_local.Add(CPE_NameVar.KTS_N_t04, 56);
//            dict_local.Add(CPE_NameVar.KTS_N_n2, 57);
//            dict_local.Add(CPE_NameVar.KTS_N, 58);
//            dict_local.Add(CPE_NameVar.KTS_t, 59);
//            dict_local.Add(CPE_NameVar.number_regim, 42);

//            //add place ISP
//            Dictionary<CPE_NameVar, int> name_isp = new Dictionary<CPE_NameVar, int>();
//            foreach (KeyValuePair <CPE_NameVar, int> kv in dict_local)
//            {
//                if (kv.Value < 41)
//                {
//                    name_isp.Add((CPE_NameVar)kv.Key,(int) kv.Value);
//                }
//            }
//            this.cfgPrepare.NameVariable.Add(CPE_NameSliceColumn.ISP, name_isp);


//            //add ModeDelta, ModeBreakDelta,ModeBreakMin
            
//            Dictionary<CPE_NameVar, int> name_mode_delta = new Dictionary<CPE_NameVar, int>();
//            Dictionary<CPE_NameVar, int> name_mode_break_delta = new Dictionary<CPE_NameVar, int>();
//            Dictionary<CPE_NameVar, int> name_mode_break_min = new Dictionary<CPE_NameVar, int>();

//            foreach (KeyValuePair<CPE_NameVar, int> kv in dict_local)
//            {
//                if (kv.Value < 42)
//                {
                    
//                    name_mode_delta.Add((CPE_NameVar)kv.Key, (int)kv.Value);
//                    name_mode_break_delta.Add((CPE_NameVar)kv.Key, (int)kv.Value);
//                    name_mode_break_min.Add((CPE_NameVar)kv.Key, (int)kv.Value);
//                }
//            }

//            this.cfgPrepare.NameVariable.Add(CPE_NameSliceColumn.ModeDetectDelta, name_mode_delta);
//            this.cfgPrepare.NameVariable.Add(CPE_NameSliceColumn.ModeDetectBreakDelta, name_mode_break_delta);
//            this.cfgPrepare.NameVariable.Add(CPE_NameSliceColumn.ModeDetectBreakMin, name_mode_break_min);

//            //add mode mean 
//            Dictionary<CPE_NameVar, int> name_mode = new Dictionary<CPE_NameVar, int>();
//            foreach (KeyValuePair<CPE_NameVar, int> kv in dict_local)
//            {

//                    name_mode.Add((CPE_NameVar)kv.Key, (int)kv.Value);


//            }
//            this.cfgPrepare.NameVariable.Add(CPE_NameSliceColumn.ModeDetectMean, name_mode);
        

//        }

//    }
//}
    }
}