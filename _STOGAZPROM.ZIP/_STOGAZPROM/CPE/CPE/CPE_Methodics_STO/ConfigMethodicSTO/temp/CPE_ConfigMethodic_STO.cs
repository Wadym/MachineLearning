﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_CommonBlocks.ConfigMethodicCommon;

namespace CPE_Methodics_STO.ConfigMethodicSTO
{
    class CPE_ConfigDataMethodic_STO : CPE_ConfigDataMethodic
    {
                public CPE_ConfigDataName DataName { get; set; }
        public CPE_ConfigDataXML DataXml { get; set; }
        public CPE_ConfigData DataProcess { get; set; }

        public void CPE_ConfigDataMethodic()
        {
            this.DataXml = new CPE_ConfigDataXML();
            this.DataProcess = new CPE_ConfigData();
            this.DataName = new CPE_ConfigDataName();
        }


    }
}
