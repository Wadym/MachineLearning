﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_CommonBlocks;


namespace CPE_Methodics_STO
{
    public class CPE_cgf_CPE_Process4_cluster_simulate
    {
        public int Pos { get; set; }   //Input Data for cluster
        public Dictionary<CPE_NV, double> NominalDict;
        public Dictionary<CPE_NamePolynom, Polynoms> PolynomDict;

        public CPE_cgf_CPE_Process4_cluster_simulate()
        {
            NominalDict = new Dictionary<CPE_NV, double>();
            PolynomDict = new Dictionary<CPE_NamePolynom, Polynoms>();
        }

    }


    public class CPE_Process4_cluster_simulate : SliceProcessing
    {
        public CPE_cgf_CPE_Process4_cluster_simulate cfg = new CPE_cgf_CPE_Process4_cluster_simulate();

        //config
        public void Config(CPE_cgf_CPE_Process4_cluster_simulate confdata)
        {
            Func.Utill_CheckDictionaryKey("CPE_Cluster_simulate",
                new CPE_NamePolynom[] { CPE_NamePolynom.ef_cbn_V1, CPE_NamePolynom.N_T04, 
                             CPE_NamePolynom.N_n2,CPE_NamePolynom.G_t_N},
                 confdata.PolynomDict);
            cfg = confdata;
        }




        public override bool Process(Slice input)
        {
            bool result = false;

            Dictionary<int, double> data = input.Data[cfg.Pos];
            Dictionary<int, CPE_ValidityDataTypes> status = input.DataStatus[cfg.Pos];

            //transfer tp Process3_Nominal
            data[(int)CPE_NV.form_ef_cbn_V1] = cfg.PolynomDict[CPE_NamePolynom.ef_cbn_V1].Value(data[(int)CPE_NV.V1pr_cbn]);
            status[(int)CPE_NV.form_ef_cbn_V1] = cfg.PolynomDict[CPE_NamePolynom.ef_cbn_V1].Status(data[(int)CPE_NV.V1pr_cbn]);
            status[(int)CPE_NV.form_ef_cbn_V1] = Func.Utill_Status(status, new int[] { (int)CPE_NV.V1pr_cbn, (int)CPE_NV.form_ef_cbn_V1 });
            //****
            data[(int)CPE_NV.form_N_T04] = cfg.PolynomDict[CPE_NamePolynom.N_T04].Value(data[(int)CPE_NV.T04pr]);
            status[(int)CPE_NV.form_N_T04] = cfg.PolynomDict[CPE_NamePolynom.N_T04].Status(data[(int)CPE_NV.T04pr]);
            status[(int)CPE_NV.form_N_T04] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T04pr, (int)CPE_NV.form_N_T04 });

            data[(int)CPE_NV.form_N_n2] = cfg.PolynomDict[CPE_NamePolynom.N_n2].Value(data[(int)CPE_NV.n2pr]);
            status[(int)CPE_NV.form_N_n2] = cfg.PolynomDict[CPE_NamePolynom.N_n2].Status(data[(int)CPE_NV.n2pr]);
            status[(int)CPE_NV.form_N_n2] = Func.Utill_Status(status, new int[] { (int)CPE_NV.n2pr, (int)CPE_NV.form_N_n2 });

            data[(int)CPE_NV.form_G_t_N] = cfg.PolynomDict[CPE_NamePolynom.G_t_N].Value(data[(int)CPE_NV.Npr]);
            status[(int)CPE_NV.form_G_t_N] = cfg.PolynomDict[CPE_NamePolynom.G_t_N].Status(data[(int)CPE_NV.Npr]);
            status[(int)CPE_NV.form_G_t_N] = Func.Utill_Status(status, new int[] { (int)CPE_NV.Npr, (int)CPE_NV.form_G_t_N });

            //Политропный КПД, пересчитанный к номиналу //0-kpd_pol_curve; 1-kpd_pol_current ,
            data[(int)CPE_NV.clus_ef_cbn_V1] = data[(int)CPE_NV.nom_ef_cbn] - (data[(int)CPE_NV.form_ef_cbn_V1] - data[(int)CPE_NV.ef_cbn]);
            status[(int)CPE_NV.clus_ef_cbn_V1] = Func.Utill_Status(status, new int[] { (int)CPE_NV.nom_ef_cbn, (int)CPE_NV.form_ef_cbn_V1, (int)CPE_NV.ef_cbn });

            data[(int)CPE_NV.cluss_Npr_T04] = data[(int)CPE_NV.nom_N] - (data[(int)CPE_NV.form_N_T04] - data[(int)CPE_NV.Npr]);
            status[(int)CPE_NV.cluss_Npr_T04] = Func.Utill_Status(status, new int[] { (int)CPE_NV.nom_N, (int)CPE_NV.form_N_T04, (int)CPE_NV.Npr });
            //            //Приведенная мощность, пересчитанная к номинальным оборотам (по n_KVD)
            data[(int)CPE_NV.clus_N_n2] = data[(int)CPE_NV.nom_N] - (data[(int)CPE_NV.form_N_n2] - data[(int)CPE_NV.Npr]);
            status[(int)CPE_NV.clus_N_n2] = Func.Utill_Status(status, new int[] { (int)CPE_NV.nom_N, (int)CPE_NV.form_N_n2, (int)CPE_NV.Npr });

            data[(int)CPE_NV.clus_G_t_N] = data[(int)CPE_NV.nom_G_t] - (data[(int)CPE_NV.form_G_t_N] - data[(int)CPE_NV.Gpr_t]);
            status[(int)CPE_NV.clus_G_t_N] = Func.Utill_Status(status, new int[] { (int)CPE_NV.form_G_t_N, (int)CPE_NV.nom_G_t, (int)CPE_NV.Gpr_t });

            result = true;
            return result;
        }
    }
}



