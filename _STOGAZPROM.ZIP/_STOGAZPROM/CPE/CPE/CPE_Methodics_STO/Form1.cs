﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using CPE_Lib;
using CPE_Methodics_STO.ConfigMethodicSTO;
using System.Xml;
using System.Xml.Serialization;
using System.Threading;
using CPE_CommonBlocks;
using CPE_CommonBlocks.ConfigMethodicCommon;


namespace CPE_Methodics_STO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            CPE_Methodic_STO test = new CPE_Methodic_STO();

            //read string
            StreamReader reader = new StreamReader(File.OpenRead(@"..\..\..\..\Data\STO\STO_new.xml"));
            string stringXML = reader.ReadToEnd();

            Console.WriteLine("***");
            Console.WriteLine("read string - done");
            Console.WriteLine("***");

            //config
            test.Config(stringXML, new CPE_DataBlobAccess());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConfigDataXML_STO confdata = new ConfigDataXML_STO();
            // FileStream fs = new FileStream(, FileMode.OpenOrCreate);
            XmlSerializer ser = new XmlSerializer(typeof(ConfigDataXML_STO));

            // c:\Tehnekon\Branches\3.1.ParamDiag_22.10.2015\CPE\CPE\Data\DG90\
            TextWriter writer = new StreamWriter(@"..\..\..\..\Data\STO\STO_write.xml");
            //confdata.InputsSetting.IDD=CPE_NV.CoefDiafr;
          //  confdata.ParametersSetting.Coeff.Add( 50);
           // confdata.ParametersSetting.Polynom[0].a00 = "50";
            ID_Value_Pair sasa = new ID_Value_Pair();
            sasa.Name = "sd";
            sasa.Value = "df";
            confdata.ParametersSetting.Nominal.Add(sasa);
            confdata.ClustersSetting.Nodes.Add(new CPE_ClusterProcessorCfg_Node());
            confdata.ClustersSetting.Nodes[0].InputVariables = "assas";
            ser.Serialize(writer, confdata);

            writer.Close();
            Console.WriteLine("***");
            Console.WriteLine("write xml - done");
            Console.WriteLine("***");




        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }


        public void RunCalc()
        {
            CPE_Methodic_STO cpe = new CPE_Methodic_STO();

       
            //read string

            StreamReader reader = new StreamReader(File.OpenRead(@"..\Data\STO\input_STO_ORSHA.xml"));
            //StreamReader reader = new StreamReader(File.OpenRead(@"..\Data\STO\input_res.xml"));
            string stringXML = reader.ReadToEnd();

            Console.WriteLine("***");
            Console.WriteLine("read string - done");
            Console.WriteLine("***");

            //config
            cpe.Config(stringXML, new CPE_DataBlobAccess());
            Console.WriteLine("***");
            Console.WriteLine("Config - done");
            Console.WriteLine("***");


//ORSHA      n1,n2,n3,T01_cbn,T02_cbn,P01_cbn,P02_cbn,Pd_cbn_conf,T01,T04

            CPE_FileReared reader_data = new CPE_FileReared(@"..\Data\STO\res\ORSHA#1_20151223_20160527.csv", 26, 0,


                new List<int>() { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 },
                new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 16, 17, 18 },
                new List<double>() { 1, 1, 1, 1, 1, 1, 1, 0.001, 1, 1, 1, 1, 0.001, 1, 1, 1 },
                new List<double>() { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });

//res 
            //CPE_FileReared reader_data = new CPE_FileReared(@"..\Data\STO\res\input_random_point.csv", 2, 0,


            //    new List<int>() { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37 },
            //    new List<int>() { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 },
            //    new List<double>() { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            //    new List<double>() { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 });
        
            Dictionary<int,CPE_FileWriter> write_data = new Dictionary<int,CPE_FileWriter>();

            int num_inputs = 19;
            int num_outputs = 59;
            Slice TestSlice = new Slice(num_inputs, num_outputs);
            
            while (true)
            {
               
                //init
                cpe.Init(TestSlice);
                if (reader_data.ReadLine(TestSlice))
                {
                   
                    cpe.Execute(TestSlice);
     
                    foreach (int position in TestSlice.Data.Keys)
                    {
                        
                        if (TestSlice.Data[position].Count > 0)
                        {
                        if (false == write_data.ContainsKey(position))
                        {                            
                            write_data.Add(position,
                                new CPE_FileWriter(string.Format(@"..\Data\STO\res\out_{0}.csv", 
                                    position), position,true));
                        }

                        if (TestSlice.Data[position].Count > write_data[position].name_variable.Count)
                        {
                            write_data[position].headline = false;
                        }

                        if (false == write_data[position].headline)
                        {
                            write_data[position].WriteHeadLine<CPE_NV>(TestSlice);
                        }
                      
                        write_data[position].Write(TestSlice);
                          
                       // write_data[position].Write<CPE_NV>(TestSlice);
                        }

                    }
                }
                else
                {
                    foreach (int  position in write_data.Keys)
                    {
                       
                        write_data[position].Close();
                    }
                    break;
                }
            }
         
            Console.WriteLine();
            Console.WriteLine("FINISH!!!");
        }
        
        
        private void button3_Click(object sender, EventArgs e)
        {
            Thread tt = new Thread(new ThreadStart(RunCalc));
            tt.Start();
        }
    }
}
