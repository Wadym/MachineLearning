﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_CommonBlocks;


namespace CPE_Methodics_STO
{
    public class CPE_cgf_CPE_Process5_post
    {
        public int Pos { get; set; }   //Input Data for cluster
    }


    public class CPE_Process5_post : SliceProcessing
    {
        CPE_cgf_CPE_Process5_post cfg = new CPE_cgf_CPE_Process5_post();

        //config
        public void Config(CPE_cgf_CPE_Process5_post confdata)
        {
            cfg = confdata;
        }


        public override bool Process(Slice input)
        {
            bool result = false;
            Dictionary<int, double> data = input.Data[cfg.Pos];
            Dictionary<int, CPE_ValidityDataTypes> status = input.DataStatus[cfg.Pos];

            data[(int)CPE_NV.Coef_regim] = data[(int)CPE_NV.form_ef_cbn_V1] / data[(int)CPE_NV.nom_ef_cbn];
            status[(int)CPE_NV.Coef_regim] = Func.Utill_Status(status, new int[] { (int)CPE_NV.nom_ef_cbn, (int)CPE_NV.form_ef_cbn_V1 });

            data[(int)CPE_NV.KTS_cbn] = data[(int)CPE_NV.clus_ef_cbn_V1] / data[(int)CPE_NV.nom_ef_cbn];
            status[(int)CPE_NV.KTS_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.nom_ef_cbn, (int)CPE_NV.clus_ef_cbn_V1 });

            data[(int)CPE_NV.KTS_N_T04] = data[(int)CPE_NV.cluss_Npr_T04] / data[(int)CPE_NV.nom_N];
            status[(int)CPE_NV.KTS_N_T04] = Func.Utill_Status(status, new int[] { (int)CPE_NV.cluss_Npr_T04, (int)CPE_NV.nom_N });

            data[(int)CPE_NV.KTS_N_n2] = data[(int)CPE_NV.clus_N_n2] / data[(int)CPE_NV.nom_N];
            status[(int)CPE_NV.KTS_N_n2] = Func.Utill_Status(status, new int[] { (int)CPE_NV.clus_N_n2, (int)CPE_NV.nom_N });

            data[(int)CPE_NV.KTS_G_t] = data[(int)CPE_NV.clus_G_t_N] / data[(int)CPE_NV.nom_G_t];
            status[(int)CPE_NV.KTS_G_t] = Func.Utill_Status(status, new int[] { (int)CPE_NV.clus_G_t_N, (int)CPE_NV.nom_G_t });
            //attention there are additional logic base on if.
            if (((status[(int)CPE_NV.KTS_N_n2] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
            (status[(int)CPE_NV.KTS_N_n2] == CPE_ValidityDataTypes.ValidityDataTypeHandmade)) &&
            ((status[(int)CPE_NV.KTS_N_T04] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
            (status[(int)CPE_NV.KTS_N_T04] == CPE_ValidityDataTypes.ValidityDataTypeHandmade)))
            {
                data[(int)CPE_NV.KTS_N] = Math.Min(data[(int)CPE_NV.KTS_N_n2], data[(int)CPE_NV.KTS_N_T04]);
                status[(int)CPE_NV.KTS_N] = Func.Utill_Status(status, new int[] { (int)CPE_NV.KTS_N_n2, (int)CPE_NV.KTS_N_T04 });
            }
            else if ((status[(int)CPE_NV.KTS_N_n2] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
            (status[(int)CPE_NV.KTS_N_n2] == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
            {
                status[(int)CPE_NV.KTS_N] = status[(int)CPE_NV.KTS_N_n2];
                data[(int)CPE_NV.KTS_N] = data[(int)CPE_NV.KTS_N_n2];

            }
            else if ((status[(int)CPE_NV.KTS_N_T04] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
            (status[(int)CPE_NV.KTS_N_T04] == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
            {
                status[(int)CPE_NV.KTS_N] = status[(int)CPE_NV.KTS_N_T04];
                data[(int)CPE_NV.KTS_N] = data[(int)CPE_NV.KTS_N_T04];
            }


            result = true;
            return result;
        }
    }
}



