﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Methodics_STO
{
               public enum CPE_NameSliceColumn
    {
        ISP,
        ModeDetectMean,
        ModeDetectDelta,
        ModeDetectBreakMin,
        ModeDetectBreakDelta,
        Cluster,
        PostProcessor
    }
               class CPE_Enum_STO
               {
               }
 
}
