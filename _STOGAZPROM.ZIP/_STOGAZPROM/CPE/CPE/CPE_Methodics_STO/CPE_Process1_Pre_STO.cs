﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_CommonBlocks;



namespace CPE_Methodics_STO
{
    public class CPE_cgf_Process1_Pre_STO
    {
        public int Pos { get; set; }   //Position in Slice.Data to put
        // public Dictionary<CPE_NV, double> ConstDict { get; set; } //Acbn,Adiafr,n_CBN
        public Dictionary<CPE_NV, double> Nominal { get; set; } //nominal data
        public Dictionary<CPE_NV, double> CoeffDiafr { get; set; } //coeffisien confusor and diafr
        public List<CPE_cfg_Attr> AttributeInput { get; set; }
        public Dictionary<int, int> NameVariable { get; set; } //name  related InputData <name_var,#num_imput,>

        public CPE_cgf_Process1_Pre_STO()
        {

            Nominal = new Dictionary<CPE_NV, double>();
            CoeffDiafr = new Dictionary<CPE_NV, double>();
            AttributeInput = new List<CPE_cfg_Attr>();
            NameVariable = new  Dictionary<int,int>();
        }
    }

    public class CPE_Process1_Pre_STO : SliceProcessing
    {
        CPE_cgf_Process1_Pre_STO cfg = new CPE_cgf_Process1_Pre_STO();


        //config
        public void Config(CPE_cgf_Process1_Pre_STO confdata)
        {
            cfg = confdata;
            Func.Util_CheckSameNumberList("Pre", cfg.AttributeInput, cfg.NameVariable);
        }


        // PROCESS
        public override bool Process(Slice input)
        {
            bool result = false;

            //make local link
            Dictionary<int, double> data = input.Data[cfg.Pos];
            Dictionary<int, CPE_ValidityDataTypes> status = input.DataStatus[cfg.Pos];


            //corect Q
            //17-ro/Q-18

            if (cfg.AttributeInput[cfg.NameVariable[(int)CPE_NV.Q_t]] == CPE_cfg_Attr.UseOption)
            {
                data[(int)CPE_NV.Q_t] = data[(int)CPE_NV.Q_t] / data[(int)CPE_NV.ro_t];
                status[(int)CPE_NV.Q_t] = Func.Utill_Status(status, new int[] { (int)CPE_NV.Q_t, (int)CPE_NV.ro_t });
            }


            //            //absolute pressure

            status[(int)CPE_NV.P01_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.Pi01_cbn, (int)CPE_NV.B });
            data[(int)CPE_NV.P01_cbn] = data[(int)CPE_NV.B] + data[(int)CPE_NV.Pi01_cbn];
            

            data[(int)CPE_NV.P02_cbn] = data[(int)CPE_NV.B] + data[(int)CPE_NV.Pi02_cbn];
            status[(int)CPE_NV.P02_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.B, (int)CPE_NV.Pi02_cbn });

            data[(int)CPE_NV.P_t_diafr] = data[(int)CPE_NV.B] + data[(int)CPE_NV.Pi_t_diafr];
            status[(int)CPE_NV.P_t_diafr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.B, (int)CPE_NV.Pi_t_diafr });

            if (cfg.AttributeInput[cfg.NameVariable[(int)CPE_NV.G_cbn_sau]] == CPE_cfg_Attr.UseOption)
            {
                data[(int)CPE_NV.G_cbn_sau] = data[(int)CPE_NV.G_cbn_sau] * data[(int)CPE_NV.ro_t];
                status[(int)CPE_NV.G_cbn_sau] = Func.Utill_Status(status, new int[] { (int)CPE_NV.G_cbn_sau, (int)CPE_NV.ro_t });
            }

            if (cfg.AttributeInput[cfg.NameVariable[(int)CPE_NV.G_t_sau]] == CPE_cfg_Attr.UseOption)
            {

                data[(int)CPE_NV.G_t_sau] = data[(int)CPE_NV.G_t_sau] * data[(int)CPE_NV.ro_t];
                status[(int)CPE_NV.G_t_sau] = Func.Utill_Status(status, new int[] { (int)CPE_NV.ro_t, (int)CPE_NV.G_t_sau });
            }

            double Z = Func.GasCompressibility(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.P01_cbn], data[(int)CPE_NV.ro_t]);
            double density = Func.GasDensity(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.P01_cbn], 101325 / 293.15 / data[(int)CPE_NV.ro_t], Z);
            data[(int)CPE_NV.G_cbn_diafr] = Func.FlowMasDiafr(cfg.CoeffDiafr[CPE_NV.CoefConf] / 60, data[(int)CPE_NV.Pd_cbn_conf], density);
            status[(int)CPE_NV.G_cbn_diafr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01_cbn, (int)CPE_NV.P01_cbn, (int)CPE_NV.ro_t, (int)CPE_NV.Pd_cbn_conf });


            ///here
            Z = Func.GasCompressibility(data[(int)CPE_NV.t_t_diafr], data[(int)CPE_NV.P_t_diafr], data[(int)CPE_NV.ro_t]);
            density = Func.GasDensity(data[(int)CPE_NV.t_t_diafr], data[(int)CPE_NV.P_t_diafr], 101325 / 293.15 / data[(int)CPE_NV.ro_t], Z);
            data[(int)CPE_NV.G_t_diafr] = Func.FlowMasDiafr(cfg.CoeffDiafr[CPE_NV.CoefDiafr] / 60, data[(int)CPE_NV.Pd_t_diafr], density);
            status[(int)CPE_NV.G_t_diafr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.t_t_diafr, (int)CPE_NV.P_t_diafr, (int)CPE_NV.ro_t, (int)CPE_NV.Pd_t_diafr });

            //Принятый расход газа ЦБН(выбор из САУ или диафр)
            if ((status[(int)CPE_NV.G_cbn_diafr] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
                (status[(int)CPE_NV.G_cbn_diafr] == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
            {
                data[(int)CPE_NV.G_cbn] = data[(int)CPE_NV.G_cbn_diafr];
                status[(int)CPE_NV.G_cbn] = status[(int)CPE_NV.G_cbn_diafr];
            }
            else
            {
                data[(int)CPE_NV.G_cbn] = data[(int)CPE_NV.G_cbn_sau];
                status[(int)CPE_NV.G_cbn] = status[(int)CPE_NV.G_cbn_sau];
            }

            //Принятый расход газа ГТД(выбор из САУ или диафр)
            if ((status[(int)CPE_NV.G_t_diafr] == CPE_ValidityDataTypes.ValidityDataTypeGood) ||
           (status[(int)CPE_NV.G_t_diafr] == CPE_ValidityDataTypes.ValidityDataTypeHandmade))
            {
                data[(int)CPE_NV.G_t_gtd] = data[(int)CPE_NV.G_t_diafr];
                status[(int)CPE_NV.G_t_gtd] = status[(int)CPE_NV.G_t_diafr];
            }
            else
            {
                data[(int)CPE_NV.G_t_gtd] = data[(int)CPE_NV.G_t_sau];
                status[(int)CPE_NV.G_t_gtd] = status[(int)CPE_NV.G_t_sau];
            }

            data[(int)CPE_NV.ef_cbn] = Func.EfficiencyPolytropCBN(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.T02_cbn], data[(int)CPE_NV.P01_cbn], data[(int)CPE_NV.P02_cbn], data[(int)CPE_NV.ro_t]);
            status[(int)CPE_NV.ef_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01_cbn, (int)CPE_NV.T02_cbn, (int)CPE_NV.P01_cbn, (int)CPE_NV.P02_cbn, (int)CPE_NV.ro_t });

            double Nmeh = Math.Pow(data[(int)CPE_NV.n3] / cfg.Nominal[CPE_NV.nom_n3], 1.5) * 100 / 1000;
            double m_t = Math.Log10((data[(int)CPE_NV.T02_cbn] + 273.15) / (data[(int)CPE_NV.T01_cbn] + 273.15)) / Math.Log10(data[(int)CPE_NV.P02_cbn] / data[(int)CPE_NV.P01_cbn]);
            double k_k_1 = 4.16 + 0.0041 * ((data[(int)CPE_NV.T01_cbn] + data[(int)CPE_NV.T02_cbn]) / 2 - 10) + 3.93 * (data[(int)CPE_NV.ro_t] / 1.2044 - 0.55) + 5 * (m_t - 0.3);
            double z1 = Func.GasCompressibility(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.P01_cbn], data[(int)CPE_NV.ro_t]);
            double z2 = Func.GasCompressibility(data[(int)CPE_NV.T02_cbn], data[(int)CPE_NV.P02_cbn], data[(int)CPE_NV.ro_t]);
            double N = k_k_1 * (z1 + z2) / 2 * 101325 / 293 / 1000 / data[(int)CPE_NV.ro_t] * (data[(int)CPE_NV.T02_cbn] - data[(int)CPE_NV.T01_cbn]) * data[(int)CPE_NV.G_cbn] / 1000;
            data[(int)CPE_NV.N] = N + Nmeh;
            status[(int)CPE_NV.N] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01_cbn, (int)CPE_NV.T02_cbn, (int)CPE_NV.P01_cbn, (int)CPE_NV.P02_cbn, (int)CPE_NV.ro_t, (int)CPE_NV.n3, (int)CPE_NV.G_cbn });

            if ((data[(int)CPE_NV.G_t_gtd] > 0) && (data[(int)CPE_NV.Q_t] > 0))
            {
                data[(int)CPE_NV.ef] = data[(int)CPE_NV.N] * 1000.0 / data[(int)CPE_NV.G_t_gtd] / data[(int)CPE_NV.Q_t];
                status[(int)CPE_NV.ef] = Func.Utill_Status(status, new int[] { (int)CPE_NV.N, (int)CPE_NV.G_t_gtd, (int)CPE_NV.Q_t });
            }
            else
            {
                data[(int)CPE_NV.ef] = CPE_Enum_Const.value_INCORRECT;
                status[(int)CPE_NV.ef] = CPE_ValidityDataTypes.ValidityDataTypeError;
            }

            data[(int)CPE_NV.ef_gpa] = data[(int)CPE_NV.ef] * data[(int)CPE_NV.ef_cbn];
            status[(int)CPE_NV.ef_gpa] = Func.Utill_Status(status, new int[] { (int)CPE_NV.ef, (int)CPE_NV.ef_cbn });

            Z = Func.GasCompressibility(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.P01_cbn], data[(int)CPE_NV.ro_t]);
            density = Func.GasDensity(data[(int)CPE_NV.T01_cbn], data[(int)CPE_NV.P01_cbn], 101325 / 293.15 / data[(int)CPE_NV.ro_t], Z);

            data[(int)CPE_NV.V1_cbn] = data[(int)CPE_NV.G_cbn] / density;
            status[(int)CPE_NV.V1_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01_cbn, (int)CPE_NV.P01_cbn, (int)CPE_NV.ro_t, (int)CPE_NV.G_cbn });

            if (data[(int)CPE_NV.n3] > 0)
            {
                data[(int)CPE_NV.V1pr_cbn] = cfg.Nominal[CPE_NV.nom_n3] / data[(int)CPE_NV.n3] * data[(int)CPE_NV.V1_cbn];
                status[(int)CPE_NV.V1pr_cbn] = Func.Utill_Status(status, new int[] { (int)CPE_NV.n3, (int)CPE_NV.V1_cbn });
            }
            else
            {
                data[(int)CPE_NV.V1pr_cbn] = CPE_Enum_Const.value_INCORRECT;
                status[(int)CPE_NV.V1pr_cbn] = CPE_ValidityDataTypes.ValidityDataTypeError;
            }


            data[(int)CPE_NV.n1pr] = Func.PrivRPM(data[(int)CPE_NV.n1], data[(int)CPE_NV.T01]);
            status[(int)CPE_NV.n1pr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.n1, (int)CPE_NV.T01 });

            data[(int)CPE_NV.n2pr] = Func.PrivRPM(data[(int)CPE_NV.n2], data[(int)CPE_NV.T01]);
            status[(int)CPE_NV.n2pr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.n2, (int)CPE_NV.T01 });

            data[(int)CPE_NV.n3pr] = Func.PrivRPM(data[(int)CPE_NV.n3], data[(int)CPE_NV.T01]);
            status[(int)CPE_NV.n3pr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.n3, (int)CPE_NV.T01 });

            data[(int)CPE_NV.P02pr] = Func.PrivPressure(data[(int)CPE_NV.P02], data[(int)CPE_NV.B]);
            status[(int)CPE_NV.P02pr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.P02, (int)CPE_NV.B });

            data[(int)CPE_NV.Npr] = Func.PrivPower(data[(int)CPE_NV.N], data[(int)CPE_NV.T01], data[(int)CPE_NV.B]);
            status[(int)CPE_NV.Npr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01, (int)CPE_NV.B, (int)CPE_NV.N });

            data[(int)CPE_NV.T04pr] = Func.PrivTemperature(data[(int)CPE_NV.T04], data[(int)CPE_NV.T01]);
            status[(int)CPE_NV.T04pr] = Func.Utill_Status(status, new int[] { (int)CPE_NV.T01, (int)CPE_NV.T04 });

            data[(int)CPE_NV.Gpr_t] = Func.PrivPower(data[(int)CPE_NV.G_t_gtd], data[(int)CPE_NV.T01], data[(int)CPE_NV.B]) * data[(int)CPE_NV.Q_t] / (8000 * 4.1868 / data[(int)CPE_NV.ro_t]);
            status[(int)CPE_NV.Gpr_t] = Func.Utill_Status(status, new int[] { (int)CPE_NV.G_t_gtd, (int)CPE_NV.T01, (int)CPE_NV.B, (int)CPE_NV.Q_t, (int)CPE_NV.ro_t });

            result = true;
            return result;
        }
    }
}



