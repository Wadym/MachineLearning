﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_Lib;
using CPE_Methodics_STO;
using CPE_CommonBlocks;


namespace CPE_Methodics_STO
{
    public class CPE_cgf_CPE_Process3_Nominal
    {
        public CPE_NameSliceColumn Pos { get; set; }   //Input Data for cluster

        public Dictionary<int, double> NominalDict;
        public Dictionary<CPE_NamePolynom, Polynoms> PolynomDict;


        public CPE_cgf_CPE_Process3_Nominal()
        {
            NominalDict = new Dictionary<int, double>();
            PolynomDict = new Dictionary<CPE_NamePolynom, Polynoms>();
        }

    }



    public class CPE_Process3_Nominal : SliceProcessing
    {
        CPE_cgf_CPE_Process3_Nominal cfg = new CPE_cgf_CPE_Process3_Nominal();

        //config
        public void Config(CPE_cgf_CPE_Process3_Nominal confdata)
        {
            cfg = confdata;

            //check that all field non empty


            Func.Utill_CheckDictionaryKey("CPE_Process3_Nominal",
                new int[] { (int)CPE_NV.nom_N, (int)CPE_NV.nom_T04, (int)CPE_NV.nom_n2, (int)CPE_NV.nom_n3, (int)CPE_NV.nom_V_cbn, (int)CPE_NV.nom_ef_cbn },
                confdata.NominalDict);

            Func.Utill_CheckDictionaryKey("CPE_Process3_Nominal",
                new CPE_NamePolynom[] { CPE_NamePolynom.G_t_N },
                confdata.PolynomDict);

            Func.Utill_CheckDictionaryKey("CPE_Process3_Nominal",
               new CPE_NamePolynom[] { CPE_NamePolynom.ef_cbn_V1 },
               confdata.PolynomDict);

        }

        public override void Init(Slice input)
        {
            //if there are not position add
            if (false == input.Data.ContainsKey((int)cfg.Pos))
            {
                input.Data.Add((int)cfg.Pos, new Dictionary<int, double>());
                input.DataStatus.Add((int)cfg.Pos, new Dictionary<int, CPE_ValidityDataTypes>());
            }
        }


        public override bool Process(Slice input)
        {
            bool result = false;

            //make local dictionary
            Dictionary<int, double> data_dic = input.Data[(int)cfg.Pos];
            Dictionary<int, CPE_ValidityDataTypes> status_dic = input.DataStatus[(int)cfg.Pos];

            //transfer tp Process3_Nominal
            data_dic[(int)CPE_NV.form_ef_cbn_V1] = cfg.PolynomDict[CPE_NamePolynom.ef_cbn_V1].Value(data_dic[(int)CPE_NV.V1pr_cbn]);
            status_dic[(int)CPE_NV.form_ef_cbn_V1] = cfg.PolynomDict[CPE_NamePolynom.ef_cbn_V1].Status(data_dic[(int)CPE_NV.V1pr_cbn]);
            status_dic[(int)CPE_NV.form_ef_cbn_V1] = Func.Utill_Status(status_dic, new int[] { (int)CPE_NV.V1pr_cbn, (int)CPE_NV.form_ef_cbn_V1 });
            //****

            data_dic[(int)CPE_NV.nom_N] = cfg.NominalDict[(int)CPE_NV.nom_N];
            status_dic[(int)CPE_NV.nom_N] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            data_dic[(int)CPE_NV.nom_T04] = cfg.NominalDict[(int)CPE_NV.nom_T04];
            status_dic[(int)CPE_NV.nom_T04] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            data_dic[(int)CPE_NV.nom_n2] = cfg.NominalDict[(int)CPE_NV.nom_n2];
            status_dic[(int)CPE_NV.nom_n2] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            data_dic[(int)CPE_NV.nom_n3] = cfg.NominalDict[(int)CPE_NV.nom_n3];
            status_dic[(int)CPE_NV.nom_n3] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            data_dic[(int)CPE_NV.nom_ef_cbn] = cfg.NominalDict[(int)CPE_NV.nom_ef_cbn];
            status_dic[(int)CPE_NV.nom_ef_cbn] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            data_dic[(int)CPE_NV.nom_V_cbn] = cfg.NominalDict[(int)CPE_NV.nom_V_cbn];
            status_dic[(int)CPE_NV.nom_V_cbn] = CPE_ValidityDataTypes.ValidityDataTypeGood;

            status_dic[(int)CPE_NV.nom_G_t] = Func.Utill_Status(status_dic, new int[] { (int)CPE_NV.nom_N });
            if ((CPE_ValidityDataTypes.ValidityDataTypeGood == status_dic[(int)CPE_NV.nom_G_t]) ||
               (CPE_ValidityDataTypes.ValidityDataTypeHandmade == status_dic[(int)CPE_NV.nom_G_t]))
            {
                data_dic[(int)CPE_NV.nom_G_t] = cfg.PolynomDict[CPE_NamePolynom.G_t_N].Value(data_dic[(int)CPE_NV.nom_N]);
                status_dic[(int)CPE_NV.nom_G_t] = cfg.PolynomDict[CPE_NamePolynom.G_t_N].Status(data_dic[(int)CPE_NV.nom_N]);
            }
            else
            {
                data_dic[(int)CPE_NV.nom_G_t] = CPE_Enum_Const.value_INCORRECT;
            }


            result = true;
            return result;
        }
    }
}



