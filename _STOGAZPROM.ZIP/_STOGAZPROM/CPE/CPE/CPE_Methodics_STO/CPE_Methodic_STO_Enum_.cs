﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CPE_Methodics_STO
{

    public class CPE_Methodic_STO_Enum_
    {
        
    }
    public enum CPE_NameSliceColumn
    {
        ISP,
        ModeDetectMean,
        ModeDetectDelta,
        Cluster,
        PostProcessor
    };

    public enum CPE_NamePolynom
    {
        ef_cbn_V1,
        N_T04,
        N_n2,
        G_t_N
    }

    public enum CPE_NV
    {
        B=1,
        n1=2,
        n2=3,
        n3=4,
        T01_cbn=5,
        T02_cbn=6,
        Pi01_cbn=7,
        Pi02_cbn=8,
        Pd_cbn_conf=9,
        T01=10,
        T04=11,
        G_cbn_sau_temp=12,
        t_t_diafr=13,
        Pi_t_diafr=14,
        Pd_t_diafr=15,
        G_t_sau_temp=16,
        P02=17,
        ro_t=18,
        Q_t=19,
        P01_cbn=20,
        P02_cbn=21,
        P_t_diafr=22,
        G_cbn_sau=23,
        G_t_sau=24,
        G_cbn_diafr=25,
        G_t_diafr=26,
        G_cbn=27,
        G_t_gtd=28,
        ef_cbn=29,
        N=30,
        ef=31,
        ef_gpa=32,
        V1_cbn=33,
        V1pr_cbn=34,
        n1pr=35,
        n2pr=36,
        n3pr=37,
        P02pr=38,
        Npr=39,
        T04pr=40,
        Gpr_t=41,
        nom_N=42,
        nom_T04=43,
        nom_n2=44,
        nom_n3=45,
        nom_ef_cbn=46,
        nom_V_cbn=47,
        nom_G_t=48,
        form_ef_cbn_V1=49,
        form_N_T04=50,
        form_N_n2=51,
        form_G_t_N=52,
        clus_ef_cbn_V1=53,
        cluss_Npr_T04=54,
        clus_N_n2=55,
        clus_G_t_N=56,
        Coef_regim=57,
        CoefDiafr=58,
        CoefConf=59,
        KTS_cbn=60,
        KTS_N_T04=61,
        KTS_N_n2=62,
        KTS_N=63,
        KTS_G_t=64
    }
}
