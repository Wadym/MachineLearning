﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace CPE_FifoArraysData
{
    /// <summary>
    /// Класс очереди массивов данных
    /// </summary>
    public class CPE_FifoArraysData<T>
    {
        /// <summary>Размер очереди</summary>
        private readonly Int32 m_Size;
        /// <summary>Через какое число записей записывать в поток. 0 - не записывать</summary>
        private readonly UInt32 m_SaveNum;
        /// <summary>Счетчик добавленных элементов</summary>
        private UInt32 m_SaveCount;
        /// <summary>Поток для записи</summary>
        private Stream m_StreamForSave;
        /// <summary>Очередь</summary>
        private List<List<T>> m_Queue;
        /// <summary>Объект для лока очереди</summary>
        private Object m_GuardQueue;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="size">Размер очереди</param>
        /// <param name="saveCount">Через какое число записей записывать в поток</param>
        /// <param name="streamForSave">Поток для записи</param>
        public CPE_FifoArraysData(Int32 size, UInt32 saveCount, Stream streamForSave)
        {
            m_Size = size;
            m_SaveNum = saveCount;
            m_SaveCount = 0;
            m_StreamForSave = streamForSave;

            m_GuardQueue = new Object();
            m_Queue = new List<List<T>>((Int32)m_Size);

            if (streamForSave != null)
            {
                BinaryFormatter bf = new BinaryFormatter();
                try
                {
                    m_Queue = (List<List<T>>)bf.Deserialize(streamForSave);
                }
                catch (SerializationException)
                {
                    // Если не удалось десериализовать, то считаем что ничего не было
                }
            }
        }
        
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="size">Размер очереди</param>
        public CPE_FifoArraysData(Int32 size)
            : this(size, 0, null)
        {
        }

        /// <summary>
        /// Добавление элемента в очередь
        /// </summary>
        /// <param name="elem">Добавляемый элемент</param>
        public void Add(List<T> elem)
        {
            // лочим очередь
            lock (m_GuardQueue)
            {
                // Если уперлись в размер, то выкидываем первый элемент
                if (m_Queue.Count == m_Size)
                {
                    m_Queue.RemoveAt(0);
                }

                // Добавляем
                m_Queue.Add(elem);

                // Если необходимо периодически добавлять в файл, то будем считать добавляемые элементы
                if (m_SaveNum != 0)
                {
                    m_SaveCount++;

                    // Если пора сохранять, то сохраняем
                    if (m_SaveCount == m_SaveNum)
                    {
                        SaveQueueToStream();
                        m_SaveCount = 0;
                    }
                }
            }
        }

        /// <summary>
        /// Получить первый срез
        /// </summary>
        /// <returns></returns>
        public List<T> GetFirstElem()
        {
            // лочим очередь
            lock (m_GuardQueue)
            {
                // Если в ней что-то есть, то отдаем первый элемент
                if (m_Queue.Count > 0)
                {
                    // Сохраняем первый элемент
                    List<T> elem = m_Queue[0];
                    // удаляем его из очереди
                    m_Queue.RemoveAt(0);

                    return elem;
                }

                // в очереди ничего не оказалось
                return null;
            }
        }

        /// <summary>
        /// Сохранить очередь в поток
        /// </summary>
        private void SaveQueueToStream()
        { 
            if (m_StreamForSave == null)
                throw new ArgumentNullException("SaveQueueToStream: В класс не передан поток для записи (m_StreamForSave = null)");

            m_StreamForSave.SetLength(0);

            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(m_StreamForSave, m_Queue);
            
            m_StreamForSave.Flush();
        }
    }
}
