﻿using System;
using System.Collections.Generic;
using System.Text;
using CPE_FifoArraysData;
using System.IO;

namespace CPE_FifoArraysDataTest
{
    class Program
    {
        static void Main(string[] args)
        {
            using (FileStream file = new FileStream("test.dat", FileMode.OpenOrCreate))
            {
                CPE_FifoArraysData<Double> queue = new CPE_FifoArraysData<Double>(10, 5, file);

                queue.Add(new List<Double>() { 10, 20, 30});
                queue.Add(new List<Double>() { 20, 30, 40 });
                queue.Add(new List<Double>() { 30, 40, 50 });
                queue.Add(new List<Double>() { 40, 50, 60 });
                queue.Add(new List<Double>() { 50, 60, 70 });
                queue.Add(new List<Double>() { 60, 70, 80 });
                queue.Add(new List<Double>() { 70, 80, 90 });
                List<Double> elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                elem = queue.GetFirstElem();
                queue.Add(new List<Double>() { 10, 20, 30 });
                queue.Add(new List<Double>() { 10, 20, 30 });
                queue.Add(new List<Double>() { 10, 20, 30 });
                queue.Add(new List<Double>() { 10, 20, 30 });
                queue.Add(new List<Double>() { 10, 20, 30 });
            }
        }
    }
}
